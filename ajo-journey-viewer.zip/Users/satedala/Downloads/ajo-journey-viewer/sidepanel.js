// sidepanel.js
// Single-view conditions viewer: groups condition nodes by their label
// and shows each group as a color-coded container with a name/expression
// table inside.

const $  = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

let currentJourney = null;
let currentOrgId = null;
let currentSandbox = null;
let currentAjoBaseUrl = null;  // e.g. "https://experience.adobe.com/#/@paypal/sname:prod"

let settings = {
  apiKey:       'voyager_ui',
  sandbox:      'dev',
  apiBaseUrl:   'https://journey-private.adobe.io/authoring',
  acceptHeader: 'application/vnd.adobe.jo+json'
};

// Rotating colors for group containers
const GROUP_COLORS = ['coral', 'amber', 'teal', 'purple', 'pink', 'blue', 'green'];

async function init() {
  await loadSettings();
  await restoreColumnWidth();

  // Detect if we're running in a regular browser tab vs side panel
  const isTabMode = new URLSearchParams(location.search).get('mode') === 'tab';
  if (isTabMode) {
    document.body.classList.add('tab-mode');
    // Hide the "Open in tab" button since we're already in one
    const btn = $('#openTabBtn');
    if (btn) btn.style.display = 'none';
    // Try to restore the journey that was passed via storage
    await hydrateFromStorage();
  }

  $('#loadBtn').addEventListener('click', loadFromCurrentTab);
  $('#pasteBtn').addEventListener('click', () => $('#pasteModal').classList.remove('hidden'));
  $('#pasteSubmit').addEventListener('click', loadFromPaste);
  $('#pasteCancel').addEventListener('click', () => $('#pasteModal').classList.add('hidden'));
  $('#openTabBtn')?.addEventListener('click', openInTab);

  showSettingsBanner();
  if (!currentJourney) detectAndShowStatus();
}

async function hydrateFromStorage() {
  try {
    const { lastJourney, lastOrgId, lastSandbox, lastAjoBaseUrl } = await chrome.storage.local.get(['lastJourney', 'lastOrgId', 'lastSandbox', 'lastAjoBaseUrl']);
    if (lastJourney) {
      currentJourney = lastJourney;
      currentOrgId = lastOrgId || null;
      currentSandbox = lastSandbox || null;
      currentAjoBaseUrl = lastAjoBaseUrl || null;
      if (lastOrgId || lastSandbox) showSettingsBanner(lastOrgId, lastSandbox);
      loadJourney(lastJourney);
      const n = (lastJourney.ui?.nodes || []).filter((x) => x.type === 'condition').length;
      showStatus(`Restored "${lastJourney.name || 'journey'}" — ${n} condition node${n === 1 ? '' : 's'}`, 'success');
      // One-shot: clear so a refresh doesn't keep showing stale data
      chrome.storage.local.remove(['lastJourney', 'lastOrgId', 'lastSandbox', 'lastAjoBaseUrl']);
    }
  } catch (e) {
    console.warn('hydrateFromStorage failed:', e);
  }
}

async function openInTab() {
  try {
    if (currentJourney) {
      await chrome.storage.local.set({
        lastJourney: currentJourney,
        lastOrgId: currentOrgId,
        lastSandbox: currentSandbox,
        lastAjoBaseUrl: currentAjoBaseUrl
      });
    }
    const url = chrome.runtime.getURL('sidepanel.html') + '?mode=tab';
    await chrome.tabs.create({ url });
  } catch (e) {
    console.error(e);
    showStatus(`Could not open in tab: ${e.message}`, 'error');
  }
}

async function loadSettings() {
  try {
    const url = chrome.runtime.getURL('settings.json');
    const res = await fetch(url);
    if (res.ok) {
      const s = await res.json();
      settings = { ...settings, ...s };
    }
  } catch (e) {
    console.warn('Could not load settings.json, using defaults:', e);
  }
}

function showSettingsBanner(orgId, sandbox) {
  const el = $('#settingsBanner');
  if (!el) return;
  const activeSandbox = sandbox || currentSandbox || settings.sandbox;
  const orgPill = orgId
    ? `<span class="settings-pill"><strong>org:</strong> ${escapeHtml(orgId.slice(0, 12))}…</span>`
    : '';
  el.innerHTML = `
    ${orgPill}
    <span class="settings-pill"><strong>sandbox:</strong> ${escapeHtml(activeSandbox)}</span>
  `;
}

async function detectAndShowStatus() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /experience\.adobe\.com.*journey-optimizer/.test(tab.url)) {
      showStatus('Adobe Journey Optimizer detected. Click "Load from tab" to fetch.', 'info');
    } else {
      showStatus('Open an AJO journey page and click "Load from tab", or paste JSON.', 'info');
    }
  } catch (e) {
    showStatus('Ready. Paste JSON or open an AJO journey page.', 'info');
  }
}

// =============================================================
// Load from current tab
// =============================================================

// Pick the right tab to extract from. In side-panel mode the currently active
// tab IS the AJO page. In tab mode (this viewer opened as a tab), the active
// tab is the viewer itself, so we hunt across all windows for an AJO tab.
async function getTargetTab() {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active && active.url && active.url.includes('experience.adobe.com')) {
    return active;
  }

  // Look for any Adobe Experience tab in any window
  const adobeTabs = await chrome.tabs.query({ url: 'https://experience.adobe.com/*' });
  if (adobeTabs.length === 0) {
    throw new Error('No Adobe Experience tab found. Open a journey page in another tab first.');
  }
  // Prefer one that looks like a journey URL
  const journeyTab = adobeTabs.find((t) => /journey/i.test(t.url || ''));
  return journeyTab || adobeTabs[0];
}

async function loadFromCurrentTab() {
  showStatus('Inspecting active tab…', 'loading');
  try {
    const tab = await getTargetTab();

    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: extractAjoContext
    });

    const ctx = result && result.result;
    if (!ctx)                              throw new Error('Could not extract context from page.');
    if (!ctx.token)                        throw new Error('No IMS access token in sessionStorage. Are you signed in to Adobe?');
    if (!ctx.orgId)                        throw new Error('Could not determine IMS org ID from page storage (looked in unifiedShellSession).');
    if (!ctx.journeyId && !ctx.versionId)  throw new Error('No journey ID or version ID found in URL. Expected …/journey/{uuid} or …/version/{uuid}.');

    // Update banner with the detected org + sandbox
    currentOrgId = ctx.orgId;
    currentSandbox = ctx.sandbox || settings.sandbox;
    currentAjoBaseUrl = ctx.ajoBaseUrl || null;
    showSettingsBanner(ctx.orgId, currentSandbox);

    const idLabel = ctx.versionId
      ? `version ${ctx.versionId.slice(0, 8)}…`
      : `journey ${ctx.journeyId.slice(0, 8)}…`;
    showStatus(`Fetching ${idLabel} (sandbox: ${currentSandbox})`, 'loading');

    const journey = await fetchJourney(ctx);
    loadJourney(journey);
    const conditionCount = (journey.ui?.nodes || []).filter((n) => n.type === 'condition').length;
    showStatus(`Loaded "${journey.name || 'journey'}" — ${conditionCount} condition node${conditionCount === 1 ? '' : 's'}`, 'success');
  } catch (e) {
    console.error(e);
    showStatus(`Error: ${e.message}`, 'error');
  }
}

function extractAjoContext() {
  const tokens = [];
  for (let i = 0; i < sessionStorage.length; i++) {
    const key = sessionStorage.key(i);
    if (!key || !key.toLowerCase().includes('access_token')) continue;
    const value = sessionStorage.getItem(key);
    if (!value) continue;
    let raw = value;
    try {
      const parsed = JSON.parse(value);
      if (typeof parsed === 'string') raw = parsed;
      else if (parsed && typeof parsed === 'object') {
        raw = parsed.tokenValue || parsed.access_token || parsed.token || value;
      }
    } catch (_) {}
    if (typeof raw !== 'string' || raw.split('.').length !== 3) continue;
    tokens.push({ key, token: raw });
  }

  const best = tokens[0];

  // ---- Extract IMS org ID from unifiedShellSession (primary path) ----
  // The Adobe shell stores it as { activeOrg, userOrgs: [{ imsOrgId, orgName, ... }] }
  let orgId = null;
  try {
    const shell = localStorage.getItem('unifiedShellSession');
    if (shell) {
      const parsed = JSON.parse(shell);
      orgId =
        parsed.activeOrg ||
        (Array.isArray(parsed.userOrgs) && parsed.userOrgs[0] && parsed.userOrgs[0].imsOrgId) ||
        null;
    }
  } catch (_) {}

  // ---- Fallback: scan all storage for the @AdobeOrg pattern ----
  if (!orgId) {
    const ORG_RX = /([A-F0-9]{24}@AdobeOrg)/i;
    const scan = (st) => {
      for (let i = 0; i < st.length; i++) {
        const v = st.getItem(st.key(i));
        if (typeof v !== 'string') continue;
        const m = v.match(ORG_RX);
        if (m) return m[1];
      }
      return null;
    };
    orgId = scan(localStorage) || scan(sessionStorage);
  }

  const url = location.href;
  const hash = location.hash || '';
  const fullText = url + ' ' + hash;
  const UUID = '[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
  const journeyMatch = fullText.match(new RegExp(`journey\\/(${UUID})`, 'i'));
  const versionMatch = fullText.match(new RegExp(`version\\/(${UUID})`, 'i'));

  // Sandbox is encoded as /sname:xxx/ in the AJO URL path/hash
  // e.g. /sname:prod/journey-optimizer/journeys/journey/{uuid}
  const sandboxMatch = fullText.match(/sname:([A-Za-z0-9_-]+)/);

  // Base URL for AJO deep links — captures protocol + host + tenant + sname.
  // e.g. "https://experience.adobe.com/#/@paypal/sname:prod"
  const baseMatch = url.match(/^(https:\/\/experience\.adobe\.com\/#\/@[^/]+\/sname:[^/]+)/);
  const ajoBaseUrl = baseMatch ? baseMatch[1] : null;

  return {
    token: best ? best.token : null,
    orgId,
    sandbox: sandboxMatch ? sandboxMatch[1] : null,
    ajoBaseUrl,
    journeyId: journeyMatch ? journeyMatch[1] : null,
    versionId: versionMatch ? versionMatch[1] : null,
    url
  };
}

async function fetchJourney(ctx) {
  const sandbox = ctx.sandbox || settings.sandbox;
  const headers = {
    'Authorization':   `Bearer ${ctx.token}`,
    'x-api-key':       settings.apiKey,
    'x-gw-ims-org-id': ctx.orgId,
    'x-sandbox-name':  sandbox,
    'Content-Type':    'application/json',
    'Accept':          settings.acceptHeader || 'application/vnd.adobe.jo+json'
  };

  let versionId = ctx.versionId;

  if (!versionId && ctx.journeyId) {
    versionId = await resolveVersionFromJourney(ctx.journeyId, headers);
  }
  if (!versionId) throw new Error('Could not resolve a version ID to fetch.');

  const url = `${settings.apiBaseUrl}/journeyVersions/${versionId}`;
  const res = await fetch(url, { headers });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Version API ${res.status}: ${body.slice(0, 240) || res.statusText}`);
  }
  const raw = await res.json();
  return normalizeJourney(raw);
}

async function resolveVersionFromJourney(journeyId, headers) {
  showStatus(`Looking up versions for journey ${journeyId.slice(0, 8)}…`, 'loading');

  try {
    const jUrl = `${settings.apiBaseUrl}/journeys/${journeyId}`;
    const jRes = await fetch(jUrl, { headers });
    if (jRes.ok) {
      const j = await jRes.json();
      const root = j.result || j;
      const v = root.latestVersionId
             || root.liveVersionId
             || root.lastVersionId
             || root.versionId
             || root._embedded?.latest?.id
             || root._embedded?.version?.id
             || root._embedded?.['latest-version']?.id;
      if (v) return v;
    }
  } catch (_) {}

  try {
    const vUrl = `${settings.apiBaseUrl}/journeys/${journeyId}/versions`;
    const vRes = await fetch(vUrl, { headers });
    if (vRes.ok) {
      const data = await vRes.json();
      const versions = data._embedded?.versions
                    || data.versions
                    || data.items
                    || data.results
                    || (Array.isArray(data) ? data : []);
      if (versions.length) {
        const live = versions.find((v) => (v.state || v.status || '').toLowerCase() === 'live');
        const pick = live || [...versions].sort((a, b) =>
          (b.createdAt || b.modifiedAt || '').localeCompare(a.createdAt || a.modifiedAt || '')
        )[0];
        const id = pick && (pick.id || pick.uid || pick.versionId);
        if (id) return id;
      }
    }
  } catch (_) {}

  return journeyId;
}

// =============================================================
// Normalize API response shape
// =============================================================

function normalizeJourney(raw) {
  if (!raw || typeof raw !== 'object') return raw;
  const root = (raw.result && typeof raw.result === 'object' && raw.result.ui) ? raw.result : raw;
  const ui = root.ui || { nodes: [], edges: [] };

  const toArr = (v) => {
    if (Array.isArray(v)) return v;
    if (v && typeof v === 'object') return Object.values(v);
    return [];
  };

  return {
    ...root,
    ui: {
      ...ui,
      nodes: toArr(ui.nodes),
      edges: toArr(ui.edges)
    }
  };
}

// =============================================================
// Paste JSON
// =============================================================

async function loadFromPaste() {
  const text = $('#pasteText').value.trim();
  if (!text) return;

  // Detect input type:
  //   1) URL like https://journey-private.adobe.io/authoring/journeyVersions/{id}
  //   2) curl command (extract the URL out of it)
  //   3) raw JSON (existing behavior)
  const isJsonLike = /^[\[{]/.test(text);
  if (!isJsonLike) {
    const urlMatch = text.match(/https?:\/\/[^\s'"`]+/);
    if (urlMatch) {
      await fetchFromUrl(urlMatch[0]);
      $('#pasteText').value = '';
      $('#pasteModal').classList.add('hidden');
      return;
    }
  }

  // Fall through: treat as JSON
  try {
    const parsed = JSON.parse(text);

    // Auto-detect: profile JSON vs journey JSON.
    // Profile JSON has identityMap or segmentMembership or a tenant block
    // (a key starting with "_") and no journey ui/nodes.
    if (isProfileJson(parsed)) {
      loadProfile(parsed);
      $('#pasteModal').classList.add('hidden');
      $('#pasteText').value = '';
      return;
    }

    const journey = normalizeJourney(parsed);
    loadJourney(journey);
    $('#pasteModal').classList.add('hidden');
    $('#pasteText').value = '';
    const conditionCount = (journey.ui?.nodes || []).filter((n) => n.type === 'condition').length;
    showStatus(`Loaded "${journey.name || 'journey'}" — ${conditionCount} condition node${conditionCount === 1 ? '' : 's'}`, 'success');
  } catch (e) {
    alert('Could not parse input as JSON, URL, or curl: ' + e.message);
  }
}

// Fetch a journey version straight from a full API URL.
// The URL must look like .../journeyVersions/{uuid} or .../journeys/{uuid}.
// We still need auth from the active Adobe tab.
async function fetchFromUrl(rawUrl) {
  showStatus('Pulling auth from Adobe tab…', 'loading');
  try {
    const tab = await getTargetTab();
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: extractAjoContext
    });
    const pageCtx = result && result.result;
    if (!pageCtx || !pageCtx.token) throw new Error('No IMS access token found. Open an AJO tab and sign in.');
    if (!pageCtx.orgId)             throw new Error('No IMS org ID found in page storage (unifiedShellSession).');

    currentOrgId = pageCtx.orgId;
    currentSandbox = pageCtx.sandbox || settings.sandbox;
    currentAjoBaseUrl = pageCtx.ajoBaseUrl || null;
    showSettingsBanner(pageCtx.orgId, currentSandbox);

    // Parse the URL — pull out versionId or journeyId
    const UUID = '[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
    const versionMatch = rawUrl.match(new RegExp(`journeyVersions\\/(${UUID})`, 'i'));
    const journeyMatch = rawUrl.match(new RegExp(`journeys\\/(${UUID})(?!\\/versions)`, 'i'));

    if (!versionMatch && !journeyMatch) {
      throw new Error('URL does not contain a journeyVersions/{uuid} or journeys/{uuid} path.');
    }

    const ctx = {
      token:     pageCtx.token,
      orgId:     pageCtx.orgId,
      sandbox:   currentSandbox,
      versionId: versionMatch ? versionMatch[1] : null,
      journeyId: journeyMatch ? journeyMatch[1] : null
    };

    const idLabel = ctx.versionId
      ? `version ${ctx.versionId.slice(0, 8)}…`
      : `journey ${ctx.journeyId.slice(0, 8)}…`;
    showStatus(`Fetching ${idLabel} from pasted URL (sandbox: ${currentSandbox})`, 'loading');

    const journey = await fetchJourney(ctx);
    loadJourney(journey);
    const n = (journey.ui?.nodes || []).filter((x) => x.type === 'condition').length;
    showStatus(`Loaded "${journey.name || 'journey'}" — ${n} condition node${n === 1 ? '' : 's'}`, 'success');
  } catch (e) {
    console.error(e);
    showStatus(`Error: ${e.message}`, 'error');
  }
}

// =============================================================
// Render: Conditions view (grouped by label)
// =============================================================

function loadJourney(journey) {
  currentJourney = journey;
  // Switch back to journey conditions view (in case a profile was previously loaded)
  $('#conditionsView').classList.remove('hidden');
  $('#profileView').classList.add('hidden');
  renderConditionsView(journey);
}

function renderConditionsView(journey) {
  const container = $('#conditionsView');
  const nodes = (journey.ui && journey.ui.nodes) || [];
  const edges = (journey.ui && journey.ui.edges) || [];

  const renderable = orderRenderableByFlow(nodes, edges);

  if (!renderable.length) {
    container.innerHTML = '<div class="empty">No renderable nodes (event, condition, audience, action, timer, email, campaign) in this journey.</div>';
    return;
  }

  // Color assignment:
  //   - conditions cycle through GROUP_COLORS, one per unique label
  //   - non-condition types get a fixed per-type color (TYPE_COLORS)
  const labelColors = new Map();
  let colorIdx = 0;
  for (const n of renderable) {
    if (n.type !== 'condition') continue;
    const label = n.data?.label || n.label || 'Untitled condition';
    if (!labelColors.has(label)) {
      labelColors.set(label, GROUP_COLORS[colorIdx % GROUP_COLORS.length]);
      colorIdx++;
    }
  }

  // Count by type for the summary line
  const counts = { condition: 0, segmentTrigger: 0, action: 0, message: 0, campaign: 0, timer: 0, event: 0 };
  for (const n of renderable) counts[n.type] = (counts[n.type] || 0) + 1;

  const journeyName = journey.name || 'Untitled journey';
  const sandbox = journey.sandboxName || currentSandbox || settings.sandbox || '—';
  const journeyVersion = journey.journeyVersion || '?';
  const state = journey.state || 'unknown';

  // Map of node id -> 1-based position so any node ref can hyperlink.
  const nodeIndex = new Map();
  renderable.forEach((n, i) => nodeIndex.set(n.id, i + 1));

  const html = renderable.map((node, i) => {
    let color;
    if (node.type === 'condition') {
      const lbl = node.data?.label || node.label || 'Untitled condition';
      color = labelColors.get(lbl);
    } else {
      color = TYPE_COLORS[node.type] || 'blue';
    }
    return renderJourneyNode(node, i + 1, color, nodes, edges, nodeIndex);
  });

  // Build summary chips
  const summaryParts = [];
  if (counts.condition)      summaryParts.push(`<strong>${counts.condition}</strong> condition${counts.condition === 1 ? '' : 's'}`);
  if (counts.segmentTrigger) summaryParts.push(`<strong>${counts.segmentTrigger}</strong> audience${counts.segmentTrigger === 1 ? '' : 's'}`);
  if (counts.event)          summaryParts.push(`<strong>${counts.event}</strong> event${counts.event === 1 ? '' : 's'}`);
  if (counts.action)         summaryParts.push(`<strong>${counts.action}</strong> action${counts.action === 1 ? '' : 's'}`);
  if (counts.timer)          summaryParts.push(`<strong>${counts.timer}</strong> timer${counts.timer === 1 ? '' : 's'}`);
  if (counts.message)        summaryParts.push(`<strong>${counts.message}</strong> email${counts.message === 1 ? '' : 's'}`);
  if (counts.campaign)       summaryParts.push(`<strong>${counts.campaign}</strong> campaign${counts.campaign === 1 ? '' : 's'}`);

  container.innerHTML = `
    <div class="conditions-header">
      <div class="ch-title-row">
        <div class="ch-title">Journey view</div>
        <div class="ch-actions">
          <button class="ch-action" id="expandAllBtn" type="button">Expand all</button>
          <button class="ch-action" id="collapseAllBtn" type="button">Collapse all</button>
        </div>
      </div>
      <div class="ch-row"><span class="ch-key">Journey:</span> <code class="ch-val">${escapeHtml(journeyName)}</code></div>
      <div class="ch-row"><span class="ch-key">Sandbox:</span> <code class="ch-val">${escapeHtml(sandbox)}</code> <span class="ch-sep">·</span> <span class="ch-key">Version:</span> <code class="ch-val">v${escapeHtml(String(journeyVersion))}</code> <span class="ch-sep">·</span> <span class="ch-key">State:</span> <code class="ch-val">${escapeHtml(state)}</code></div>
      <div class="ch-row">${summaryParts.join(' <span class="ch-sep">·</span> ')} <span class="ch-sep">·</span> <span class="ch-key">ordered by flow</span></div>
    </div>
    ${html.join('')}
  `;

  // Wire up collapse/expand
  container.querySelectorAll('.grp-head[data-toggle]').forEach((head) => {
    head.addEventListener('click', () => {
      head.parentElement.classList.toggle('collapsed');
      const tog = head.querySelector('.grp-toggle');
      if (tog) tog.textContent = head.parentElement.classList.contains('collapsed') ? '▶' : '▼';
    });
  });
  $('#expandAllBtn')?.addEventListener('click', () => {
    container.querySelectorAll('.grp').forEach((g) => {
      g.classList.remove('collapsed');
      const tog = g.querySelector('.grp-toggle');
      if (tog) tog.textContent = '▼';
    });
  });
  $('#collapseAllBtn')?.addEventListener('click', () => {
    container.querySelectorAll('.grp').forEach((g) => {
      g.classList.add('collapsed');
      const tog = g.querySelector('.grp-toggle');
      if (tog) tog.textContent = '▶';
    });
  });

  // Cross-card hyperlink jumps
  container.querySelectorAll('.cond-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.dataset.jump;
      if (!targetId) return;
      const targetEl = container.querySelector(`[data-cond-id="${targetId}"]`);
      if (!targetEl) return;
      if (targetEl.classList.contains('collapsed')) {
        targetEl.classList.remove('collapsed');
        const tog = targetEl.querySelector('.grp-toggle');
        if (tog) tog.textContent = '▼';
      }
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      targetEl.classList.add('flash-highlight');
      setTimeout(() => targetEl.classList.remove('flash-highlight'), 1600);
    });
  });

  // Copy-to-clipboard for expressions
  container.querySelectorAll('.copy-expr-btn').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      const txt = btn.dataset.expr || '';
      if (!txt) return;
      try {
        await navigator.clipboard.writeText(txt);
      } catch (_) {
        // Clipboard API may fail in some contexts — fall back to execCommand
        const ta = document.createElement('textarea');
        ta.value = txt;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (_) {}
        document.body.removeChild(ta);
      }
      const original = btn.textContent;
      btn.classList.add('copied');
      btn.textContent = '✓ copied';
      setTimeout(() => {
        btn.classList.remove('copied');
        btn.textContent = original;
      }, 1200);
    });
  });

  // Deep links — don't bubble into collapse toggling
  container.querySelectorAll('.deep-link').forEach((link) => {
    link.addEventListener('click', (e) => e.stopPropagation());
  });

  // Inject a drag handle into every group-label header so users can resize
  // the two columns. All tables share one CSS custom property on the container,
  // so dragging any handle resizes every card uniformly.
  installColumnResizers(container);
}

// =============================================================
// Profile view — render an AEP profile JSON as grouped tables
// =============================================================

// Detect: does this look like a profile JSON (vs a journey JSON)?
// Heuristics — any of:
//   - top-level "identityMap" object
//   - top-level "segmentMembership" object
//   - a tenant-prefixed key like "_paypal", "_nordstrom" containing an object
// AND no journey-style ui.nodes/ui.edges structure.
function isProfileJson(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return false;
  // If it has a journey shape, bail out — that's not a profile.
  const root = (obj.result && typeof obj.result === 'object' && obj.result.ui) ? obj.result : obj;
  if (root.ui && (root.ui.nodes || root.ui.edges)) return false;

  if (obj.identityMap && typeof obj.identityMap === 'object') return true;
  if (obj.segmentMembership && typeof obj.segmentMembership === 'object') return true;
  for (const k of Object.keys(obj)) {
    if (k.startsWith('_') && obj[k] && typeof obj[k] === 'object' && !Array.isArray(obj[k])) return true;
  }
  return false;
}

let currentProfile = null;

function loadProfile(profile) {
  currentProfile = profile;
  // Toggle the two main panels
  $('#conditionsView').classList.add('hidden');
  $('#profileView').classList.remove('hidden');
  renderProfileView(profile);

  // Quick summary for the status bar
  const idCount = countIdentities(profile);
  const segCount = profile.segmentMembership?.ups
    ? Object.keys(profile.segmentMembership.ups).length
    : 0;
  showStatus(`Loaded profile — ${idCount} identit${idCount === 1 ? 'y' : 'ies'}, ${segCount} segment${segCount === 1 ? '' : 's'}`, 'success');
}

function countIdentities(profile) {
  const ids = new Set();
  const im = profile.identityMap;
  if (im && typeof im === 'object') {
    for (const ns of Object.keys(im)) {
      const arr = Array.isArray(im[ns]) ? im[ns] : [];
      for (const x of arr) if (x && x.id) ids.add(`${ns}:${x.id}`);
    }
  }
  // Tenant identities too
  for (const k of Object.keys(profile)) {
    if (!k.startsWith('_')) continue;
    const tenantIdents = profile[k]?.identities;
    if (tenantIdents && typeof tenantIdents === 'object') {
      for (const [ns, v] of Object.entries(tenantIdents)) {
        if (v) ids.add(`${k}.${ns}:${v}`);
      }
    }
  }
  return ids.size;
}

function renderProfileView(profile) {
  const container = $('#profileView');

  // Counts for the header summary
  const identCount = countIdentities(profile);
  const segments = profile.segmentMembership?.ups || {};
  const segCount = Object.keys(segments).length;
  const realizedCount = Object.values(segments).filter((s) => s.status === 'realized').length;
  const exitedCount = Object.values(segments).filter((s) => s.status === 'exited').length;

  // SCAs live under any tenant key
  let scaCount = 0;
  const tenantKeys = Object.keys(profile).filter((k) => k.startsWith('_'));
  for (const tk of tenantKeys) {
    const sca = profile[tk]?.SystemComputedAttributes;
    if (sca && typeof sca === 'object') scaCount += Object.keys(sca).length;
  }

  const freqCount = profile.frequencyMap ? Object.keys(profile.frequencyMap).length : 0;
  const tenantList = tenantKeys.join(', ') || '—';
  const email = profile.personalEmail?.address || '—';
  const modified = profile.lastModifiedAt || '—';

  // Build sections (each returns an HTML string for a .grp block)
  const sections = [];
  sections.push(buildSummarySection(profile));
  sections.push(buildIdentitiesSection(profile));
  sections.push(buildTenantAttributesSection(profile));
  sections.push(buildSCASection(profile));
  sections.push(buildSegmentsSection(profile));
  sections.push(buildFrequencySection(profile));
  sections.push(buildFlatAllSection(profile));

  container.innerHTML = `
    <div class="conditions-header">
      <div class="ch-title-row">
        <div class="ch-title">Profile</div>
        <div class="ch-actions">
          <button class="ch-action" id="profileExpandAllBtn" type="button">Expand all</button>
          <button class="ch-action" id="profileCollapseAllBtn" type="button">Collapse all</button>
        </div>
      </div>
      <div class="ch-row"><span class="ch-key">Email:</span> <code class="ch-val">${escapeHtml(email)}</code></div>
      <div class="ch-row"><span class="ch-key">Tenant:</span> <code class="ch-val">${escapeHtml(tenantList)}</code> <span class="ch-sep">·</span> <span class="ch-key">Modified:</span> <code class="ch-val">${escapeHtml(modified)}</code></div>
      <div class="ch-row">
        <strong>${identCount}</strong> identit${identCount === 1 ? 'y' : 'ies'}
        <span class="ch-sep">·</span>
        <strong>${segCount}</strong> segment${segCount === 1 ? '' : 's'} (${realizedCount} realized, ${exitedCount} exited)
        <span class="ch-sep">·</span>
        <strong>${scaCount}</strong> computed attr${scaCount === 1 ? '' : 's'}
        <span class="ch-sep">·</span>
        <strong>${freqCount}</strong> frequency cap${freqCount === 1 ? '' : 's'}
      </div>
      <div class="profile-filter-wrap">
        <input type="text" class="profile-filter" id="profileFilter" placeholder="Filter rows by key or value…">
      </div>
    </div>
    ${sections.join('')}
  `;

  // Collapse/expand wiring (re-using the same pattern as renderConditionsView)
  container.querySelectorAll('.grp-head[data-toggle]').forEach((head) => {
    head.addEventListener('click', () => {
      head.parentElement.classList.toggle('collapsed');
      const tog = head.querySelector('.grp-toggle');
      if (tog) tog.textContent = head.parentElement.classList.contains('collapsed') ? '▶' : '▼';
    });
  });
  $('#profileExpandAllBtn')?.addEventListener('click', () => {
    container.querySelectorAll('.grp').forEach((g) => {
      g.classList.remove('collapsed');
      const tog = g.querySelector('.grp-toggle');
      if (tog) tog.textContent = '▼';
    });
  });
  $('#profileCollapseAllBtn')?.addEventListener('click', () => {
    container.querySelectorAll('.grp').forEach((g) => {
      g.classList.add('collapsed');
      const tog = g.querySelector('.grp-toggle');
      if (tog) tog.textContent = '▶';
    });
  });

  // Live filter across all profile tables
  const filterEl = $('#profileFilter');
  filterEl?.addEventListener('input', () => {
    const q = filterEl.value.trim().toLowerCase();
    container.querySelectorAll('.profile-table').forEach((tbl) => {
      let visible = 0;
      tbl.querySelectorAll('tbody tr').forEach((tr) => {
        const txt = tr.textContent.toLowerCase();
        const match = !q || txt.includes(q);
        tr.classList.toggle('filter-hidden', !match);
        if (match) visible++;
      });
      const section = tbl.closest('.grp');
      if (section) section.classList.toggle('section-empty', q !== '' && visible === 0);
    });
  });
}

// ----- Section: Profile summary (top-level scalars) -----
function buildSummarySection(profile) {
  const rows = [];
  const scalarKeys = ['testProfile', 'mergePolicyId', 'lastModifiedAt'];
  for (const k of scalarKeys) {
    if (k in profile) rows.push([k, profile[k]]);
  }
  if (profile.personalEmail?.address) {
    rows.push(['personalEmail.address', profile.personalEmail.address]);
  }
  // Any other top-level scalar that isn't one of the big structured blocks
  const SKIP = new Set(['identityMap', 'segmentMembership', 'frequencyMap', 'personalEmail']);
  for (const k of Object.keys(profile)) {
    if (SKIP.has(k) || k.startsWith('_') || scalarKeys.includes(k)) continue;
    const v = profile[k];
    if (v === null || typeof v !== 'object') {
      rows.push([k, v]);
    }
  }
  if (!rows.length) return '';
  return wrapGrp('blue', 'Profile summary', rows.length, kvTable(rows));
}

// ----- Section: Identities -----
function buildIdentitiesSection(profile) {
  const rows = [];
  const im = profile.identityMap;
  if (im && typeof im === 'object') {
    for (const ns of Object.keys(im)) {
      const arr = Array.isArray(im[ns]) ? im[ns] : [];
      for (const x of arr) {
        if (x && x.id != null) rows.push([ns, String(x.id), '']);
      }
    }
  }
  // Tenant identities
  for (const k of Object.keys(profile)) {
    if (!k.startsWith('_')) continue;
    const ti = profile[k]?.identities;
    if (ti && typeof ti === 'object') {
      for (const [ns, v] of Object.entries(ti)) {
        if (v != null) rows.push([ns, String(v), k]);
      }
    }
  }
  if (!rows.length) return '';
  const body = `
    <table class="grp-table profile-table">
      <thead>
        <tr><th>Namespace</th><th>ID</th><th>Source</th></tr>
      </thead>
      <tbody>
        ${rows.map(([ns, id, src]) => `
          <tr>
            <td class="col-key"><span class="id-ns">${escapeHtml(ns)}</span></td>
            <td class="col-val">${escapeHtml(id)}</td>
            <td class="col-val">${src ? `<code>${escapeHtml(src)}</code>` : '<span class="val-empty">identityMap</span>'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  return wrapGrp('teal', 'Identities', rows.length, body);
}

// ----- Section: Tenant attributes (flat leaf table, minus SCAs/identities) -----
function buildTenantAttributesSection(profile) {
  const tenantKeys = Object.keys(profile).filter((k) => k.startsWith('_'));
  if (!tenantKeys.length) return '';
  const rows = [];
  for (const tk of tenantKeys) {
    const obj = profile[tk];
    if (!obj || typeof obj !== 'object') continue;
    // Walk every key under the tenant EXCEPT the big structured blocks we
    // already break out into their own sections.
    for (const [subKey, subVal] of Object.entries(obj)) {
      if (subKey === 'SystemComputedAttributes') continue;
      if (subKey === 'identities') continue;
      const prefix = `${tk}.${subKey}`;
      flattenInto(subVal, prefix, rows);
    }
  }
  if (!rows.length) return '';
  return wrapGrp('purple', 'Tenant attributes', rows.length, kvTable(rows));
}

// ----- Section: System Computed Attributes -----
function buildSCASection(profile) {
  const tenantKeys = Object.keys(profile).filter((k) => k.startsWith('_'));
  const rows = [];
  for (const tk of tenantKeys) {
    const sca = profile[tk]?.SystemComputedAttributes;
    if (!sca || typeof sca !== 'object') continue;
    for (const [name, val] of Object.entries(sca)) {
      // Each SCA value is either an object {value, timestamp} OR an array of those.
      const entries = Array.isArray(val) ? val : [val];
      rows.push({ tenant: tk, name, entries });
    }
  }
  if (!rows.length) return '';

  // Sort each row's entries by newest timestamp first
  for (const r of rows) {
    r.entries = [...r.entries].sort((a, b) => {
      const ta = a?.timestamp ? Date.parse(a.timestamp) : 0;
      const tb = b?.timestamp ? Date.parse(b.timestamp) : 0;
      return tb - ta;
    });
  }
  rows.sort((a, b) => a.name.localeCompare(b.name));

  const body = `
    <table class="grp-table profile-table profile-table-sca">
      <thead>
        <tr><th>Attribute</th><th>Tenant</th><th>Values (newest first)</th></tr>
      </thead>
      <tbody>
        ${rows.map((r) => `
          <tr>
            <td class="col-key">${escapeHtml(r.name)} <span class="grp-count">${r.entries.length}</span></td>
            <td class="col-val"><code>${escapeHtml(r.tenant)}</code></td>
            <td class="col-val">
              <div class="sca-entries">
                ${r.entries.map((e) => {
                  const vals = Array.isArray(e?.value) ? e.value : (e?.value != null ? [e.value] : []);
                  const valHtml = vals.length
                    ? `<span class="sca-entry-vals">${vals.map((v) => `<span class="sca-val-chip">${escapeHtml(String(v))}</span>`).join('')}</span>`
                    : '<span class="val-empty">(empty)</span>';
                  const tsHtml = e?.timestamp ? `<span class="sca-ts">${escapeHtml(e.timestamp)}</span>` : '';
                  return `<div class="sca-entry">${valHtml}${tsHtml}</div>`;
                }).join('')}
              </div>
            </td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  return wrapGrp('coral', 'System Computed Attributes', rows.length, body);
}

// ----- Section: Segment Memberships -----
function buildSegmentsSection(profile) {
  const ups = profile.segmentMembership?.ups;
  if (!ups || typeof ups !== 'object') return '';
  const rows = Object.entries(ups).map(([id, info]) => ({
    id,
    status: info?.status || '',
    ts: info?.lastQualificationTime || ''
  }));
  if (!rows.length) return '';

  // Newest qualifications first
  rows.sort((a, b) => Date.parse(b.ts || 0) - Date.parse(a.ts || 0));

  const statusClass = (s) => {
    if (s === 'realized') return 'seg-status-realized';
    if (s === 'exited')   return 'seg-status-exited';
    if (s === 'existing') return 'seg-status-existing';
    return 'seg-status-other';
  };

  const body = `
    <table class="grp-table profile-table">
      <thead>
        <tr><th>Status</th><th>Segment ID</th><th>Last qualification</th></tr>
      </thead>
      <tbody>
        ${rows.map((r) => `
          <tr>
            <td class="col-key"><span class="seg-status ${statusClass(r.status)}">${escapeHtml(r.status || '—')}</span></td>
            <td class="col-val"><code>${escapeHtml(r.id)}</code></td>
            <td class="col-val">${escapeHtml(r.ts || '—')}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  return wrapGrp('amber', 'Segment memberships', rows.length, body);
}

// ----- Section: Frequency Map -----
function buildFrequencySection(profile) {
  const fm = profile.frequencyMap;
  if (!fm || typeof fm !== 'object') return '';
  const rows = Object.entries(fm).map(([id, info]) => ({
    id,
    value:  info?.value,
    expiry: info?.expiryDate || ''
  }));
  if (!rows.length) return '';

  const body = `
    <table class="grp-table profile-table">
      <thead>
        <tr><th>Frequency ID</th><th>Value</th><th>Expires</th></tr>
      </thead>
      <tbody>
        ${rows.map((r) => `
          <tr>
            <td class="col-key"><code>${escapeHtml(r.id)}</code></td>
            <td class="col-val"><span class="val-num">${escapeHtml(String(r.value ?? '—'))}</span></td>
            <td class="col-val">${escapeHtml(r.expiry || '—')}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  return wrapGrp('pink', 'Frequency map', rows.length, body);
}

// ----- Section: ALL attributes (flat) — catch-all so nothing is hidden -----
function buildFlatAllSection(profile) {
  const rows = [];
  flattenInto(profile, '', rows);
  if (!rows.length) return '';
  return wrapGrp('green', 'All attributes (flat)', rows.length, kvTable(rows), /* startCollapsed */ true);
}

// ----- Helpers -----

// Wrap a body in a collapsible .grp container that matches the existing
// conditions-view styling.
function wrapGrp(color, title, count, bodyHtml, startCollapsed) {
  return `
    <div class="grp grp-${color}${startCollapsed ? ' collapsed' : ''}">
      <div class="grp-head" data-toggle>
        <span class="grp-toggle">${startCollapsed ? '▶' : '▼'}</span>
        <span class="grp-title">${escapeHtml(title)}</span>
        <span class="grp-count">${count}</span>
      </div>
      <div class="grp-body">
        ${bodyHtml}
      </div>
    </div>
  `;
}

// Render a flat array of [key, value] (or [key, value, extra]) pairs as a
// two-column key/value table.
function kvTable(rows) {
  return `
    <table class="grp-table profile-table">
      <thead>
        <tr><th>Path</th><th>Value</th></tr>
      </thead>
      <tbody>
        ${rows.map(([k, v]) => `
          <tr>
            <td class="col-key">${formatKeyPath(k)}</td>
            <td class="col-val">${formatValue(v)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

// Walk an arbitrary value and push leaf entries [path, value] into `rows`.
// Arrays are expanded with [i] notation. Objects with timestamp+value are
// kept as compact "value @ timestamp" strings so SCAs read nicely.
function flattenInto(value, path, rows) {
  if (value === null || value === undefined) {
    rows.push([path || '(root)', value]);
    return;
  }
  if (Array.isArray(value)) {
    if (!value.length) { rows.push([path, '[]']); return; }
    value.forEach((item, i) => {
      flattenInto(item, `${path}[${i}]`, rows);
    });
    return;
  }
  if (typeof value === 'object') {
    // Compact rendering for {value, timestamp} pairs
    const keys = Object.keys(value);
    const isTsPair =
      keys.length <= 3 &&
      keys.includes('timestamp') &&
      (keys.includes('value') || keys.includes('expiryDate'));
    if (isTsPair) {
      const v = value.value !== undefined ? value.value : value.expiryDate;
      const vStr = Array.isArray(v) ? `[${v.map(String).join(', ')}]` : String(v);
      rows.push([path, `${vStr} @ ${value.timestamp}`]);
      return;
    }
    if (!keys.length) { rows.push([path, '{}']); return; }
    for (const k of keys) {
      flattenInto(value[k], path ? `${path}.${k}` : k, rows);
    }
    return;
  }
  rows.push([path || '(root)', value]);
}

// Render a dotted path like "_nordstrom.SystemComputedAttributes[0].value"
// with the trailing leaf segment emphasized.
function formatKeyPath(path) {
  const safe = escapeHtml(String(path || ''));
  const m = safe.match(/^(.*?)([^.\[\]]+)$/);
  if (!m || !m[1]) return safe;
  return `<span class="key-path">${m[1]}</span>${m[2]}`;
}

// Type-aware value rendering for the key/value tables.
function formatValue(v) {
  if (v === null)      return '<span class="val-null">null</span>';
  if (v === undefined) return '<span class="val-null">undefined</span>';
  if (typeof v === 'boolean') return `<span class="val-bool">${v}</span>`;
  if (typeof v === 'number')  return `<span class="val-num">${escapeHtml(String(v))}</span>`;
  if (typeof v === 'string') {
    if (v === '') return '<span class="val-empty">(empty string)</span>';
    return `<span class="val-str">${escapeHtml(v)}</span>`;
  }
  // Fallback for any compact object/array that slipped through
  try { return `<code>${escapeHtml(JSON.stringify(v))}</code>`; }
  catch (_) { return escapeHtml(String(v)); }
}

// =============================================================
// Column resize — drag the boundary between the two columns
// =============================================================

const COL_RESIZE_STORAGE_KEY = 'colGrouplabelWidthPct';
const COL_RESIZE_MIN = 15;
const COL_RESIZE_MAX = 60;

function installColumnResizers(container) {
  container.querySelectorAll('th.col-grouplabel').forEach((th) => {
    if (th.querySelector('.col-resize-handle')) return;  // already installed
    const handle = document.createElement('span');
    handle.className = 'col-resize-handle';
    handle.title = 'Drag to resize columns';
    th.appendChild(handle);
    handle.addEventListener('mousedown', (e) => startColResize(e, handle, container));
  });
}

let _colResizeState = null;
function startColResize(ev, handle, container) {
  ev.preventDefault();
  ev.stopPropagation();
  // Anchor on the table this handle lives in to compute the % offset
  const table = handle.closest('table');
  if (!table) return;
  const rect = table.getBoundingClientRect();
  _colResizeState = {
    container,
    handle,
    tableLeft: rect.left,
    tableWidth: rect.width
  };
  handle.classList.add('resizing');
  document.body.classList.add('col-resizing');
  document.addEventListener('mousemove', onColResizeMove);
  document.addEventListener('mouseup', stopColResize, { once: true });
}

function onColResizeMove(ev) {
  if (!_colResizeState) return;
  const { container, tableLeft, tableWidth } = _colResizeState;
  let pct = ((ev.clientX - tableLeft) / tableWidth) * 100;
  pct = Math.max(COL_RESIZE_MIN, Math.min(COL_RESIZE_MAX, pct));
  applyColumnWidth(container, pct);
}

function stopColResize() {
  if (!_colResizeState) return;
  _colResizeState.handle.classList.remove('resizing');
  document.body.classList.remove('col-resizing');
  document.removeEventListener('mousemove', onColResizeMove);
  // Persist the final width
  const pct = parseFloat(_colResizeState.container.style.getPropertyValue('--col-grouplabel-width'));
  if (!isNaN(pct) && chrome?.storage?.local) {
    chrome.storage.local.set({ [COL_RESIZE_STORAGE_KEY]: pct });
  }
  _colResizeState = null;
}

function applyColumnWidth(container, pct) {
  container.style.setProperty('--col-grouplabel-width', pct + '%');
  container.style.setProperty('--col-detail-width', (100 - pct) + '%');
}

// Restore the saved column width on startup
async function restoreColumnWidth() {
  if (!chrome?.storage?.local) return;
  try {
    const { [COL_RESIZE_STORAGE_KEY]: saved } = await chrome.storage.local.get([COL_RESIZE_STORAGE_KEY]);
    if (typeof saved === 'number' && saved >= COL_RESIZE_MIN && saved <= COL_RESIZE_MAX) {
      const container = $('#conditionsView');
      if (container) applyColumnWidth(container, saved);
    }
  } catch (_) {}
}

// Node types we render as their own card. Anything else (start, end, timer,
// segmentTrigger followers like 'wait', etc.) is treated as a "transit" node
// that the flow passes through but doesn't get its own card.
const RENDERABLE_TYPES = new Set(['event', 'condition', 'segmentTrigger', 'action', 'message', 'campaign', 'timer']);

// Fixed color per non-condition type. Conditions get cycled colors per-label.
const TYPE_COLORS = {
  event:          'blue',
  segmentTrigger: 'green',
  action:         'amber',
  message:        'pink',
  campaign:       'pink',  // inline-campaign delivery — same family as message
  timer:          'teal'
};

// Short chip label and per-row unit shown in each card's header
const TYPE_META = {
  event:          { chip: 'EVENT',     unit: 'detail',   unitPlural: 'details' },
  condition:      { chip: 'CONDITION', unit: 'branch',   unitPlural: 'branches' },
  segmentTrigger: { chip: 'AUDIENCE',  unit: 'detail',   unitPlural: 'details' },
  action:         { chip: 'ACTION',    unit: 'param',    unitPlural: 'params' },
  message:        { chip: 'EMAIL',     unit: 'detail',   unitPlural: 'details' },
  campaign:       { chip: 'CAMPAIGN',  unit: 'detail',   unitPlural: 'details' },
  timer:          { chip: 'TIMER',     unit: 'setting',  unitPlural: 'settings' }
};

// Hook for future type remapping (e.g. distinguishing channel sub-variants).
// Returns the type to use for the chip label and TYPE_META lookup.
// Currently a passthrough — kept as an explicit function so call sites stay
// consistent if/when subtype-based remapping comes back.
function effectiveType(node) {
  return node.type;
}

// Walk the journey graph from start and return renderable nodes in flow
// order. Falls back to JSON order for orphans.
function orderRenderableByFlow(nodes, edges) {
  const nodeById = new Map(nodes.map((n) => [n.id, n]));
  const outgoing = new Map();
  for (const e of edges) {
    if (!e || !e.source || !e.target) continue;
    const sid = e.source.elementId;
    const tid = e.target.elementId;
    if (!outgoing.has(sid)) outgoing.set(sid, []);
    outgoing.get(sid).push(tid);
  }

  const visited = new Set();
  const order = [];

  function dfs(rootId) {
    const stack = [rootId];
    while (stack.length) {
      const id = stack.pop();
      if (visited.has(id) || !nodeById.has(id)) continue;
      visited.add(id);
      const node = nodeById.get(id);
      if (RENDERABLE_TYPES.has(node.type)) order.push(node);
      const outs = outgoing.get(id) || [];
      for (let i = outs.length - 1; i >= 0; i--) stack.push(outs[i]);
    }
  }

  const startNode = nodes.find((n) => n.type === 'start');
  if (startNode) dfs(startNode.id);

  // Catch any renderable nodes not reachable from start
  for (const n of nodes) {
    if (RENDERABLE_TYPES.has(n.type) && !visited.has(n.id)) {
      order.push(n);
      visited.add(n.id);
    }
  }

  return order;
}

// Kept for backwards-compat in case anything imports it
function orderConditionsByFlow(nodes, edges) {
  return orderRenderableByFlow(nodes, edges).filter((n) => n.type === 'condition');
}

// =============================================================
// Cross-card references (predecessor / successor links)
// =============================================================

// Returns the "activity name" — the role/template label AJO shows under the
// title on its canvas card. Different from node.data.label (the user-given
// specific name). For example for a segmentTrigger, this is "Read audience";
// for a custom action it's the template name like "j1_AJO_to_AWS_Payload_Prod";
// for a message it's "Email". Returns '' when it doesn't add info beyond
// the title (e.g., when it matches the title verbatim).
function getActivityName(node) {
  if (!node) return '';
  const title = node.data?.label || node.label || node.type;
  if (!node.label || node.label === title) return '';
  return node.label;
}

// BFS through the journey graph to find the nearest renderable node downstream
// from `startNode`. `renderedIdSet` is the set of node ids that have their own
// card. Returns { target, via: [bypassed nodes] } or null.
function findDownstreamRendered(startNode, allNodes, edges, renderedIdSet) {
  if (!startNode || renderedIdSet.size === 0) return null;
  if (renderedIdSet.has(startNode.id)) return { target: startNode, via: [] };
  const visited = new Set([startNode.id]);
  const queue = [{ node: startNode, via: [startNode] }];
  while (queue.length) {
    const { node, via } = queue.shift();
    const outs = edges.filter((e) => e.source && e.source.elementId === node.id);
    for (const e of outs) {
      if (!e.target) continue;
      const nextId = e.target.elementId;
      if (visited.has(nextId)) continue;
      visited.add(nextId);
      const nextNode = allNodes.find((n) => n.id === nextId);
      if (!nextNode) continue;
      if (renderedIdSet.has(nextId)) return { target: nextNode, via };
      queue.push({ node: nextNode, via: [...via, nextNode] });
    }
  }
  return null;
}

// Render a single predecessor/successor reference. If the referenced node has
// its own card, render a clickable link with a #N badge. For successor refs to
// non-rendered nodes, walk forward and add a transitive "↳ jumps to" link.
function renderRef(node, arrow, kind, currentNodeId, nodeIndex, allNodes, edges) {
  if (!node) return '';
  const lbl = node.data?.label || node.label || node.type;
  const eyebrow = getActivityName(node)
    ? `<div class="ref-eyebrow">${escapeHtml(getActivityName(node))}</div>`
    : '';
  const renderedIdSet = new Set(nodeIndex.keys());
  const pos = nodeIndex.get(node.id);

  if (pos != null && node.id !== currentNodeId) {
    return `<div class="cell-${kind} has-link">${eyebrow}<a class="cond-link" href="#cond-${node.id}" data-jump="${node.id}" title="Jump to #${pos}">${arrow} ${escapeHtml(lbl)}<span class="link-badge">#${pos}</span></a></div>`;
  }

  if (kind === 'target') {
    const found = findDownstreamRendered(node, allNodes, edges, renderedIdSet);
    if (found && found.target.id !== currentNodeId && nodeIndex.has(found.target.id)) {
      const targetPos = nodeIndex.get(found.target.id);
      const targetLabel = found.target.data?.label || found.target.label || found.target.type;
      const targetEyebrow = getActivityName(found.target)
        ? `<div class="ref-eyebrow">${escapeHtml(getActivityName(found.target))}</div>`
        : '';
      const viaLabels = found.via.map((n) => n.data?.label || n.label || n.type);
      const viaText = viaLabels.length
        ? `bypasses ${viaLabels.length} node${viaLabels.length === 1 ? '' : 's'}: ${viaLabels.join(' → ')}`
        : '';
      const title = `Jumps to #${targetPos}${viaText ? ' — ' + viaText : ''}`;
      return `<div class="cell-${kind}">${eyebrow}${arrow} ${escapeHtml(lbl)}</div>
        <div class="cell-${kind} via-link has-link">${targetEyebrow}<a class="cond-link" href="#cond-${found.target.id}" data-jump="${found.target.id}" title="${escapeHtml(title)}">↳ ${escapeHtml(targetLabel)}<span class="link-badge">#${targetPos}</span></a></div>`;
    }
  }

  return `<div class="cell-${kind}">${eyebrow}${arrow} ${escapeHtml(lbl)}</div>`;
}

// =============================================================
// Per-type row builders — what each card's table rows look like.
// Each row: { name, expr, description? }
// =============================================================

function buildAudienceRows(data) {
  const rows = [];
  const segmentId = data.segment?.id;
  const deepLink = (currentAjoBaseUrl && segmentId)
    ? `${currentAjoBaseUrl}/journey-optimizer/platform/segment/browse/${segmentId}/detail`
    : null;

  if (data.segment?.name) rows.push({ name: 'audience',   expr: data.segment.name, deepLink });
  if (segmentId)          rows.push({ name: 'segment id', expr: segmentId,        deepLink });
  if (data.namespaceId)   rows.push({ name: 'namespace',  expr: data.namespaceId });
  if (data.label && data.label !== data.segment?.name) {
    rows.push({ name: 'label', expr: data.label });
  }
  if (data.throttlingRatePerSec != null) {
    rows.push({ name: 'throttling/sec', expr: String(data.throttlingRatePerSec) });
  }
  if (typeof data.isMultipleReentrance === 'boolean') {
    rows.push({ name: 'multi reentrance', expr: String(data.isMultipleReentrance) });
  }
  if (typeof data.deltaIsOn === 'boolean') {
    rows.push({ name: 'delta on', expr: String(data.deltaIsOn) });
  }
  return rows.length ? rows : [{ name: 'audience', expr: '—' }];
}

function buildActionRows(data) {
  // Dataset lookup actions don't use paramMappings — they have their own
  // lookupKeys expression plus lookup metadata. Surface all of it.
  if (data.actionType === 'datasetLookup') {
    const rows = [];
    const expr = data.lookupKeys?.plainText || '';
    if (expr) {
      rows.push({
        name: 'lookup keys',
        expr,
        description: data.lookupKeys?.dataType ? `returns ${data.lookupKeys.dataType}` : undefined
      });
    }
    // Which fields the lookup returns
    const paths = Array.isArray(data.fieldPaths) ? data.fieldPaths : [];
    if (paths.length) {
      rows.push({ name: 'field paths', expr: paths.join('\n') });
    }
    // Lookup metadata
    if (data.datasetName) {
      rows.push({
        name: 'dataset',
        expr: data.datasetName,
        description: data.datasetId ? `id: ${data.datasetId}` : undefined
      });
    }
    if (data.schemaName) {
      rows.push({ name: 'schema', expr: data.schemaName });
    }
    if (data.label && data.label !== 'Product Lookup' && data.label !== data.datasetName) {
      rows.push({ name: 'label', expr: data.label });
    }
    if (data.description) {
      rows.push({ name: 'description', expr: data.description });
    }
    if (data.fallbackOnTimeoutOrError) {
      rows.push({ name: 'fallback on error', expr: 'true' });
    }
    return rows.length ? rows : [{ name: 'datasetLookup', expr: '—' }];
  }

  // Custom / regular actions — walk paramMappings as before, but also tag
  // optional and bring along childFields metadata as a description so the
  // structure under "items"/etc. isn't lost.
  const params = data.paramMappings || [];
  const rows = params.map((p) => {
    const expr = (p.parameterizedExpression && p.parameterizedExpression.plainText)
              || p.stringExpression
              || '';
    const labelOrPath = p.label || p.paramPath || 'param';
    const descParts = [];
    if (p.paramPath && p.paramPath !== p.label) descParts.push(p.paramPath);
    if (p.optionalMapping) descParts.push('optional');
    if (p.dataType) descParts.push(`type: ${p.dataType}`);
    if (Array.isArray(p.childFields) && p.childFields.length) {
      const children = p.childFields
        .map((c) => `${c.key || c.label}${c.value ? ' → ' + c.value : ''}`)
        .join(', ');
      descParts.push(`children: ${children}`);
    }
    return {
      name: labelOrPath,
      expr,
      description: descParts.length ? descParts.join(' · ') : undefined
    };
  });
  if (!rows.length) {
    if (data.label)       rows.push({ name: 'label',       expr: data.label });
    if (data.description) rows.push({ name: 'description', expr: data.description });
  }
  return rows.length ? rows : [{ name: 'action', expr: data.actionType || '—' }];
}

// Timer nodes — either a custom PQL expression or a fixed delay duration.
function buildTimerRows(data) {
  const rows = [];
  const expr = data.parameterizedExpression?.plainText || '';
  if (expr) {
    rows.push({ name: 'expression', expr, description: data.type ? `type: ${data.type}` : undefined });
  }
  if (data.delay) {
    rows.push({
      name: 'delay',
      expr: data.delay,
      description: formatIsoDuration(data.delay)
    });
  }
  if (data.timezone) rows.push({ name: 'timezone', expr: data.timezone });
  if (data.label && data.label !== 'Wait') {
    rows.push({ name: 'label', expr: data.label });
  }
  if (!rows.length) {
    rows.push({ name: 'timer', expr: data.type || '—' });
  }
  return rows;
}

// "PT3M" → "3 minutes" etc. — best-effort, falls back silently if it doesn't parse.
function formatIsoDuration(s) {
  if (typeof s !== 'string' || !s.startsWith('PT')) return undefined;
  const m = s.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!m) return undefined;
  const parts = [];
  if (m[1]) parts.push(`${m[1]} hour${m[1] === '1' ? '' : 's'}`);
  if (m[2]) parts.push(`${m[2]} minute${m[2] === '1' ? '' : 's'}`);
  if (m[3]) parts.push(`${m[3]} second${m[3] === '1' ? '' : 's'}`);
  return parts.join(' ');
}

// Event nodes — the qualifier (eventId etc.) and any related metadata.
// Takes both `data` and `node` because the friendly event name typically
// lives on `node.label` (e.g. "Nordstrom_Product_Detail") while `data.label`
// is usually empty.
function buildEventRows(data, node) {
  const rows = [];
  const friendlyName = node?.label || data?.label;
  if (friendlyName)       rows.push({ name: 'event name',   expr: friendlyName });
  if (data.description)   rows.push({ name: 'description',  expr: data.description });
  if (data.eventCategory) rows.push({ name: 'category',     expr: data.eventCategory });
  if (node?.subtype && node.subtype !== data.eventCategory) {
    rows.push({ name: 'subtype', expr: node.subtype });
  }
  if (data.uid)           rows.push({ name: 'event uid',    expr: data.uid });
  if (data.eventId) {
    // eventId is a long sha256-style hash — display full but mark as identifier
    rows.push({ name: 'event id', expr: data.eventId, description: 'XDM event schema identifier (hash)' });
  }
  if (data.timeout != null) rows.push({ name: 'timeout', expr: String(data.timeout) });
  return rows.length ? rows : [{ name: 'event', expr: '—' }];
}

function buildMessageRows(data) {
  const rows = [];
  if (data.label)       rows.push({ name: 'label',       expr: data.label });
  if (data.description && data.description !== data.label) {
    rows.push({ name: 'description', expr: data.description });
  }
  if (data.category)  rows.push({ name: 'category',   expr: data.category });
  if (data.channel)   rows.push({ name: 'channel',    expr: data.channel });
  if (data.surfaceId) rows.push({ name: 'surface id', expr: data.surfaceId });
  if (data.messageId) rows.push({ name: 'message id', expr: data.messageId });
  const channelOverrides = data.channelOverrides || [];
  for (const co of channelOverrides) {
    const e = (co.expression && co.expression.plainText) || '';
    const lbl = `${co.name || 'override'}${co.channel ? ' (' + co.channel + ')' : ''}`;
    rows.push({ name: lbl, expr: e });
  }
  if (data.trackingOptions) {
    const t = data.trackingOptions;
    const flags = [];
    if (t.clickTrackingEnabled) flags.push('click');
    if (t.openTrackingEnabled)  flags.push('open');
    rows.push({ name: 'tracking', expr: flags.length ? flags.join(', ') : 'none' });
  }
  if (typeof data.sendTimeOptimizationIsOn === 'boolean') {
    rows.push({ name: 'STO', expr: String(data.sendTimeOptimizationIsOn) });
  }
  return rows.length ? rows : [{ name: 'email', expr: '—' }];
}

// =============================================================
// Renderers — dispatcher + per-type
// =============================================================

function renderJourneyNode(node, index, color, allNodes, edges, nodeIndex) {
  if (node.type === 'condition') {
    return renderConditionNode(node, index, color, allNodes, edges, nodeIndex);
  }
  return renderOtherNode(node, index, color, allNodes, edges, nodeIndex);
}

function renderOtherNode(node, index, color, allNodes, edges, nodeIndex) {
  const type = node.type;
  const chipType = effectiveType(node);
  const meta = TYPE_META[chipType] || { chip: type.toUpperCase(), unit: 'detail', unitPlural: 'details' };
  const label = node.data?.label || node.label || node.name || type;
  const shortId = node.id.slice(0, 8);

  // Predecessor nodes
  const incomingNodes = edges
    .filter((e) => e.target && e.target.elementId === node.id)
    .map((e) => allNodes.find((n) => n.id === e.source.elementId))
    .filter(Boolean);

  // Primary successor (excluding timeout/error edges)
  const outEdges = edges.filter((e) => e.source && e.source.elementId === node.id);
  const mainOutEdges = outEdges.filter((e) => e.type !== 'timeout_error');
  const timeoutEdge = outEdges.find((e) => e.type === 'timeout_error');
  const primaryTarget = mainOutEdges[0]
    ? allNodes.find((n) => n.id === mainOutEdges[0].target.elementId)
    : null;
  const timeoutTarget = timeoutEdge
    ? allNodes.find((n) => n.id === timeoutEdge.target.elementId)
    : null;

  const rows = (function () {
    const data = node.data || {};
    switch (type) {
      case 'event':          return buildEventRows(data, node);
      case 'segmentTrigger': return buildAudienceRows(data);
      case 'action':         return buildActionRows(data);
      case 'message':        return buildMessageRows(data);
      case 'campaign':       return buildMessageRows(data);  // same data shape as message
      case 'timer':          return buildTimerRows(data);
      default:               return [{ name: 'label', expr: data.label || node.label || '' }];
    }
  })();

  const predecessorHtml = incomingNodes
    .map((n) => renderRef(n, '↑', 'pred', node.id, nodeIndex, allNodes, edges))
    .join('');
  const successorHtml = primaryTarget
    ? renderRef(primaryTarget, '→', 'target', node.id, nodeIndex, allNodes, edges)
    : '';
  const timeoutHtml = timeoutTarget
    ? `<div class="cell-target timeout-target" title="Timeout / error fallback">⚠ timeout/error → ${escapeHtml(timeoutTarget.data?.label || timeoutTarget.label || timeoutTarget.type)}</div>`
    : '';

  const subtypeStr = node.subtype ? `${type}/${node.subtype}` : type;

  return `
    <div class="grp grp-${color} grp-type-${type}" data-cond-id="${node.id}" id="cond-${node.id}">
      <div class="grp-head" data-toggle="1">
        <span class="grp-toggle" aria-hidden="true">▼</span>
        <span class="grp-idx">${index}</span>
        <div class="grp-title-stack">
          ${getActivityName(node) ? `<div class="grp-activity">${escapeHtml(getActivityName(node))}</div>` : ''}
          <div class="grp-title">${escapeHtml(label)}</div>
        </div>
        <span class="grp-type-chip type-${chipType}">${escapeHtml(meta.chip)}</span>
        <span class="grp-count">${rows.length} ${rows.length === 1 ? meta.unit : meta.unitPlural}</span>
        <span class="grp-id" title="${escapeHtml(subtypeStr)} node id">${escapeHtml(shortId)}</span>
      </div>
      <div class="grp-body">
        <table class="grp-table">
          <thead>
            <tr>
              <th class="col-grouplabel">group label</th>
              <th class="col-detail">name &amp; value</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((r, i) => `
              <tr>
                <td class="col-grouplabel">
                  ${i === 0 ? predecessorHtml : ''}
                  ${i === 0 ? `<div class="cell-grouplabel">${escapeHtml(label)}</div>` : ''}
                  ${i === rows.length - 1 ? successorHtml + timeoutHtml : ''}
                </td>
                <td class="col-detail">
                  <div class="kv-row">
                    <code class="kv-key">${escapeHtml(r.name)}</code>
                    <span class="kv-val-wrap">
                      ${r.expr
                        ? `<pre class="expr-code expr-inline">${highlightExpr(reformatExpr(String(r.expr)))}</pre>`
                        : `<span class="expr-empty">—</span>`}
                      ${r.deepLink
                        ? `<a class="deep-link" href="${escapeHtml(r.deepLink)}" target="_blank" rel="noopener" title="Open in AJO Segment view">↗ AJO</a>`
                        : ''}
                      ${r.expr
                        ? `<button class="copy-expr-btn" type="button" data-expr="${escapeHtml(String(r.expr))}" title="Copy to clipboard">copy</button>`
                        : ''}
                    </span>
                  </div>
                  ${r.description ? `<div class="kv-desc">${escapeHtml(r.description)}</div>` : ''}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderConditionNode(cond, index, color, allNodes, edges, nodeIndex) {
  const branches = (cond.data && cond.data.conditions) || [];
  const label = cond.data?.label || cond.label || 'Untitled condition';
  const shortId = cond.id.slice(0, 8);
  const meta = TYPE_META.condition;

  // Upstream nodes that feed into THIS condition (same for every branch row)
  const incomingNodes = edges
    .filter((e) => e.target && e.target.elementId === cond.id)
    .map((e) => allNodes.find((n) => n.id === e.source.elementId))
    .filter(Boolean);

  const predecessorHtml = incomingNodes
    .map((n) => renderRef(n, '↑', 'pred', cond.id, nodeIndex, allNodes, edges))
    .join('');

  const rows = branches.map((b) => {
    const edge = edges.find((e) =>
      e.source && e.source.elementId === cond.id &&
      (e.id === b.uid || e.identifier === b.uid)
    );
    const target = edge ? allNodes.find((n) => n.id === edge.target.elementId) : null;
    const expr = (b.parameterizedExpression && b.parameterizedExpression.plainText)
              || b.expression || '';
    return {
      name: b.name || b.label || 'Branch',
      expr,
      isOpposite: b.conditionType === 'opposite',
      conditionType: b.conditionType || 'condition',
      target,
      description: b.description
    };
  });

  return `
    <div class="grp grp-${color} grp-type-condition" data-cond-id="${cond.id}" id="cond-${cond.id}">
      <div class="grp-head" data-toggle="1">
        <span class="grp-toggle" aria-hidden="true">▼</span>
        <span class="grp-idx">${index}</span>
        <div class="grp-title-stack">
          ${getActivityName(cond) ? `<div class="grp-activity">${escapeHtml(getActivityName(cond))}</div>` : ''}
          <div class="grp-title">${escapeHtml(label)}</div>
        </div>
        <span class="grp-type-chip type-condition">${escapeHtml(meta.chip)}</span>
        <span class="grp-count">${rows.length} ${rows.length === 1 ? meta.unit : meta.unitPlural}</span>
        <span class="grp-id" title="condition node id">${escapeHtml(shortId)}</span>
      </div>
      <div class="grp-body">
        <table class="grp-table">
          <thead>
            <tr>
              <th class="col-grouplabel">group label</th>
              <th class="col-detail">name &amp; expression</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map((r) => {
              const successorHtml = renderRef(r.target, '→', 'target', cond.id, nodeIndex, allNodes, edges);
              return `
              <tr class="${r.isOpposite ? 'row-opposite' : ''}">
                <td class="col-grouplabel">
                  ${predecessorHtml}
                  <div class="cell-grouplabel">${escapeHtml(label)}</div>
                  ${successorHtml}
                </td>
                <td class="col-detail">
                  <code class="cell-name">${escapeHtml(r.name)}</code>
                  ${r.expr
                    ? `<div class="expr-wrap"><pre class="expr-code">${highlightExpr(reformatExpr(r.expr))}</pre><button class="copy-expr-btn" type="button" data-expr="${escapeHtml(String(r.expr))}" title="Copy to clipboard">copy</button></div>${r.description ? `<div class="expr-desc">${escapeHtml(r.description)}</div>` : ''}`
                    : `<span class="expr-opposite">[opposite]</span>${r.description ? `<div class="expr-desc">${escapeHtml(r.description)}</div>` : ''}`}
                </td>
              </tr>
            `;}).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// =============================================================
// Expression reformatter — normalize tabs/whitespace, re-indent by depth,
// and wrap long single-line expressions on `(` and `,`.
// =============================================================

function reformatExpr(expr) {
  if (!expr) return '';
  let text = String(expr).replace(/\r\n/g, '\n').replace(/\t/g, '  ');
  text = text.split('\n')
    .map((l) => l.replace(/[ \t]+$/, ''))
    .filter((l) => l.trim().length > 0)
    .join('\n');
  if (text.length < 80 && !text.includes('\n')) return text.trim();
  if (!text.includes('\n')) text = insertBreaks(text);
  return reindentByDepth(text);
}

function findMatchClose(s, start) {
  const openCh = s[start];
  const closeCh = openCh === '(' ? ')' : openCh === '{' ? '}' : openCh === '[' ? ']' : '';
  if (!closeCh) return -1;
  let d = 1, inStr = false, strCh = '';
  for (let i = start + 1; i < s.length; i++) {
    const c = s[i];
    if (inStr) {
      if (c === strCh && s[i - 1] !== '\\') inStr = false;
      continue;
    }
    if (c === '"' || c === "'") { inStr = true; strCh = c; continue; }
    if (c === '(' || c === '{' || c === '[') d++;
    else if (c === ')' || c === '}' || c === ']') {
      d--;
      if (d === 0 && c === closeCh) return i;
    }
  }
  return -1;
}

function insertBreaks(line) {
  const out = [];
  const mlStack = [];
  let i = 0, inStr = false, strCh = '';

  while (i < line.length) {
    const ch = line[i];
    if (inStr) {
      out.push(ch);
      if (ch === strCh && line[i - 1] !== '\\') inStr = false;
      i++; continue;
    }
    if (ch === '"' || ch === "'") {
      inStr = true; strCh = ch;
      out.push(ch); i++; continue;
    }

    if (ch === '(' || ch === '{' || ch === '[') {
      const matchIdx = findMatchClose(line, i);
      const groupLen = matchIdx > 0 ? matchIdx - i : 0;
      const innerHasParen = matchIdx > 0 && line.slice(i + 1, matchIdx).includes('(');
      const shouldBreak = (ch === '{')
        ? (groupLen > 50 && innerHasParen)
        : (groupLen > 50);

      out.push(ch);
      mlStack.push(shouldBreak);
      if (shouldBreak) {
        out.push('\n');
        while (line[i + 1] === ' ') i++;
      }
      i++; continue;
    }

    if (ch === ')' || ch === '}' || ch === ']') {
      const wasMl = mlStack.pop();
      if (wasMl) out.push('\n');
      out.push(ch);
      i++; continue;
    }

    if (ch === ',') {
      const enclosingMl = mlStack[mlStack.length - 1];
      out.push(',');
      if (enclosingMl) {
        out.push('\n');
        while (line[i + 1] === ' ') i++;
      }
      i++; continue;
    }

    out.push(ch);
    i++;
  }
  return out.join('');
}

function reindentByDepth(text) {
  const INDENT = '  ';
  const lines = text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
  const out = [];
  let depth = 0;

  for (const line of lines) {
    let leadingClose = 0;
    for (const ch of line) {
      if (ch === ')' || ch === '}' || ch === ']') leadingClose++;
      else break;
    }
    out.push(INDENT.repeat(Math.max(0, depth - leadingClose)) + line);

    let net = 0, inStr = false, strCh = '';
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inStr) {
        if (ch === strCh && line[i - 1] !== '\\') inStr = false;
        continue;
      }
      if (ch === '"' || ch === "'") { inStr = true; strCh = ch; continue; }
      if (ch === '(' || ch === '{' || ch === '[') net++;
      if (ch === ')' || ch === '}' || ch === ']') net--;
    }
    depth = Math.max(0, depth + net);
  }
  return out.join('\n');
}

// =============================================================
// PQL syntax highlighting
// =============================================================

// PQL syntax highlighting. Tokenizer-based so string content and HTML
// entities don't get mangled by overlapping regexes.
const HL_KEYWORDS  = new Set(['count', 'and', 'or', 'not', 'toDateTime', 'in', 'exists']);
const HL_CONSTS    = new Set(['true', 'false', 'null']);
const HL_FUNCTIONS = new Set([
  'matchRegExp', 'inAudience', 'nowWithDelta', 'currentTimeInMillis',
  'currentDataPackField', 'ExperiencePlatform', 'ProfileFieldGroup',
  'all', 'any'
]);

function highlightExpr(expr) {
  if (!expr) return '';
  const TOKEN_RX = /("[^"]*"|'[^']*')|(@event\{[^}]+\})|(#\{[^}]+\})|(\$\{[^}]+\})|(-?\d+(?:\.\d+)?)|([A-Za-z_][A-Za-z_0-9]*)|(==|!=|>=|<=|>|<)/g;
  const out = [];
  let lastIdx = 0;
  let m;
  while ((m = TOKEN_RX.exec(expr)) !== null) {
    // Plain text between tokens — escape only, no highlighting
    if (m.index > lastIdx) out.push(escapeHtml(expr.slice(lastIdx, m.index)));

    const [, str, event, fldHash, fldVar, num, word, op] = m;
    if (str) {
      out.push(`<span class="str">${escapeHtml(str)}</span>`);
    } else if (event) {
      out.push(`<span class="fld">${escapeHtml(event)}</span>`);
    } else if (fldHash) {
      // Recursively highlight the content INSIDE #{...} so nested
      // functions/keywords/strings still get colored.
      const inner = fldHash.slice(2, -1);
      out.push(`<span class="fld-hash">#{${highlightExpr(inner)}}</span>`);
    } else if (fldVar) {
      out.push(`<span class="fld-var">${escapeHtml(fldVar)}</span>`);
    } else if (num) {
      out.push(`<span class="num">${escapeHtml(num)}</span>`);
    } else if (word) {
      if (HL_CONSTS.has(word))         out.push(`<span class="const">${word}</span>`);
      else if (HL_KEYWORDS.has(word))  out.push(`<span class="kw">${word}</span>`);
      else if (HL_FUNCTIONS.has(word)) out.push(`<span class="fn">${word}</span>`);
      else                             out.push(escapeHtml(word));
    } else if (op) {
      out.push(`<span class="op">${escapeHtml(op)}</span>`);
    }
    lastIdx = TOKEN_RX.lastIndex;
  }
  if (lastIdx < expr.length) out.push(escapeHtml(expr.slice(lastIdx)));
  return out.join('');
}

// =============================================================
// Helpers
// =============================================================

function showStatus(msg, type) {
  const el = $('#status');
  el.textContent = msg;
  el.className = `status status-${type || 'info'}`;
}

function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

document.addEventListener('DOMContentLoaded', init);
