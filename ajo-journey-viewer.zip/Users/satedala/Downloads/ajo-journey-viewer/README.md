# AJO Journey Flow Viewer

Chrome MV3 side-panel extension that visualizes an Adobe Journey Optimizer journey as a flow diagram with the condition logic broken out side-by-side. Also renders **AEP profile JSON** as a set of grouped tables (identities, segments, system-computed attributes, frequency caps, and a flat catch-all).

## What it does

- Detects the **journey** and **version** UUIDs from the current AJO URL
- Pulls the **IMS token**, **client_id**, **org id**, and **sandbox** from page session/local storage
- Calls the AJO authoring API for the journey version JSON
- Renders three views in the side panel:
  - **Flow** — SVG diagram of every node and edge (start/event/timer/condition/action/campaign/end), color-coded by type, with pan/zoom
  - **Conditions** — every condition node broken out as a card with each branch's PQL expression syntax-highlighted, target node, and condition vs opposite badge
  - **Raw** — full pretty-printed JSON

Cards in the conditions view cover **every node type that carries an expression or configuration**:

| Type | What's shown |
|---|---|
| `event` | Friendly event name (from `node.label`), category, subtype, event uid, event id hash, description, timeout |
| `condition` | Every branch's PQL expression (resource + opposite) |
| `action` / `datasetLookup` | `lookupKeys` PQL, `fieldPaths`, dataset name + id, schema, fallback flag |
| `action` / `custom` | Every `paramMapping` — label, paramPath, expression, optional flag, dataType, childFields |
| `timer` | `parameterizedExpression` PQL (custom timers), `delay` with human-readable duration (`PT3M → 3 minutes`), timezone |
| `segmentTrigger` | Audience name, segment id, namespace, throttling, reentrance flags — with `↗ AJO` deep link to the segment browse page when running against an AJO tab |
| `message` | Label, category, channel, surface id, message id, channel overrides, tracking flags |
| `campaign` | Same fields as message (inline campaign delivery shares the message data shape) |

Click any node in the flow diagram to open a detail panel with that node's branches, paramMappings, datasetLookup fields, channel/surface info, etc.

## Profile view

Paste an **AEP profile JSON** (anything with `identityMap`, `segmentMembership`, or a tenant block like `_paypal` / `_nordstrom`) into the **Paste JSON** dialog. The viewer auto-detects it and renders these sections:

| Section | What's in it |
|---|---|
| **Profile summary** | Top-level scalars: `testProfile`, `mergePolicyId`, `lastModifiedAt`, `personalEmail.address`, and any other top-level primitives |
| **Identities** | Every entry from `identityMap` plus tenant-level `identities` (e.g. `_nordstrom.identities.enterpriseId`), namespace badge + ID + source |
| **Tenant attributes** | Flat dotted paths under each `_tenant` block (`store.*`, `loyalty.*`, `preferences.*`, etc.) — excludes SCAs and identities since those have their own sections |
| **System Computed Attributes** | One row per SCA, with all timestamped value entries stacked newest-first as chips + ISO timestamps |
| **Segment memberships** | Every `segmentMembership.ups` entry with a colored realized/exited badge, segment GID, and last-qualification timestamp |
| **Frequency map** | Each `frequencyMap` entry with current value and expiry |
| **All attributes (flat)** | Catch-all — every leaf in the JSON flattened to a dotted path. Starts collapsed. Use this if you want to confirm nothing is hidden. |

A live filter input at the top of the profile view searches across every row in every section.

## Install

1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → select this folder
3. Open an AJO journey in the browser (`https://experience.adobe.com/#/.../journey-optimizer/journeys/journey/{id}/version/{id}/...`)
4. Click the extension's toolbar icon to open the side panel
5. Click **Load from tab**

## Settings

API credentials live in `settings.json`:

```json
{
  "apiKey":       "voyager_ui",
  "orgId":        "246B0A595411C35F0A4C98BC@AdobeOrg",
  "sandbox":      "dev",
  "apiBaseUrl":   "https://journey-private.adobe.io/authoring",
  "acceptHeader": "application/vnd.adobe.jo+json"
}
```

These get sent as `x-api-key`, `x-gw-ims-org-id`, and `x-sandbox-name` on every API request. Edit the file and reload the extension at `chrome://extensions` to change them. The active values are shown in a banner at the top of the side panel.

## URL handling

The extension extracts the UUID from either pattern in the URL:

- `…/version/{uuid}` — used directly to fetch the journey version
- `…/journey/{uuid}` — treated as a journey ID; the extension calls `/journeys/{id}` (and falls back to `/journeys/{id}/versions`) to resolve the latest version, then fetches that. If both lookups fail, the UUID is tried as a version ID directly.

## If the API call fails

Auth setups vary by tenant — the auto-extracted client_id may not match the API key your org uses for the authoring API. Use the **Paste JSON** button as a fallback: copy the JSON response from the Network tab in DevTools (the `journeyVersions/{uid}` request) and paste it in. Everything else (rendering, conditions breakdown, node detail) works the same.

## Troubleshooting

| Issue | Cause / Fix |
|---|---|
| "No journey/version ID in URL" | You're not on a journey version page. Open the journey in AJO first. |
| "No IMS token in session storage" | You're not signed into Adobe Experience Cloud in the active tab, or the token key naming differs. Try refreshing the AJO page. |
| "No org ID found" | Rare — the extension scans session/local storage for `*@AdobeOrg` and falls back to `window.adobeIMS`. If still missing, paste the JSON manually. |
| API returns 403 | The IMS token's client_id doesn't have AJO authoring scope. Paste JSON, or update `sidepanel.js` → `fetchJourney` to hardcode the right `x-api-key`. |
| Nodes overlap / hard to read | Use the zoom buttons (`+` / `−` / `Reset`). Default is `0.6×` because original AJO coords span ~2800×1075. |

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest, side panel + scripting permissions |
| `background.js` | Opens side panel on toolbar click |
| `sidepanel.html` | Layout with three tabs, node detail panel, paste modal |
| `sidepanel.css` | Navy theme, syntax highlight classes, all component styles |
| `flowRenderer.js` | SVG flow diagram (nodes + bezier edges + zoom/pan) |
| `sidepanel.js` | Token/context extraction, API fetch, condition breakdown, node detail |

## Notes

- No build step. Individual JS files load directly via `sidepanel.html`.
- No minified bundle (per deployment preference).
- Original AJO node coordinates are preserved — what you see matches the canvas layout, just scaled down.
