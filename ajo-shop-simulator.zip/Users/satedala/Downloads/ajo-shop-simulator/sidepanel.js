// ─────────────────────────────────────────────────────────────────────────────
// Adobe Journey Event Trigger — schema-driven side panel
//
// All sections, fields, events and payloads come from settings.json. This file
// is a generic renderer + form-state manager. To add a new section / event /
// field, edit settings.json — no code changes needed here.
// ─────────────────────────────────────────────────────────────────────────────

const TE = window.TemplateEngine; // from template-engine.js

const STORAGE_KEYS = {
  shopperId: "njoEvent.shopperId",
  profile:   "njoEvent.lastProfile",
};

let SETTINGS = null;

// Per-section state: { [sectionId]: { selectedEventId, values: {...} } }
const state = {};

// Cache of the last loaded events list (used by the tracking-filter toggle).
let _lastEvents = [];

// Cached last-loaded audiences and the source profile so the search inputs
// can re-render filtered views on every keystroke without re-fetching from
// AEP. SCA renders from the profile shape so we hold a reference to that
// rather than the extracted block.
let _lastAudiences = [];
let _lastProfile = null;

// Live sandbox name pulled from the active Adobe tab. Drives:
//   • the shortcut bar URLs
//   • the Fire button labels ("Fire on Dev" / "Fire on Nonprod" / "Fire on Prod")
//   • the toast banner that announces sandbox switches
// Starts null so the first refresh (with whatever the live tab is) counts as
// the initial paint, not a "switched from X to Y" event.
let currentSandbox = null;
let currentTenant  = null;

document.addEventListener("DOMContentLoaded", async () => {
  await loadSettings();
  renderShortcutBar();
  renderDynamicSections();
  wireShopperBar();
  wireProfileCopy();
  wireIOCopy();
  wireShowTrackingToggle();
  wireProfileFilters();
  await restorePersistedState();

  // Now that sections (and their Fire buttons) exist in the DOM, do the
  // first context fetch — this paints the Fire buttons with the right
  // sandbox label without the "Fire Event" → "Fire on Dev" flash that an
  // earlier call would cause.
  refreshSandboxContext({ silent: true });

  // Listen for tab/window changes so the panel re-syncs whenever the user
  // switches between Adobe tabs in different sandboxes.
  setupTabWatchers();
});

async function loadSettings() {
  try {
    const res = await fetch(chrome.runtime.getURL("settings.json"));
    SETTINGS = await res.json();
  } catch (e) {
    console.error("Failed to load settings.json:", e);
    SETTINGS = { sections: [] };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shortcut bar
// — Buttons appear instantly using settings.json defaults so the panel is
// usable from t=0, then URLs upgrade in place once the live Adobe tab
// context resolves via refreshSandboxContext().
// ─────────────────────────────────────────────────────────────────────────────
function renderShortcutBar() {
  // First pass: settings defaults. Live values arrive via refreshShortcutBar
  // once getContext resolves.
  refreshShortcutBar(
    SETTINGS.tenant  || "@nordstrom",
    SETTINGS.sandbox || "prod",
  );
}

function refreshShortcutBar(tenant, sandbox) {
  const bar = document.getElementById("shortcut-bar");
  if (!bar) return;

  // SVG icons — clear purpose-built glyphs with a short label underneath
  const ICONS = {
    "Journeys": {
      title: "Journeys",
      label: "Journeys",
      svg: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="2.5" cy="8" r="1.5" fill="currentColor"/><circle cx="8" cy="3" r="1.5" fill="currentColor"/><circle cx="13.5" cy="11" r="1.5" fill="currentColor"/><path d="M4 8C4 8 5.5 8 6.5 5.5C7.5 3 8 3 8 3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><path d="M8 3C8 3 9.5 3 10.5 7C11.5 11 13.5 11 13.5 11" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`
    },
    "Audiences": {
      title: "Audiences",
      label: "Audiences",
      svg: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="6" cy="5.5" r="2" stroke="currentColor" stroke-width="1.3"/><path d="M2 13c0-2.2 1.8-4 4-4s4 1.8 4 4" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><circle cx="12" cy="5.5" r="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M13 13c0-1.8-1-3.2-2.5-3.7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`
    },
    "Query": {
      title: "Query Editor",
      label: "Query",
      svg: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="12" height="12" rx="2" stroke="currentColor" stroke-width="1.3"/><path d="M5 6.5l2 2-2 2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.5 10.5h2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`
    },
    "Profile": {
      title: "Profile",
      label: "Profile",
      svg: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="5.5" r="2.5" stroke="currentColor" stroke-width="1.3"/><path d="M3 14c0-2.8 2.2-5 5-5s5 2.2 5 5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`
    },
  };

  const children = [];

  if (Array.isArray(SETTINGS.shortcuts)) {
    const base = TE.tplStr(SETTINGS.shortcutsBaseUrl || "", { tenant, sandbox });
    SETTINGS.shortcuts.forEach((sc) => {
      const ic = ICONS[sc.label] || { svg: "", title: sc.label, label: sc.label };
      const a = document.createElement("a");
      a.className = "shortcut-icon-btn";
      a.href = base + (sc.path || "");
      a.target = "_blank";
      a.rel = "noopener";
      a.title = ic.title;
      a.innerHTML = `${ic.svg}<span class="shortcut-icon-label">${ic.label}</span>`;
      children.push(a);
    });
  }

  // Auth Token copy button
  const tokenBtn = document.createElement("button");
  tokenBtn.type = "button";
  tokenBtn.className = "shortcut-icon-btn shortcut-icon-token";
  tokenBtn.id = "shortcut-token-btn";
  tokenBtn.title = "Copy Auth Token";
  tokenBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="6.5" cy="6.5" r="2.5" stroke="currentColor" stroke-width="1.3"/><path d="M8.5 8.5L13 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M11 12l1.5 1" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg><span class="shortcut-icon-label">Token</span>`;
  tokenBtn.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    let token = null;
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          for (let i = 0; i < sessionStorage.length; i++) {
            const k = sessionStorage.key(i);
            if (k && k.startsWith("adobeid_ims_access_token")) {
              try { return JSON.parse(sessionStorage.getItem(k))?.tokenValue || null; } catch(e) {}
            }
          }
          return null;
        }
      });
      token = res?.result;
    } catch(e) {}
    if (!token) { _shortcutToast(tokenBtn, "⚠ Not found"); return; }
    try {
      await navigator.clipboard.writeText(token);
      _shortcutToast(tokenBtn, "✓");
    } catch(e) { _shortcutToast(tokenBtn, "⚠ Failed"); }
  });
  children.push(tokenBtn);

  bar.replaceChildren(...children);
}

function _shortcutToast(btn, msg) {
  const orig = btn.textContent;
  btn.textContent = msg;
  setTimeout(() => { btn.textContent = orig; }, 1800);
}

// ─────────────────────────────────────────────────────────────────────────────
// Live sandbox context — single source of truth
// ─────────────────────────────────────────────────────────────────────────────
// Called on load, on tab activation, and on tab URL changes. Asks the
// background for the live Adobe-tab context (tenant + sandbox), then:
//   1) refreshes shortcut bar URLs
//   2) updates every Fire button label to match the sandbox
//   3) if the sandbox actually changed (and silent=false), shows a toast
//
// silent:true on first call so we don't flash a "switched to dev" toast on
// the initial paint.
async function refreshSandboxContext({ silent = false } = {}) {
  let tenant, sandbox;
  try {
    const ctx = await chrome.runtime.sendMessage({ action: "getContext" });
    if (ctx?.ok && ctx.context) {
      tenant  = ctx.context.tenant  || SETTINGS.tenant  || "@nordstrom";
      sandbox = ctx.context.sandbox || SETTINGS.sandbox || "prod";
    } else {
      // No Adobe tab open — fall back to settings defaults, but don't toast.
      tenant  = SETTINGS.tenant  || "@nordstrom";
      sandbox = SETTINGS.sandbox || "prod";
      silent = true;
    }
  } catch {
    tenant  = SETTINGS.tenant  || "@nordstrom";
    sandbox = SETTINGS.sandbox || "prod";
    silent = true;
  }

  const prevSandbox = currentSandbox;
  currentSandbox = sandbox;
  currentTenant  = tenant;

  refreshShortcutBar(tenant, sandbox);
  updateFireButtonLabels(sandbox);

  if (!silent && prevSandbox && prevSandbox !== sandbox) {
    showSandboxToast(prevSandbox, sandbox);
  }
}

// Walks every Fire (submit) button currently in the DOM and rewrites its
// label + prod styling. Called whenever sections re-render or the sandbox
// changes. Skips buttons that are mid-fire (label === "Firing..." with the
// spinner) so we don't clobber the in-progress UI state.
function updateFireButtonLabels(sandbox) {
  const label = `Fire on ${capitalize(sandbox || "Dev")}`;
  const isProd = /^prod(uction)?$/i.test(String(sandbox || "").trim());

  for (const btn of document.querySelectorAll('button[data-role="submit"]')) {
    // If the button is currently showing "Firing..." (has the spinner span),
    // skip it — the active fire() handler captured origLabel and will
    // restore. We rely on it picking up the new label on the *next* render.
    if (btn.querySelector(".spinner")) continue;
    btn.textContent = label;
    btn.classList.toggle("is-prod", isProd);
  }
}

function capitalize(s) {
  s = String(s || "");
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : "";
}

// Slide-down banner announcing a sandbox switch. Auto-dismisses after ~4s.
// Reuses the same red treatment as the identity card when moving into prod.
function showSandboxToast(prev, next) {
  const el = document.getElementById("sandbox-toast");
  if (!el) return;
  const isProd = /^prod(uction)?$/i.test(next);
  el.classList.toggle("is-prod", isProd);
  el.textContent = isProd
    ? `⚠ Switched to ${capitalize(next)} — events fire to live`
    : `Switched: ${capitalize(prev)} → ${capitalize(next)}`;
  // Force a reflow so the transition fires on consecutive toasts.
  el.classList.remove("is-visible");
  void el.offsetWidth;
  el.classList.add("is-visible");

  clearTimeout(showSandboxToast._t);
  // Prod gets a longer dwell since it's a "pay attention" moment.
  showSandboxToast._t = setTimeout(() => el.classList.remove("is-visible"), isProd ? 6000 : 3500);
}

// ─────────────────────────────────────────────────────────────────────────────
// Tab event watchers — refresh the sandbox context whenever the user
// switches between or updates Adobe tabs. Debounced because URL changes can
// burst (multi-step navigation inside the Adobe shell).
// ─────────────────────────────────────────────────────────────────────────────
function setupTabWatchers() {
  let pending = null;
  const trigger = () => {
    if (pending) clearTimeout(pending);
    pending = setTimeout(() => { pending = null; refreshSandboxContext(); }, 250);
  };

  if (chrome?.tabs?.onActivated) {
    chrome.tabs.onActivated.addListener(trigger);
  }
  if (chrome?.tabs?.onUpdated) {
    // Only care about URL changes on experience.adobe.com tabs.
    chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
      if (!tab?.url || !tab.url.startsWith("https://experience.adobe.com")) return;
      if (changeInfo.url || changeInfo.status === "complete") trigger();
    });
  }
  if (chrome?.windows?.onFocusChanged) {
    chrome.windows.onFocusChanged.addListener((winId) => {
      if (winId !== chrome.windows.WINDOW_ID_NONE) trigger();
    });
  }

  // Also re-check when the user re-focuses the side panel itself (e.g.
  // tabs.onUpdated may have been suppressed while the panel was hidden).
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) trigger();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Section rendering — from settings
// ─────────────────────────────────────────────────────────────────────────────
function renderDynamicSections() {
  const host = document.getElementById("dynamic-sections");
  host.replaceChildren();
  for (const section of SETTINGS.sections || []) {
    // Hidden sections — used by the Shop simulator extension to keep event
    // payload configs in settings.json (so the Shop tab's dispatch can find
    // them by id via the existing fireEvent flow) without exposing the
    // low-level form UI to end users.
    if (section.hidden) continue;
    const sectionEl = renderSection(section);
    // Attach the section to the live DOM BEFORE rendering fields, so the
    // `[data-role="fields"]` host element is queryable. Otherwise the initial
    // field render bails out with `host == null` and the user has to click
    // Reset to see fields.
    host.appendChild(sectionEl);
    // Shop sections don't have a fields[] block to render — they manage
    // their own DOM in renderShopSection.
    if (section.type !== "shop") renderFieldsForSection(section.id);
  }
}

function renderSection(section) {
  // Shop section is a special UI — no event form, no fields. Renders a
  // shopping simulator that calls into existing event sections via fireEvent.
  if (section.type === "shop") return renderShopSection(section);

  state[section.id] = state[section.id] || { selectedEventId: null, values: {} };
  // Auto-select the first event in every section so the form has a sensible
  // default — fields render immediately, no "click Reset to see anything" wart.
  // Sections can opt out with "autoSelectFirst": false.
  if (!state[section.id].selectedEventId
      && section.events.length > 0
      && section.autoSelectFirst !== false) {
    state[section.id].selectedEventId = section.events[0].id;
    applyEventDefaults(section.id, section.events[0]);
  }

  const details = document.createElement("details");
  details.className = "io-section";
  details.id = `section-${section.id}`;
  if (section.openByDefault) details.open = true;

  const summary = document.createElement("summary");
  summary.innerHTML = `
    <span class="section-title">${escapeHtml(section.title)}</span>
    <span class="io-status empty" id="status-${section.id}">ready</span>
  `;
  details.appendChild(summary);

  const block = document.createElement("div");
  block.className = "io-block";

  // Event chips (only shown when more than one event)
  if (section.events.length > 1) {
    const chipsWrap = document.createElement("div");
    chipsWrap.className = "form-group";
    chipsWrap.innerHTML = `<label>Event Type</label>`;
    const row = document.createElement("div");
    row.className = "chips-row";
    row.dataset.role = "event-chips";
    row.dataset.section = section.id;
    chipsWrap.appendChild(row);
    block.appendChild(chipsWrap);
    refreshEventChips(section, row);
  }

  // Field forms
  const fieldsHost = document.createElement("div");
  fieldsHost.dataset.role = "fields";
  fieldsHost.dataset.section = section.id;
  block.appendChild(fieldsHost);

  // Per-section alert slot — validation + fire-event status messages render
  // here (right above the submit row) so the user sees them in context
  // instead of glancing back up to the top of the panel.
  const alertSlot = document.createElement("div");
  alertSlot.className = "section-alert";
  alertSlot.id = `alert-${section.id}`;
  block.appendChild(alertSlot);

  // Submit row
  const btnGroup = document.createElement("div");
  btnGroup.className = "button-group";
  btnGroup.innerHTML = `
    <button type="button" class="btn btn-secondary" data-role="reset" data-section="${section.id}">Reset</button>
    <button type="button" class="btn btn-primary"   data-role="submit" data-section="${section.id}">${escapeHtml(section.submitLabel || "Fire on Dev")}</button>
  `;
  block.appendChild(btnGroup);

  details.appendChild(block);

  // Wire events
  details.addEventListener("click", (e) => {
    const chip = e.target.closest('button.chip-btn[data-event-id]');
    if (chip && chip.dataset.section === section.id) {
      selectEvent(section.id, chip.dataset.eventId);
      return;
    }
    const role = e.target.closest("button[data-role]")?.dataset.role;
    const sec = e.target.closest("button[data-role]")?.dataset.section;
    if (sec !== section.id) return;
    if (role === "reset")  resetSection(section.id);
    if (role === "submit") submitSection(section.id);
  });

  // Fields are rendered by the caller (renderDynamicSections / resetSection)
  // *after* the section has been attached to the live DOM, so that the
  // `[data-role="fields"]` element is queryable. Doing it here would either
  // require passing the host element through or fail silently.
  return details;
}

// Pre-populate context with event defaults — used on initial auto-select and
// on event-chip clicks. Only fills empty slots, so user-typed values win.
function applyEventDefaults(sectionId, event) {
  if (!event?.defaults) return;
  for (const [k, v] of Object.entries(event.defaults)) {
    const resolved = resolveDefault(v);
    const cur = state[sectionId].values[k];
    if (cur == null || cur === "" || (Array.isArray(cur) && cur.length === 0)) {
      state[sectionId].values[k] = resolved;
    }
  }
}

function refreshEventChips(section, row) {
  row.replaceChildren(...section.events.map((ev) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip-btn" + (state[section.id].selectedEventId === ev.id ? " active" : "");
    b.dataset.eventId = ev.id;
    b.dataset.section = section.id;
    b.textContent = ev.label || ev.id;
    return b;
  }));
}

function selectEvent(sectionId, eventId) {
  state[sectionId].selectedEventId = eventId;
  const section = sectionDef(sectionId);
  const event = section.events.find((e) => e.id === eventId);
  // Apply event defaults into values (only for empty slots).
  applyEventDefaults(sectionId, event);
  // Re-render chip active state + fields.
  const sectionDetails = document.getElementById(`section-${sectionId}`);
  const chipRow = sectionDetails?.querySelector('[data-role="event-chips"]');
  if (chipRow) refreshEventChips(section, chipRow);
  renderFieldsForSection(sectionId);
  // Switching events makes any previous validation/fire message stale.
  setSectionAlert(sectionId, "");
}

// Resolve a default that may be a placeholder ({nowISO}, {generateOrderNumber})
// or a literal/list. Arrays of items pass through (items keep their structure).
function resolveDefault(value) {
  if (Array.isArray(value)) {
    return value.map((it) => {
      if (typeof it !== "object" || !it) return it;
      const out = {};
      for (const [k, v] of Object.entries(it)) out[k] = resolveDefault(v);
      return out;
    });
  }
  if (typeof value === "string") {
    const m = /^\{(\w+)\}$/.exec(value);
    if (m) return TE.runGenerator(m[1]) || value;
    return value;
  }
  return value;
}

function sectionDef(sectionId) {
  return SETTINGS.sections.find((s) => s.id === sectionId);
}

function currentEvent(sectionId) {
  const sec = sectionDef(sectionId);
  return sec.events.find((e) => e.id === state[sectionId].selectedEventId);
}

// Decide which fields are visible: section defines all possible fields. If an
// event specifies `fields` (whitelist), only those + always-visible ones show.
// Special types (shopperId-ref, etc.) are always visible. `hideFields` from the
// event takes them away.
function visibleFields(section, event) {
  const allFields = section.fields || [];
  if (!event) return allFields;
  const eventFields = event.fields;
  const hide = new Set(event.hideFields || []);
  return allFields.filter((f) => {
    if (hide.has(f.id)) return false;
    // Settings-driven gating: each field can declare a `showWhen` predicate
    // such as { "event": "CUSTOMER_RETAIL_TRANSACTION" } or
    // { "eventIn": ["A", "B"] }. The field only shows when the rule matches.
    if (!matchesShowWhen(f.showWhen, event)) return false;
    // Always-visible structural field types regardless of event whitelist.
    if (["shopperId-ref", "time", "items-list", "chip-row", "journey-autofill"].includes(f.type)) return true;
    // Required fields always show.
    if (f.required) return true;
    // If this event has a whitelist, only show fields in it.
    if (Array.isArray(eventFields)) return eventFields.includes(f.id);
    // No whitelist → show by default.
    return true;
  });
}

// Evaluate a field's `showWhen` predicate against the currently selected
// event. Returns true when there's no predicate, when the event matches the
// single `event` id, or when it's in the `eventIn` array.
function matchesShowWhen(predicate, event) {
  if (!predicate) return true;
  if (typeof predicate.event === "string" && predicate.event !== event?.id) return false;
  if (Array.isArray(predicate.eventIn) && !predicate.eventIn.includes(event?.id)) return false;
  return true;
}

function renderFieldsForSection(sectionId) {
  const section = sectionDef(sectionId);
  const event = currentEvent(sectionId);
  const host = document.querySelector(`[data-role="fields"][data-section="${sectionId}"]`);
  if (!host) return;
  host.replaceChildren();
  for (const field of visibleFields(section, event)) {
    const node = renderField(sectionId, field, event);
    if (node) host.appendChild(node);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Field renderers
// ─────────────────────────────────────────────────────────────────────────────
function renderField(sectionId, field, event) {
  // shopperId-ref binds to the top-bar shopperId input — render nothing here.
  if (field.type === "shopperId-ref") return null;

  // Apply event-specific overrides (e.g. PDV relabels SKU Items).
  const fld = { ...field };
  const ov = event?.fieldOverrides?.[field.id];
  if (ov) Object.assign(fld, ov);

  switch (fld.type) {
    case "text":              return renderTextField(sectionId, fld);
    case "time":              return renderTimeField(sectionId, fld);
    case "select":            return renderSelectField(sectionId, fld);
    case "chip-row":          return renderChipRowField(sectionId, fld);
    case "chip-radio":        return renderChipRadioField(sectionId, fld);
    case "items-list":        return renderItemsListField(sectionId, fld, event);
    case "journey-autofill":  return renderJourneyAutofillField(sectionId, fld);
    default:
      console.warn("Unknown field type:", fld.type, fld);
      return null;
  }
}

function renderTextField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);

  const inputWrap = fld.generator ? Object.assign(document.createElement("div"), { className: "input-with-btn" }) : null;
  const inp = document.createElement("input");
  inp.type = "text";
  inp.placeholder = fld.placeholder || "";
  inp.value = state[sectionId].values[fld.id] || "";
  inp.dataset.fieldId = fld.id;
  // Readonly fields are visually distinct but still editable on click — the
  // intent is "auto-filled but you can override." Removing readonly on focus
  // lets the user click in and type a custom value.
  if (fld.readonly) {
    inp.classList.add("input-readonly");
    inp.readOnly = true;
    inp.addEventListener("focus", () => { inp.readOnly = false; });
    inp.addEventListener("blur",  () => { inp.readOnly = true; });
    inp.title = fld.help || "Auto-filled — click to override";
  }
  inp.addEventListener("input", () => { state[sectionId].values[fld.id] = inp.value; });

  if (inputWrap) {
    inputWrap.appendChild(inp);
    const genBtn = document.createElement("button");
    genBtn.type = "button";
    genBtn.textContent = "Generate";
    genBtn.addEventListener("click", () => {
      const v = TE.runGenerator(fld.generator) || "";
      inp.value = v;
      state[sectionId].values[fld.id] = v;
    });
    inputWrap.appendChild(genBtn);
    wrap.appendChild(inputWrap);
  } else {
    wrap.appendChild(inp);
  }

  // Help text under readonly fields explaining the auto-fill behavior.
  if (fld.help) {
    const help = document.createElement("div");
    help.className = "field-help";
    help.textContent = fld.help;
    wrap.appendChild(help);
  }
  return wrap;
}

// "Detect from current journey" control — when clicked, asks the background
// to resolve the active journey (journeyId, name, type, eventUid) and fans
// the values out into the related read-only inputs on the same section.
// Auto-fires once on first render so the form is pre-filled when the user
// opens the section while sitting on a journey tab.
function renderJourneyAutofillField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group journey-autofill";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || "Journey context";
  wrap.appendChild(lbl);

  const row = document.createElement("div");
  row.className = "input-with-btn";

  const status = document.createElement("input");
  status.type = "text";
  status.readOnly = true;
  status.classList.add("input-readonly");
  status.placeholder = "Click Detect to pull from current tab";
  status.value = state[sectionId].values._journeyStatus || "";

  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Detect";

  // Pulls the journey context, splays the values into sibling inputs by
  // their field id (eventUid, sourceJourney*, correlationId), and records
  // them in the section state so a re-render preserves them.
  const detect = async ({ overwrite = false } = {}) => {
    btn.disabled = true;
    btn.textContent = "Detecting…";
    status.value = "";
    try {
      const r = await chrome.runtime.sendMessage({ action: "getJourneyContext" });
      if (!r?.ok) throw new Error(r?.error || "Detection failed");
      const j = r.result;

      // apply(id, value):
      //  - overwrite=false (initial auto-detect): only fill blanks, never
      //    stomp values the user already typed
      //  - overwrite=true  (manual re-detect): replace whatever's in the
      //    field with the freshly resolved value (because the user is
      //    explicitly asking for a refresh, e.g. after navigating to a
      //    different journey in the same tab)
      const apply = (id, value) => {
        const existing = state[sectionId].values[id];
        if (!overwrite && existing) return;
        if (value == null || value === "") return;
        state[sectionId].values[id] = value;
        const inp = wrap.parentElement?.querySelector(`input[data-field-id="${id}"]`);
        if (inp) inp.value = value;
      };
      apply("eventUid", j.eventUid);
      apply("sourceJourneyVersionId", j.journeyId);
      apply("correlationId", j.journeyId);
      apply("sourceJourneyName", j.journeyName);
      apply("sourceJourneyType", j.journeyType);

      const label = j.journeyName ? `${j.journeyName}` : j.journeyId;
      status.value = `✓ ${label}`;
      status.title = `Journey ID: ${j.journeyId}\nEvent UID: ${j.eventUid}${j.journeyType ? `\nType: ${j.journeyType}` : ""}`;
      state[sectionId].values._journeyStatus = status.value;
    } catch (e) {
      status.value = `✗ ${e.message}`;
      status.title = "";
      state[sectionId].values._journeyStatus = status.value;
    } finally {
      btn.disabled = false;
      // Switch the button label after the first successful detection so
      // it's obvious that clicking again will pull fresh values.
      btn.textContent = state[sectionId].values._journeyStatus?.startsWith("✓")
        ? "Re-detect"
        : "Detect";
    }
  };
  // Manual click → force-refresh mode. Useful when the user navigates the
  // AJO tab to a different journey and wants the form to follow.
  btn.addEventListener("click", () => detect({ overwrite: true }));

  row.append(status, btn);
  wrap.appendChild(row);

  if (fld.help) {
    const help = document.createElement("div");
    help.className = "field-help";
    help.textContent = fld.help;
    wrap.appendChild(help);
  }

  // Auto-detect once when the field first mounts — user opens the section,
  // values pre-fill. Subsequent renders (e.g. event-switch) skip auto-fire
  // since status is already cached in section state. Auto-detect uses
  // non-overwrite mode so anything the user already typed survives.
  if (!state[sectionId].values._journeyStatus) {
    // Defer so the rest of the form mounts first and apply() can find the
    // sibling inputs.
    setTimeout(() => detect({ overwrite: false }), 0);
  } else if (state[sectionId].values._journeyStatus.startsWith("✓")) {
    // Restore the friendly button label on re-render.
    btn.textContent = "Re-detect";
  }
  return wrap;
}

function renderTimeField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);
  const inputWrap = document.createElement("div");
  inputWrap.className = "input-with-btn";
  const inp = document.createElement("input");
  inp.type = "text";
  inp.placeholder = fld.placeholder || "ISO 8601 timestamp";
  // Default to "now" if not set
  if (!state[sectionId].values[fld.id]) {
    state[sectionId].values[fld.id] = fld.default === "{nowISO}" ? TE.nowISO() : (resolveDefault(fld.default) || TE.nowISO());
  }
  inp.value = state[sectionId].values[fld.id];
  inp.addEventListener("input", () => { state[sectionId].values[fld.id] = inp.value; });
  const nowBtn = document.createElement("button");
  nowBtn.type = "button";
  nowBtn.textContent = "Now";
  nowBtn.addEventListener("click", () => {
    const now = TE.nowISO();
    inp.value = now;
    state[sectionId].values[fld.id] = now;
  });
  inputWrap.append(inp, nowBtn);
  wrap.appendChild(inputWrap);
  return wrap;
}

function renderSelectField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);
  const sel = document.createElement("select");
  for (const opt of fld.options || []) {
    const o = document.createElement("option");
    o.value = opt.value;
    o.textContent = opt.label;
    sel.appendChild(o);
  }
  sel.value = state[sectionId].values[fld.id] || "";
  sel.addEventListener("change", () => { state[sectionId].values[fld.id] = sel.value; });
  wrap.appendChild(sel);
  return wrap;
}

function renderChipRowField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);
  const row = document.createElement("div");
  row.className = "chips-row";
  for (const opt of fld.options || []) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip-btn" + (state[sectionId].values[fld.id] === opt.value ? " active" : "");
    b.textContent = opt.label;
    b.dataset.value = opt.value;
    b.addEventListener("click", () => {
      state[sectionId].values[fld.id] = opt.value;
      for (const c of row.children) c.classList.toggle("active", c.dataset.value === opt.value);
    });
    row.appendChild(b);
  }
  wrap.appendChild(row);
  return wrap;
}

function renderChipRadioField(sectionId, fld) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);
  const row = document.createElement("div");
  row.className = "chips-row";
  // Default to the first option if not yet set.
  if (state[sectionId].values[fld.id] == null && fld.options?.length) {
    state[sectionId].values[fld.id] = fld.options[0].value;
  }
  for (const opt of fld.options || []) {
    const label = document.createElement("label");
    label.className = "chip-radio";
    const r = document.createElement("input");
    r.type = "radio";
    r.name = `${sectionId}-${fld.id}`;
    r.value = opt.value;
    r.checked = state[sectionId].values[fld.id] === opt.value;
    r.addEventListener("change", () => { state[sectionId].values[fld.id] = opt.value; });
    label.append(r, Object.assign(document.createElement("span"), { textContent: opt.label }));
    row.appendChild(label);
  }
  wrap.appendChild(row);
  return wrap;
}

function renderItemsListField(sectionId, fld, event) {
  const wrap = document.createElement("div");
  wrap.className = "form-group";
  const lbl = document.createElement("label");
  lbl.textContent = fld.label || fld.id;
  wrap.appendChild(lbl);

  // Pick which item shape to use, in order of preference:
  //   1. New `variants` array — each entry has its own `events` list and
  //      `itemFields`. Lets multiple events (BAG, PDV, …) each define their
  //      own column layout without forking the whole field.
  //   2. Legacy `richItemFields` + `richWhen.event` — preserved so older
  //      configs that only special-cased one event still work.
  //   3. Default `itemFields` — used by all events that didn't match above.
  const eventId = state[sectionId].selectedEventId;
  let cols = fld.itemFields;
  if (Array.isArray(fld.variants)) {
    const match = fld.variants.find((v) => Array.isArray(v.events) && v.events.includes(eventId));
    if (match && Array.isArray(match.itemFields)) cols = match.itemFields;
  } else if (fld.richItemFields && fld.richWhen?.event === eventId) {
    cols = fld.richItemFields;
  }

  // Ensure value slot exists.
  if (!Array.isArray(state[sectionId].values[fld.id])) {
    state[sectionId].values[fld.id] = [];
  }
  const rows = state[sectionId].values[fld.id];

  const list = document.createElement("div");
  list.className = "items-list";

  function rerender() {
    list.replaceChildren(...rows.map((row, idx) => makeItemRow(row, idx, cols, () => {
      rows.splice(idx, 1);
      rerender();
    })));
  }

  function makeItemRow(row, idx, cols, onRemove) {
    const r = document.createElement("div");
    r.className = "items-row";

    for (const col of cols) {
      const inp = document.createElement("input");
      inp.type = "text";
      inp.placeholder = col.placeholder || col.id;
      inp.value = row[col.id] || "";
      inp.addEventListener("input", () => { row[col.id] = inp.value; });
      r.appendChild(inp);
      if (col.type === "time") {
        const nowBtn = document.createElement("button");
        nowBtn.type = "button";
        nowBtn.className = "row-now-btn";
        nowBtn.textContent = "Now";
        nowBtn.addEventListener("click", () => {
          row[col.id] = TE.nowISO();
          rerender();
        });
        r.appendChild(nowBtn);
      }
    }

    const rm = document.createElement("button");
    rm.type = "button";
    rm.className = "row-remove-btn";
    rm.textContent = "×";
    rm.addEventListener("click", onRemove);
    r.appendChild(rm);
    return r;
  }

  rerender();
  wrap.appendChild(list);

  // For a simple single-column SKU input list, we keep a quick "type and add"
  // input below as a convenience. For multi-column rows we just expose +Add.
  if (cols.length === 1) {
    const addRow = document.createElement("div");
    addRow.className = "input-with-btn";
    const inp = document.createElement("input");
    inp.type = "text";
    inp.placeholder = cols[0].placeholder || `Enter ${fld.label}`;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "Add";
    function add() {
      const v = inp.value.trim();
      if (!v) return;
      rows.push({ [cols[0].id]: v });
      inp.value = "";
      rerender();
    }
    btn.addEventListener("click", add);
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); add(); } });
    addRow.append(inp, btn);
    wrap.appendChild(addRow);
  } else {
    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.className = "add-row-btn";
    addBtn.textContent = "+ Add Row";
    addBtn.addEventListener("click", () => {
      const empty = {};
      for (const c of cols) empty[c.id] = c.type === "time" ? TE.nowISO() : "";
      rows.push(empty);
      rerender();
    });
    wrap.appendChild(addBtn);
  }

  return wrap;
}

// ─────────────────────────────────────────────────────────────────────────────
// Reset / submit
// ─────────────────────────────────────────────────────────────────────────────
function resetSection(sectionId) {
  state[sectionId] = { selectedEventId: null, values: {} };
  const section = sectionDef(sectionId);
  // Same auto-select-first behaviour as initial render — Reset and load should
  // leave the section in the same visible state.
  if (section.events.length > 0 && section.autoSelectFirst !== false) {
    state[sectionId].selectedEventId = section.events[0].id;
    applyEventDefaults(sectionId, section.events[0]);
  }
  const sectionDetails = document.getElementById(`section-${sectionId}`);
  const chipRow = sectionDetails?.querySelector('[data-role="event-chips"]');
  if (chipRow) refreshEventChips(section, chipRow);
  renderFieldsForSection(sectionId);
  setSectionAlert(sectionId, "");
}

async function submitSection(sectionId) {
  const submitBtn = document.querySelector(`button[data-role="submit"][data-section="${sectionId}"]`);
  const statusEl = document.getElementById(`status-${sectionId}`);
  const setStatus = (label, klass) => {
    statusEl.textContent = label;
    statusEl.className = "io-status " + (klass || "empty");
  };

  // Clear any leftover alert from a previous attempt before we begin.
  setSectionAlert(sectionId, "");

  submitBtn.disabled = true;
  const origLabel = submitBtn.textContent;
  submitBtn.innerHTML = '<span class="spinner"></span> Firing...';

  try {
    const section = sectionDef(sectionId);
    const eventId = state[sectionId].selectedEventId;
    if (!eventId) { setSectionAlert(sectionId, "Please select an event", "error"); return; }
    const event = section.events.find((e) => e.id === eventId);

    // Gather context: section values, plus shopperId from the top bar.
    const context = { ...state[sectionId].values };
    const shopperId = document.getElementById("shopperId").value.trim();
    if (shopperId) context.shopperId = shopperId;

    // Required-field validation.
    const visibleIds = new Set(visibleFields(section, event).map((f) => f.id));
    for (const f of section.fields || []) {
      if (!visibleIds.has(f.id)) continue;
      if (f.required && !context[f.id]) {
        setSectionAlert(sectionId, `Please fill in ${f.label || f.id}`, "error");
        return;
      }
    }

    // Profile-derived values (enterpriseId, customerProfileId).
    // Convenience auto-fill: pull from the cached profile, but ONLY when the
    // user left the field blank. A typed value always wins — important for
    // any future "I want to override what's on the profile" workflow.
    if (Array.isArray(event.requiresFromProfile)) {
      for (const key of event.requiresFromProfile) {
        // User already supplied a value (via a form field) — respect it,
        // skip the profile lookup entirely.
        if (context[key]) continue;

        // Special case: customerProfileId is only required when the user
        // picked OPERATIONAL_CUSTOMER_PROFILE_ID. For the SHOPPER_ID variant
        // we use the shopperId directly.
        if (key === "customerProfileId" && context.customerIdType === "SHOPPER_ID") {
          continue;
        }

        const cached = await getCachedProfile();
        const val = digIdentity(cached, key);
        if (!val) {
          // Tailor the error to whether the user has an editable input for
          // this field, or whether it's pure profile-derived (no input at
          // all, like enterpriseId in AJO Qualification).
          const hasFormField = (section.fields || []).some(
            (f) => f.id === key && f.type !== "shopperId-ref"
          );
          const msg = hasFormField
            ? `${key} is empty — either fill it in or click View Profile to pull it from AEP.`
            : `Couldn't load ${key} — click View Profile first to load it from AEP.`;
          setSectionAlert(sectionId, msg, "error");
          return;
        }
        context[key] = val;
      }
    }

    // Fill in any missing time defaults (eventTime / systemTime / transactionTime).
    for (const f of section.fields || []) {
      if (f.type === "time" && !context[f.id]) context[f.id] = TE.nowISO();
    }

    // Fire via background.
    const response = await chrome.runtime.sendMessage({
      action: "fireEvent",
      sectionId,
      eventId,
      context,
    });

    const ioSection = document.getElementById("io-section");
    if (!response || !response.ok) {
      const errMsg = response?.error || "Fire failed";
      setSectionAlert(sectionId, errMsg, "error");
      setIO(response?.payload ?? context, response?.responseBody ?? errMsg,
            response?.status ? `HTTP ${response.status}` : "error", "err",
            response?.request);
      setStatus("error", "err");
      ioSection.open = true;
    } else {
      const result = response.result;
      setSectionAlert(sectionId, `✓ ${origLabel} succeeded — HTTP ${result.status}`, "success");
      setIO(result.payload, result.body, `HTTP ${result.status}`, "ok", result.request);
      setStatus(`HTTP ${result.status}`, "ok");
      ioSection.open = true;
    }
  } catch (err) {
    setSectionAlert(sectionId, "Error: " + err.message, "error");
    setStatus("error", "err");
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = origLabel;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shopper bar (top of panel)
// ─────────────────────────────────────────────────────────────────────────────
function wireShopperBar() {
  const inp = document.getElementById("shopperId");
  inp.addEventListener("input", () => {
    chrome.storage.local.set({ [STORAGE_KEYS.shopperId]: inp.value || "" }).catch(() => {});
  });
  document.getElementById("gen-shopper-btn")?.addEventListener("click", () => {
    inp.value = TE.runGenerator("generateShopperId");
    chrome.storage.local.set({ [STORAGE_KEYS.shopperId]: inp.value }).catch(() => {});
  });
  document.getElementById("view-profile-btn").addEventListener("click", viewProfile);
}

async function restorePersistedState() {
  try {
    const data = await chrome.storage.local.get([STORAGE_KEYS.shopperId, STORAGE_KEYS.profile]);
    const sid = data[STORAGE_KEYS.shopperId];
    if (sid) document.getElementById("shopperId").value = sid;
    const profile = data[STORAGE_KEYS.profile];
    if (profile) { renderProfile(profile); setProfileStatus("loaded (cached)", "ok"); }
  } catch (_) { /* ignore */ }
}

async function viewProfile() {
  const shopperId = document.getElementById("shopperId").value.trim();
  if (!shopperId) return showAlert("Enter a Shopper ID first", "error");
  const btn = document.getElementById("view-profile-btn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Loading...';
  setProfileStatus("loading", "empty");
  try {
    const response = await chrome.runtime.sendMessage({ action: "viewProfile", shopperId });
    if (!response.ok) {
      showAlert(response.error || "Profile fetch failed", "error");
      setProfileStatus("error", "err");
      return;
    }
    renderProfile(response.result);
    chrome.storage.local.set({ [STORAGE_KEYS.profile]: response.result }).catch(() => {});
    setProfileStatus("loaded", "ok");
    document.getElementById("profile-section").open = true;
    for (const sec of SETTINGS.sections) {
      const det = document.getElementById(`section-${sec.id}`);
      if (det) det.open = false;
    }
    document.getElementById("io-section").open = false;
    showAlert(`✓ Profile loaded (${response.result.audiences.length} audiences)`, "success");
  } catch (e) {
    showAlert("Error: " + e.message, "error");
    setProfileStatus("error", "err");
  } finally {
    btn.disabled = false;
    btn.textContent = "View Profile";
  }
}

function setProfileStatus(label, klass) {
  const el = document.getElementById("profile-status");
  el.textContent = label;
  el.className = "io-status " + (klass || "empty");
}

async function getCachedProfile() {
  try {
    const data = await chrome.storage.local.get([STORAGE_KEYS.profile]);
    return data[STORAGE_KEYS.profile] || null;
  } catch { return null; }
}

function digIdentity(profile, key) {
  if (!profile) return "";
  const dig = (root) => root?._nordstrom?.identities?.[key];
  return dig(profile.attributes) || dig(profile.attributes?.hub) || "";
}

// ─────────────────────────────────────────────────────────────────────────────
// Profile rendering
// ─────────────────────────────────────────────────────────────────────────────
function renderProfile(p) {
  // Identity panel
  const identityEl = document.getElementById("profile-identity");
  identityEl.replaceChildren();

  // Production detection — the visual cue (red accent + PROD badge) needs
  // to be unmistakable so the user doesn't accidentally fire test events
  // into the real environment. Accepts "prod" or "production" in any case.
  const sandboxStr = String(p.sandbox || "").toLowerCase().trim();
  const isProd = sandboxStr === "prod" || sandboxStr === "production";
  identityEl.classList.toggle("is-prod", isProd);

  const lines = [
    { label: "ShopperId",  value: p.shopperId },
    { label: "Profile ID", value: p.profileId || "—" },
    { label: "Sandbox",    value: p.sandbox || "—" },
  ];
  // Pull additional identities if present
  for (const k of ["enterpriseId", "customerProfileId"]) {
    const v = digIdentity(p, k);
    if (v) lines.push({ label: k, value: v });
  }
  for (const { label, value } of lines) {
    const row = document.createElement("div");
    row.className = "identity-row";
    // Sandbox value gets a red "PROD" pill when on production; everything
    // else (and non-Sandbox rows) renders as plain text.
    const valueHtml = (label === "Sandbox" && isProd)
      ? `<span class="sandbox-badge sandbox-prod">⚠ ${escapeHtml(value).toUpperCase()}</span>`
      : escapeHtml(value);
    row.innerHTML = `<span class="identity-key">${escapeHtml(label)}:</span><span class="identity-val">${valueHtml}</span>`;
    identityEl.appendChild(row);
  }
  // AEP profile deep link
  if (p.profileId) {
    const tenant = p.tenant || SETTINGS.tenant || "@nordstrom";
    const sandbox = p.sandbox || SETTINGS.sandbox || "prod";
    const url = SETTINGS.profileUrlTemplate
      ? TE.tplStr(SETTINGS.profileUrlTemplate, { tenant, sandbox, profileId: p.profileId })
      : `https://experience.adobe.com/#/${tenant}/sname:${sandbox}/journey-optimizer/platform/profile/browse/${p.profileId}/experienceEvents`;
    const row = document.createElement("div");
    row.className = "identity-row";
    row.innerHTML = `<span class="identity-key">Open in AEP:</span><a class="identity-link" href="${url}" target="_blank" rel="noopener">View profile ↗</a>`;
    identityEl.appendChild(row);
  }

  renderAttributes(p);
  renderAudiences(p.audiences || []);
  renderEvents(p.events || []);
  renderSystemComputedAttributes(p);
  renderRawJson(p);

  // Project identity values into the Shop tab's compact identity card
  // (mirror of the top Identity panel). The mirror only exists when the
  // Shop section is rendered; safely no-ops otherwise.
  _shopUpdateIdentityMirror(p);
  _shopUpdateEventsMirror(p);
}

// ─────────────────────────────────────────────────────────────────────────────
// Attributes panel — everything under _nordstrom.* that isn't already
// surfaced elsewhere. identities lives in the Identity panel,
// SystemComputedAttributes has its own SCA panel, and segmentMembership has
// already been stripped at the background layer (renders as the Audiences
// panel). What's left is things like preferences, loyalty, isDeleted, etc.
// Walked one level deep: scalar leaves under each top-level key become rows
// "key.subkey | value"; standalone scalars become "key | value".
// ─────────────────────────────────────────────────────────────────────────────
function renderAttributes(p) {
  const list = document.getElementById("profile-attrs");
  const countEl = document.getElementById("profile-attrs-count");
  if (!list || !countEl) return;

  // Mirror the SCA panel's primary→hub fallback so this works against either
  // schema flavor.
  const ns = p?.attributes?._nordstrom
          || p?.attributes?.hub?._nordstrom
          || null;

  const SKIP = new Set(["identities", "SystemComputedAttributes"]);

  // Build flat (group, key, value) rows. Group lets us color top-level
  // categories (preferences / loyalty / …) consistently across their rows.
  const rows = [];
  if (ns && typeof ns === "object") {
    for (const [topKey, topVal] of Object.entries(ns)) {
      if (SKIP.has(topKey)) continue;
      if (topVal == null) continue;
      if (Array.isArray(topVal)) {
        rows.push({ group: topKey, key: topKey, value: topVal.join(", ") });
      } else if (typeof topVal === "object") {
        for (const [subKey, subVal] of Object.entries(topVal)) {
          if (subVal == null) continue;
          // One level deep is the sweet spot — flatten further and the
          // tables become unreadable, so anything still nested gets
          // JSON-stringified.
          const display = (typeof subVal === "object")
            ? JSON.stringify(subVal)
            : String(subVal);
          rows.push({ group: topKey, key: `${topKey}.${subKey}`, value: display });
        }
      } else {
        rows.push({ group: topKey, key: topKey, value: String(topVal) });
      }
    }
  }

  if (!rows.length) {
    countEl.textContent = "";
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: "No additional attributes for this profile.",
    }));
    return;
  }

  // Stable color per group — matches the events / SCA palette so the panels
  // feel of-a-piece.
  const PALETTE = ["#F87171", "#FBBF24", "#34D399", "#60A5FA", "#A78BFA", "#F472B6", "#22D3EE", "#FB923C", "#A3E635", "#C084FC"];
  const colorCache = new Map();
  let nx = 0;
  const colorFor = (g) => {
    if (!colorCache.has(g)) { colorCache.set(g, PALETTE[nx % PALETTE.length]); nx++; }
    return colorCache.get(g);
  };

  countEl.textContent = `(${rows.length})`;

  const wrap = document.createElement("div");
  wrap.className = "profile-table-wrap" + (rows.length > 20 ? " tall-scroll" : "");
  const table = document.createElement("table");
  table.className = "profile-table";
  const thead = document.createElement("thead");
  thead.innerHTML = "<tr><th>Attribute</th><th>Value</th></tr>";
  table.appendChild(thead);
  const tbody = document.createElement("tbody");

  for (const r of rows) {
    const tr = document.createElement("tr");

    const tdKey = document.createElement("td");
    tdKey.className = "cell-key";
    tdKey.style.color = colorFor(r.group);
    tdKey.textContent = r.key;
    tdKey.title = r.key;

    const tdVal = document.createElement("td");
    tdVal.className = "cell-val";
    tdVal.textContent = r.value;

    tr.append(tdKey, tdVal);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  list.replaceChildren(wrap);
}

function renderAudiences(audiences) {
  _lastAudiences = Array.isArray(audiences) ? audiences : [];
  const list = document.getElementById("profile-audiences");
  const count = document.getElementById("profile-audiences-count");

  // Apply the search filter (if any). Case-insensitive substring match
  // against name + id + namespace + status — anything the user can see in
  // the row should be a valid search target.
  const q = (document.getElementById("profile-audiences-filter")?.value || "").trim().toLowerCase();
  const matches = (a) => {
    if (!q) return true;
    return [a.name, a.id, a.namespace, a.status]
      .some((v) => v && String(v).toLowerCase().includes(q));
  };
  const filtered = _lastAudiences.filter(matches);

  // Count shows "(N of M)" when a filter narrows results, "(N)" otherwise.
  if (!_lastAudiences.length) count.textContent = "";
  else if (filtered.length === _lastAudiences.length) count.textContent = `(${_lastAudiences.length})`;
  else count.textContent = `(${filtered.length} of ${_lastAudiences.length})`;

  if (!_lastAudiences.length) {
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: "No audiences for this profile.",
    }));
    return;
  }
  if (!filtered.length) {
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: `No audiences match "${q}".`,
    }));
    return;
  }

  const COLORS = ["#F87171", "#FBBF24", "#34D399", "#60A5FA", "#A78BFA", "#F472B6", "#22D3EE", "#FB923C", "#A3E635", "#C084FC"];
  const groupCache = new Map();
  let nextColor = 0;
  const groupKeyFor = (a) => {
    const n = String(a.name || a.id || "").trim();
    const parts = n.split(/[_\-]/).filter(Boolean);
    if (parts.length >= 2) return `${parts[0]}_${parts[1]}`;
    return parts[0] || a.namespace || "_";
  };
  const colorFor = (a) => {
    const k = groupKeyFor(a);
    if (!groupCache.has(k)) { groupCache.set(k, COLORS[nextColor % COLORS.length]); nextColor++; }
    return groupCache.get(k);
  };
  const grouped = filtered.slice().sort((a, b) => groupKeyFor(a).localeCompare(groupKeyFor(b)));

  list.replaceChildren(...grouped.map((a) => {
    const row = document.createElement("div");
    row.className = "audience-row";
    row.style.borderLeft = `3px solid ${colorFor(a)}`;
    const status = (a.status || "other").toLowerCase();
    const badgeCls = ["realized", "exited", "existing"].includes(status) ? status : "other";
    row.innerHTML = `
      <span class="aud-name" style="color:${colorFor(a)}">${escapeHtml(a.name || a.id)}</span>
      <span class="aud-ns">${escapeHtml(a.namespace || "")}</span>
      <span class="aud-ts">${escapeHtml(a.lastQualificationTime || "—")}</span>
      <span class="aud-badge ${badgeCls}">${escapeHtml(a.status || "—")}</span>
    `;
    row.title = `${a.id}\nGroup: ${groupKeyFor(a)}`;
    return row;
  }));
}

function renderEvents(events) {
  _lastEvents = Array.isArray(events) ? events : [];
  const list = document.getElementById("profile-events");
  const countEl = document.getElementById("profile-events-count");

  const showTracking = document.getElementById("show-tracking-toggle")?.checked === true;
  const HIDDEN = ["message.tracking", "message.feedback"];
  const trackingFiltered = showTracking ? _lastEvents : _lastEvents.filter((e) => {
    const t = String(e.eventType || "").toLowerCase();
    return !HIDDEN.some((p) => t === p || t.startsWith(p + "."));
  });

  // Search filter — case-insensitive substring match over every value the
  // user can see in the row: event type, brand, banner, campaign metadata,
  // SKUs, browse path, journey name. Matches the union of all those
  // strings against the query.
  const q = (document.getElementById("profile-events-filter")?.value || "").trim().toLowerCase();
  const searchFiltered = !q ? trackingFiltered : trackingFiltered.filter((e) => {
    const haystack = [
      e.eventType,
      e.channelBrand,
      e.browsePath,
      e.sourceJourneyName,
      ...(Array.isArray(e.skuIds) ? e.skuIds : []),
      ...(Array.isArray(e.items) ? e.items.map((i) => i?.skuId || i?.productDisplayId).filter(Boolean) : []),
      e.metadata?.banner,
      e.metadata?.campaignType,
      e.metadata?.campaignId,
      e.metadata?.campaignDescription,
      e.metadata?.skuIds,
    ].filter(Boolean).join(" ").toLowerCase();
    return haystack.includes(q);
  });

  const filtered = searchFiltered;
  const hidden = _lastEvents.length - filtered.length;
  countEl.textContent = filtered.length
    ? `(${filtered.length}${hidden ? ` of ${_lastEvents.length}` : ""})`
    : (_lastEvents.length ? `(0 of ${_lastEvents.length})` : "");

  if (!filtered.length) {
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: q
        ? `No events match "${q}".`
        : (hidden
            ? `${hidden} tracking/feedback events hidden — tick "show tracking/feedback" to see them.`
            : "No recent events."),
    }));
    return;
  }

  // Color per event type
  const EVENT_COLORS = ["#F87171", "#FBBF24", "#34D399", "#60A5FA", "#A78BFA", "#F472B6", "#22D3EE", "#FB923C", "#A3E635", "#C084FC"];
  const colorCache = new Map();
  let nx = 0;
  const colorFor = (k) => {
    if (!colorCache.has(k)) { colorCache.set(k, EVENT_COLORS[nx % EVENT_COLORS.length]); nx++; }
    return colorCache.get(k);
  };

  const sorted = filtered.slice().sort((a, b) => (b.timestamp || "").localeCompare(a.timestamp || ""));
  const wrap = document.createElement("div");
  wrap.className = "profile-table-wrap" + (sorted.length > 20 ? " tall-scroll" : "");
  const table = document.createElement("table");
  table.className = "profile-table profile-table-events";
  const thead = document.createElement("thead");
  // Three primary columns. Timestamp + Δ render in a sub-row underneath
  // each event since they're monospaced ISO strings that don't fit
  // cleanly in a narrow column — better as their own line.
  thead.innerHTML = "<tr><th>Event</th><th>Brand</th><th>Value</th></tr>";
  table.appendChild(thead);
  const tbody = document.createElement("tbody");

  for (let i = 0; i < sorted.length; i++) {
    const e = sorted[i];

    // Primary row — event type / brand / value
    const tr = document.createElement("tr");
    tr.className = "event-row-primary";

    const tdName = document.createElement("td");
    tdName.className = "cell-key";
    tdName.style.color = colorFor(e.eventType);
    tdName.textContent = e.eventType || "—";

    const tdBrand = document.createElement("td");
    tdBrand.className = "cell-val cell-brand";
    tdBrand.textContent = e.channelBrand || e.metadata?.banner || "—";

    const tdVal = document.createElement("td");
    tdVal.className = "cell-val";
    tdVal.replaceChildren(...renderEventValueCell(e));

    tr.append(tdName, tdBrand, tdVal);
    tbody.appendChild(tr);

    // Secondary row — timestamp + delta, full width below
    const subTr = document.createElement("tr");
    subTr.className = "event-row-meta";
    const subTd = document.createElement("td");
    subTd.colSpan = 3;
    subTd.className = "cell-meta";

    const tsSpan = document.createElement("span");
    tsSpan.className = "meta-ts";
    tsSpan.textContent = e.timestamp || "—";

    const gapSpan = document.createElement("span");
    gapSpan.className = "meta-gap";
    const next = sorted[i + 1];
    if (next && e.timestamp && next.timestamp) {
      gapSpan.textContent = "Δ " + humanizeDuration(new Date(e.timestamp) - new Date(next.timestamp));
    } else {
      gapSpan.textContent = "";
    }
    subTd.append(tsSpan, gapSpan);
    subTr.appendChild(subTd);
    tbody.appendChild(subTr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  list.replaceChildren(wrap);
}

// Builds a "key: value" labeled line block. Shared by all event-type
// renderers so every row in the Events table reads consistently.
//   rows: array of [labelString, value] tuples (or null/empty values, which
//         are skipped automatically so callers don't need to pre-filter)
// Returns: a single flex-column <div> with one labeled line per non-empty row.
function _buildLabeledBlock(rows) {
  const block = document.createElement("div");
  block.style.display = "flex";
  block.style.flexDirection = "column";
  block.style.gap = "2px";
  for (const [k, v] of rows) {
    if (v == null || v === "") continue;
    const line = document.createElement("div");
    line.style.display = "flex";
    line.style.gap = "6px";
    line.style.alignItems = "baseline";
    const keyEl = document.createElement("span");
    keyEl.textContent = k + ":";
    keyEl.style.color = "#6a7a90";
    keyEl.style.fontSize = "10px";
    keyEl.style.flexShrink = "0";
    const valEl = document.createElement("span");
    valEl.textContent = String(v);
    valEl.style.wordBreak = "break-word";
    line.append(keyEl, valEl);
    block.appendChild(line);
  }
  return block;
}

// Stack multiple labeled blocks vertically with dashed dividers — used for
// events that carry a list of items (BAG, PDV, Wishlist, etc.). Empty input
// produces an em-dash so the cell never goes fully blank.
function _stackItemBlocks(itemBlocks) {
  if (!itemBlocks.length) {
    const span = document.createElement("span");
    span.textContent = "—";
    return [span];
  }
  const w = document.createElement("div");
  w.style.display = "flex";
  w.style.flexDirection = "column";
  w.style.gap = "6px";
  for (let i = 0; i < itemBlocks.length; i++) {
    const b = itemBlocks[i];
    if (i < itemBlocks.length - 1) {
      b.style.paddingBottom = "4px";
      b.style.borderBottom = "1px dashed rgba(255,255,255,0.06)";
    }
    w.appendChild(b);
  }
  return [w];
}

// Returns the labeled-line rows that describe an item, given the event
// type. Per-event-type whitelist of which item fields to surface and what
// to label them — driven by what each event's payload actually contains.
function _itemRowsForEvent(eventType, it) {
  const t = String(eventType || "").toUpperCase();
  if (t === "BAG") {
    return [
      ["skuId",          it.skuId],
      ["lastModifyTime", it.lastModifyTime],
    ];
  }
  if (t === "PRODUCT_DETAIL_VIEWED") {
    // PDV emits productDisplayId only (per current schema); skuId fallback
    // covers any historical events written before the field rename.
    return [["productDisplayId", it.productDisplayId || it.skuId]];
  }
  if (t === "ADDED_SKU_TO_WISHLIST") {
    return [["skuId", it.skuId]];
  }
  if (t === "ORDER_SUBMITTED") {
    return [["skuId", it.skuId]];
  }
  if (t === "CUSTOMER_RETAIL_TRANSACTION") {
    return [["skuId", it.skuId]];
  }
  // Default: surface whichever identifier is present, prefer skuId.
  return [[it.skuId ? "skuId" : "productDisplayId", it.skuId || it.productDisplayId]];
}

function renderEventValueCell(e) {
  const type = String(e.eventType || "").toUpperCase();
  const text = (s) => Object.assign(document.createElement("span"), { textContent: s });

  // ── Event-level fields (no items) ──────────────────────────────────────
  // Single labeled-block events where the value is a couple of named
  // properties rather than a list. browsePath, journey name, etc.

  if (type === "BROWSE_SEARCH_RESULTS") {
    return [_buildLabeledBlock([["browsePath", e.browsePath]])];
  }

  if (type === "AJO_CUSTOM_CONTACT_HISTORY_EVENT" || type === "AJO_QUALIFICATION_EVENT") {
    return [_buildLabeledBlock([["sourceJourneyName", e.sourceJourneyName]])];
  }

  // message.feedback / message.tracking carry AJO delivery metadata buried
  // in _experience.customerJourneyManagement (banner shows in the Brand
  // column; the rest goes here).
  if ((type === "MESSAGE.FEEDBACK" || type === "MESSAGE.TRACKING") && e.metadata) {
    return [_buildLabeledBlock([
      ["campaignType",        e.metadata.campaignType],
      ["campaignId",          e.metadata.campaignId],
      ["campaignDescription", e.metadata.campaignDescription],
      ["skuIds",              e.metadata.skuIds],
    ])];
  }

  // ── Item-list events ──────────────────────────────────────────────────
  // BAG / PDV / Wishlist / Order / Retail Transaction all carry items[].
  // Add event-level fields (orderNumber, purchaseId, bagType) above the
  // item list so the row tells a complete story without having to open
  // Raw JSON.

  const HEADER_FIELDS = {
    BAG:                         [["bagType", e.bagType]],
    ORDER_SUBMITTED:             [["orderNumber", e.orderNumber], ["purchaseId", e.purchaseId]],
    CUSTOMER_RETAIL_TRANSACTION: [["orderNumber", e.orderNumber], ["purchaseId", e.purchaseId]],
  };
  const headerRows = (HEADER_FIELDS[type] || []).filter(([, v]) => v);

  if (Array.isArray(e.items) && e.items.length) {
    const blocks = [];
    if (headerRows.length) blocks.push(_buildLabeledBlock(headerRows));
    for (const it of e.items) {
      const rows = _itemRowsForEvent(type, it).filter(([, v]) => v);
      if (rows.length) blocks.push(_buildLabeledBlock(rows));
    }
    return _stackItemBlocks(blocks);
  }

  // ── Fallbacks ─────────────────────────────────────────────────────────
  // Event-level header rows even when no items (e.g. an order with the
  // number but empty items array).
  if (headerRows.length) return [_buildLabeledBlock(headerRows)];
  // Last resort: comma-list of SKUs.
  if (Array.isArray(e.skuIds) && e.skuIds.length) {
    return [_buildLabeledBlock([["skuIds", e.skuIds.join(", ")]])];
  }
  return [text("—")];
}

function humanizeDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return "—";
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ${m % 60}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function renderSystemComputedAttributes(p) {
  _lastProfile = p; // cache for live re-filtering on keystroke
  const list = document.getElementById("profile-sca");
  const countEl = document.getElementById("profile-sca-count");
  if (!list || !countEl) return;

  // SCA may live under attributes._nordstrom or attributes.hub._nordstrom
  // depending on which schema the profile resolved through.
  const sca = p?.attributes?._nordstrom?.SystemComputedAttributes
           || p?.attributes?.hub?._nordstrom?.SystemComputedAttributes
           || null;

  // Group by key. Each key holds either an array of item objects or a single
  // item object. We preserve every field present on each item (not just
  // value + timestamp) so any field Adobe attaches — meta, source, id,
  // whatever — surfaces automatically without code changes.
  const groups = []; // [{ key, items: [item, item, ...] }]
  let totalEntries = 0;
  if (sca && typeof sca === "object") {
    for (const [key, entry] of Object.entries(sca)) {
      const items = [];
      if (Array.isArray(entry)) {
        for (const item of entry) {
          if (item && typeof item === "object") {
            items.push({ ...item, timestamp: item.timestamp || "" });
          }
        }
      } else if (entry && typeof entry === "object" && "value" in entry) {
        items.push({ ...entry, timestamp: entry.timestamp || "" });
      }
      if (items.length) {
        // Newest first within each group.
        items.sort((a, b) => (b.timestamp || "").localeCompare(a.timestamp || ""));
        groups.push({ key, items });
        totalEntries += items.length;
      }
    }
  }

  if (!groups.length) {
    countEl.textContent = "";
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: "No system computed attributes for this profile.",
    }));
    return;
  }

  // Apply search filter. Match the query against the raw key, humanized
  // key, and stringified item values. Whole group survives if ANY of its
  // data matches — keeping the full history visible is more useful than
  // partially filtering rows inside one attribute.
  const q = (document.getElementById("profile-sca-filter")?.value || "").trim().toLowerCase();
  const filteredGroups = !q ? groups : groups.filter((g) => {
    const keyHay = `${g.key} ${humanizeName(g.key)}`.toLowerCase();
    if (keyHay.includes(q)) return true;
    return g.items.some((item) =>
      Object.values(item).some((v) => {
        const s = Array.isArray(v) ? v.join(" ")
                : (typeof v === "object" && v !== null) ? JSON.stringify(v)
                : String(v ?? "");
        return s.toLowerCase().includes(q);
      })
    );
  });
  const filteredTotalEntries = filteredGroups.reduce((n, g) => n + g.items.length, 0);

  if (!filteredGroups.length) {
    countEl.textContent = `(0 of ${groups.length})`;
    list.replaceChildren(Object.assign(document.createElement("div"), {
      className: "profile-identity",
      textContent: `No attributes match "${q}".`,
    }));
    return;
  }

  // Stable color per attribute key — mirrors the events table palette.
  const PALETTE = ["#F87171", "#FBBF24", "#34D399", "#60A5FA", "#A78BFA", "#F472B6", "#22D3EE", "#FB923C", "#A3E635", "#C084FC"];
  const colorCache = new Map();
  let nx = 0;
  const colorFor = (k) => {
    if (!colorCache.has(k)) { colorCache.set(k, PALETTE[nx % PALETTE.length]); nx++; }
    return colorCache.get(k);
  };

  // Order groups by their newest entry — "freshest attribute" floats to top.
  filteredGroups.sort((a, b) => (b.items[0]?.timestamp || "").localeCompare(a.items[0]?.timestamp || ""));

  // Count format: "(N)" when unfiltered, "(N · M)" when key count differs
  // from value count, "(M of N)" when a search has narrowed the view.
  const isSearching = q.length > 0;
  if (isSearching) {
    countEl.textContent = filteredGroups.length === groups.length
      ? `(${groups.length})`
      : `(${filteredGroups.length} of ${groups.length})`;
  } else {
    countEl.textContent = groups.length === totalEntries
      ? `(${groups.length})`
      : `(${groups.length} · ${totalEntries})`;
  }

  // Format a single field's value into a display string. Arrays become
  // comma-joined; nested objects get JSON-stringified as a safety net so a
  // weird new field never crashes the renderer.
  const fmtFieldValue = (v) => {
    if (v == null) return "—";
    if (Array.isArray(v)) return v.join(", ");
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  };

  // Render one item (entry) as a labeled-field block: each present field
  // becomes a "fieldName: value" line. Ordering is value → timestamp →
  // anything else (in source order) so the most-scanned fields land at the
  // top of each block. Timestamps get muted styling to read as metadata
  // about the value rather than a peer field.
  const renderItemBlock = (item) => {
    const block = document.createElement("div");
    block.style.display = "flex";
    block.style.flexDirection = "column";
    block.style.gap = "2px";

    const allFields = Object.keys(item);
    const ordered = [];
    if (allFields.includes("value"))     ordered.push("value");
    if (allFields.includes("timestamp")) ordered.push("timestamp");
    for (const f of allFields) {
      if (!ordered.includes(f)) ordered.push(f);
    }

    for (const field of ordered) {
      const raw = item[field];
      // Skip empty timestamp (renderer falls through to em-dash) but keep
      // any other explicitly-empty field so the user sees it was present.
      if (field === "timestamp" && !raw) continue;
      if (raw === undefined) continue;

      const line = document.createElement("div");
      line.style.display = "flex";
      line.style.gap = "6px";
      line.style.alignItems = "baseline";

      const keyEl = document.createElement("span");
      keyEl.textContent = field + ":";
      keyEl.style.color = "#6a7a90";
      keyEl.style.fontSize = "10px";
      keyEl.style.flexShrink = "0";
      keyEl.style.minWidth = "62px";

      const valEl = document.createElement("span");
      valEl.textContent = fmtFieldValue(raw);
      valEl.style.wordBreak = "break-word";
      if (field === "timestamp") {
        valEl.style.color = "#a8b3c4";
        valEl.style.fontSize = "10px";
      }

      line.append(keyEl, valEl);
      block.appendChild(line);
    }
    return block;
  };

  // Cap row height with tall-scroll if any group has lots of history, since
  // a single 50-entry group would otherwise push everything else off-screen.
  const tallish = filteredTotalEntries > 20 || filteredGroups.some((g) => g.items.length > 8);

  const wrap = document.createElement("div");
  wrap.className = "profile-table-wrap" + (tallish ? " tall-scroll" : "");
  const table = document.createElement("table");
  table.className = "profile-table";
  const thead = document.createElement("thead");
  thead.innerHTML = "<tr><th>Attribute</th><th>Items</th></tr>";
  table.appendChild(thead);
  const tbody = document.createElement("tbody");

  for (const g of filteredGroups) {
    const tr = document.createElement("tr");

    const tdKey = document.createElement("td");
    tdKey.className = "cell-key";
    tdKey.style.color = colorFor(g.key);
    // Group label + entry count when more than one — useful at-a-glance.
    tdKey.textContent = g.items.length > 1
      ? `${humanizeName(g.key)}  (${g.items.length})`
      : humanizeName(g.key);
    tdKey.title = `${g.key} — ${g.items.length} entr${g.items.length === 1 ? "y" : "ies"}`;

    // Items cell: one labeled-field block per entry, separated by a faint
    // dashed divider so the eye can chunk the history naturally.
    const tdItems = document.createElement("td");
    tdItems.className = "cell-val";
    const itemsWrap = document.createElement("div");
    itemsWrap.style.display = "flex";
    itemsWrap.style.flexDirection = "column";
    itemsWrap.style.gap = "6px";

    for (let i = 0; i < g.items.length; i++) {
      const block = renderItemBlock(g.items[i]);
      if (i < g.items.length - 1) {
        block.style.paddingBottom = "5px";
        block.style.borderBottom = "1px dashed rgba(255,255,255,0.08)";
      }
      itemsWrap.appendChild(block);
    }
    tdItems.replaceChildren(itemsWrap);

    tr.append(tdKey, tdItems);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  list.replaceChildren(wrap);
}

// camelCase / mixedCase → "Title Case With Numbers Stuck On". Handles acronyms
// (SKU stays uppercase) and keeps digit suffixes attached (90Days, not 90 Days).
//   nordstromSKUPurchase90Days       → Nordstrom SKU Purchase90Days
//   nordstromRackSKUInBag90Days      → Nordstrom Rack SKU In Bag90Days
//   nordstromSkuPurchases24Hours     → Nordstrom Sku Purchases24Hours
function humanizeName(s) {
  if (!s) return "";
  return String(s)
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/^(.)/, (c) => c.toUpperCase());
}

function renderRawJson(p) {
  const pre = document.getElementById("profile-attributes");
  pre.innerHTML = highlightJSON(JSON.stringify(p, null, 2));
}

// ─────────────────────────────────────────────────────────────────────────────
// Request/Response pane
// ─────────────────────────────────────────────────────────────────────────────
// Snapshot of the last request meta (url/method/headers/body) the side
// panel saw via setIO. Populated on every fire, consumed by the Copy as
// cURL button. Null until the first fire of the session.
let _lastRequestMeta = null;

function setIO(req, res, statusLabel, statusClass, requestMeta) {
  renderJSON(document.getElementById("io-request"), req);
  renderJSON(document.getElementById("io-response"), res);
  const el = document.getElementById("io-status");
  el.textContent = statusLabel || "idle";
  el.className = "io-status " + (statusClass || "empty");

  _lastRequestMeta = requestMeta || null;
  const curlBtn = document.getElementById("copy-curl-btn");
  if (curlBtn) curlBtn.disabled = !_lastRequestMeta;
}

// Keys whose values represent ephemeral UUIDs that should be regenerated
// every time the curl is replayed. Postman provides {{$guid}} which expands
// to a fresh UUID v4 on each request. _id and productTriggerId are the two
// in our current payload schemas.
const POSTMAN_GUID_KEYS = new Set([
  "_id",
  "productTriggerId",
]);

// Keys whose values represent ephemeral ISO-8601 timestamps that should be
// regenerated to "now" each time the curl runs. Postman provides
// {{$isoTimestamp}} which expands to the current ISO timestamp.
// (correlationId / sourceJourneyVersionId are NOT in this set even though
// they're UUID-shaped — they identify a specific journey and must stay
// literal.)
const POSTMAN_ISO_KEYS = new Set([
  "systemTime",
  "eventTime",
  "transactionTime",
  "lastModifyTime",
  "lastModifiedTime",
  "timestamp",
  "effectiveAt",
]);

// Walk a body recursively and replace ephemeral fields with Postman template
// variables. The substitution is keyed by FIELD NAME (not value pattern)
// because some UUID-shaped fields like correlationId / sourceJourneyVersionId
// are real identifiers that must stay literal — only the fields the form
// generates fresh on each fire should regenerate on each replay.
function _postmanizeBody(node) {
  if (Array.isArray(node)) return node.map(_postmanizeBody);
  if (node && typeof node === "object") {
    const out = {};
    for (const [k, v] of Object.entries(node)) {
      if (POSTMAN_GUID_KEYS.has(k))      out[k] = "{{$guid}}";
      else if (POSTMAN_ISO_KEYS.has(k))  out[k] = "{{$isoTimestamp}}";
      else                               out[k] = _postmanizeBody(v);
    }
    return out;
  }
  return node;
}

// Build a portable cURL command from the request meta the background
// returned. Aims for Postman-import compatibility:
//   • Each header on its own line via "\" continuation
//   • --data-raw with the body wrapped in $'...' so bash handles backslash
//     escapes ("\n", "\t") and embedded single quotes correctly
//   • One header per --header for readability
//   • Ephemeral fields (_id, timestamps) replaced with Postman template
//     vars ({{$guid}}, {{$isoTimestamp}}) so the imported request stays
//     fresh on every send instead of replaying the captured values
// The Authorization header carries the live IMS bearer token — runnable
// as-is from terminal or Postman, but the curl must be treated as a
// credential (don't paste in shared spaces).
function buildCurlCommand(meta) {
  if (!meta || !meta.url) return "";
  const method = (meta.method || "POST").toUpperCase();
  const lines = [`curl --location '${meta.url}'`];
  lines.push(`  --request ${method}`);
  for (const [k, v] of Object.entries(meta.headers || {})) {
    // Header values shouldn't contain single quotes in practice, but escape
    // defensively in case a future header carries one.
    const safeVal = String(v).replace(/'/g, "'\\''");
    lines.push(`  --header '${k}: ${safeVal}'`);
  }
  // Body: serialize to compact JSON, then use $'...' (ANSI-C quoting) so
  // any backslash escapes in the JSON string survive bash interpretation
  // when pasted into a terminal. Postman's curl importer also handles this.
  if (meta.body !== undefined && meta.body !== null && method !== "GET") {
    // Substitute ephemeral fields first so the curl re-runs cleanly.
    const postmanized = (typeof meta.body === "object" && meta.body !== null)
      ? _postmanizeBody(meta.body)
      : meta.body;
    const bodyStr = (typeof postmanized === "string")
      ? postmanized
      : JSON.stringify(postmanized);
    // Escape: backslash → \\, then single quote → \'
    const escaped = bodyStr.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    lines.push(`  --data-raw $'${escaped}'`);
  }
  return lines.join(" \\\n");
}

function renderJSON(el, value) {
  if (value == null) { el.textContent = "—"; return; }
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      el.innerHTML = highlightJSON(JSON.stringify(parsed, null, 2));
    } catch { el.textContent = value; }
    return;
  }
  if (typeof value === "object") { el.innerHTML = highlightJSON(JSON.stringify(value, null, 2)); return; }
  el.textContent = String(value);
}

function highlightJSON(text) {
  const esc = String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return esc.replace(/"(\\.|[^"\\])*"(\s*:)?|\b(true|false|null)\b|-?\d+(\.\d+)?([eE][+-]?\d+)?/g, (m) => {
    let cls = "jsn-num";
    if (/^"/.test(m)) cls = /:\s*$/.test(m) ? "jsn-key" : "jsn-str";
    else if (/^(true|false)$/.test(m)) cls = "jsn-bool";
    else if (/^null$/.test(m)) cls = "jsn-null";
    return `<span class="${cls}">${m}</span>`;
  });
}

function wireProfileCopy() {
  document.getElementById("copy-attrs-btn").addEventListener("click", () => {
    copyToClipboard(document.getElementById("profile-attributes").textContent, "Profile JSON copied");
  });
}
function wireIOCopy() {
  // Each copy button anchors its own little confirmation toast right above
  // itself — the prior top-of-panel showAlert was too far from the click
  // for the user to notice, especially when the I/O section was scrolled.
  document.getElementById("copy-req-btn").addEventListener("click", () => {
    copyAndToast(document.getElementById("io-request").textContent, "copy-req-toast", "Copied");
  });
  document.getElementById("copy-res-btn").addEventListener("click", () => {
    copyAndToast(document.getElementById("io-response").textContent, "copy-res-toast", "Copied");
  });
  document.getElementById("copy-curl-btn").addEventListener("click", () => {
    if (!_lastRequestMeta) {
      showButtonToast("copy-curl-toast", "Fire an event first", true);
      return;
    }
    const curl = buildCurlCommand(_lastRequestMeta);
    copyAndToast(curl, "copy-curl-toast", "cURL copied (live token!)");
  });
}

// Copy text to clipboard and show a confirmation toast next to the button.
// Combines the clipboard write + toast feedback into one helper since every
// copy button does the same dance.
function copyAndToast(text, toastId, successMsg) {
  navigator.clipboard.writeText(text).then(
    () => showButtonToast(toastId, successMsg, false),
    () => showButtonToast(toastId, "Copy failed", true),
  );
}

// Show a transient toast bubble attached to a specific button. The element
// is already in the DOM (rendered next to its button); we just set the text,
// add the visible class, and clear it after 1.4s.
function showButtonToast(toastId, msg, isError) {
  const el = document.getElementById(toastId);
  if (!el) return;
  el.textContent = msg;
  el.classList.toggle("is-error", !!isError);
  // Force a reflow before adding the class so consecutive clicks re-animate.
  el.classList.remove("is-visible");
  void el.offsetWidth;
  el.classList.add("is-visible");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("is-visible"), 1400);
}
function wireShowTrackingToggle() {
  const t = document.getElementById("show-tracking-toggle");
  if (!t) return;
  t.addEventListener("change", () => renderEvents(_lastEvents));
  t.addEventListener("click", (e) => e.stopPropagation());
}

// Wire the three Profile search inputs (Audiences, Events, SCA). Each fires
// on every keystroke and re-renders from the cached last-loaded data — no
// AEP refetch. Inputs live inside <details> sub-sections; stopPropagation
// keeps focus/typing from accidentally toggling the expand/collapse.
function wireProfileFilters() {
  const wire = (inputId, rerender) => {
    const el = document.getElementById(inputId);
    if (!el) return;
    el.addEventListener("input", rerender);
    // Keep clicks/typing inside the input from bubbling to the <details>
    // summary handler (some browsers toggle on label-like inner clicks).
    el.addEventListener("click", (e) => e.stopPropagation());
    el.addEventListener("keydown", (e) => e.stopPropagation());
  };

  wire("profile-audiences-filter", () => renderAudiences(_lastAudiences));
  wire("profile-events-filter",    () => renderEvents(_lastEvents));
  wire("profile-sca-filter",       () => {
    if (_lastProfile) renderSystemComputedAttributes(_lastProfile);
  });
}

function copyToClipboard(text, msg) {
  navigator.clipboard.writeText(text).then(
    () => showAlert(msg || "Copied", "success"),
    () => showAlert("Copy failed", "error"),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Misc helpers
// ─────────────────────────────────────────────────────────────────────────────
function showAlert(msg, kind) {
  const host = document.getElementById("alert-container");
  const a = document.createElement("div");
  a.className = "alert alert-" + (kind === "error" ? "error" : "success");
  a.textContent = msg;
  host.appendChild(a);
  setTimeout(() => a.remove(), 4500);
}

// Show a transient message inside a specific section, just above its
// submit row. Pass empty msg to clear. Auto-hides after ~6s.
function setSectionAlert(sectionId, msg, kind) {
  const el = document.getElementById(`alert-${sectionId}`);
  if (!el) return;
  if (el._hideTimer) { clearTimeout(el._hideTimer); el._hideTimer = null; }
  if (!msg) {
    el.className = "section-alert";
    el.textContent = "";
    return;
  }
  const klass = kind === "error" ? "section-alert-error" : "section-alert-success";
  el.className = `section-alert ${klass} shown`;
  el.textContent = msg;
  el._hideTimer = setTimeout(() => {
    el.className = "section-alert";
    el.textContent = "";
    el._hideTimer = null;
  }, 6000);
}

function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ─────────────────────────────────────────────────────────────────────────────
// SHOP SIMULATOR
// — High-level shopping actions that fire the same underlying events the
// granular Trigger/Qualification sections produce. The simulator owns its
// own DOM, catalog state, cart state, and activity log. Each action looks
// up the corresponding event config from settings.json by id, builds a
// minimal context (shopperId + product fields + maybe cart) and routes to
// the same chrome.runtime.sendMessage({action:"fireEvent",...}) flow used
// by the existing form-based sections.
//
// Catalog format: xlsx with header row containing the columns
//   productDisplayId | skuId | productName | brand | category
// Stored in chrome.storage.local under "shopCatalog" so it survives reloads.
// ─────────────────────────────────────────────────────────────────────────────

// In-memory state mirroring chrome.storage.local. Loaded on init.
const _shop = {
  products: [],      // [{ productDisplayId, skuId, productName, brand, category }]
  cart:     [],      // [{ productDisplayId, skuId, productName }]
  selected: null,    // currently selected product (object reference into products)
  brand:    null,    // active brand id (e.g. "NORDSTROM" / "NORDSTROM_RACK") — user-selected, applied to every fired event regardless of the catalog row's own brand
  // Cart-tracking toggle: when true (default), actions marked addsToCart
  // (Bag, Wishlist) push the current product into _shop.cart so it can
  // later be consumed by Order/Retail. When false, the BAG/WISHLIST
  // events still fire to AEP but the local cart stays as-is — lets the
  // user test Order/Retail with a known cart state (e.g. empty) without
  // having to fire other events to set it up. Persisted across panel
  // reloads.
  cartTrackingEnabled: true,
  log:      [],      // [{ ts, eventId, status, msg }]
  // Test recorder buffer — every successful fire pushes an entry which
  // can later be serialized to a Postman v2.1 collection. Capped to keep
  // memory bounded; oldest fire dropped first.
  recorded: [],      // [{ seq, ts, shopperId, brand, event, descriptor, request }]
  recSeq:   0,       // monotonic counter for naming (resets on Clear)
};
const SHOP_RECORDED_MAX = 200;

function renderShopSection(section) {
  // Persistent state setup — survives panel reload.
  _shopLoadFromStorage();

  const details = document.createElement("details");
  details.className = "io-section";
  details.id = `section-${section.id}`;
  if (section.openByDefault) details.open = true;

  const summary = document.createElement("summary");
  summary.innerHTML = `
    <span class="section-title">${escapeHtml(section.title)}</span>
    <span class="io-status empty" id="status-${section.id}">ready</span>
  `;
  details.appendChild(summary);

  // ── Catalog upload row ───────────────────────────────────────────────
  const catalogRow = document.createElement("div");
  catalogRow.className = "shop-catalog-row";
  catalogRow.innerHTML = `
    <input type="file" id="shop-catalog-file" accept=".xlsx" style="display:none;">
    <button type="button" class="btn-pill" id="shop-catalog-pick">Upload Catalog (.xlsx)</button>
    <button type="button" class="btn-mini" id="shop-catalog-sample" title="Load the bundled sample catalog">Load sample</button>
    <button type="button" class="shop-catalog-help-btn" id="shop-catalog-help" aria-label="How to prepare the catalog" title="How to prepare the catalog">?</button>
    <span class="shop-catalog-status" id="shop-catalog-status">No catalog loaded</span>
  `;
  details.appendChild(catalogRow);

  // ── Catalog prep popover ─────────────────────────────────────────────
  // Shows the AEP Query Service SQL needed to generate the .xlsx the
  // upload step accepts. Lives inline so it doesn't fight with the side
  // panel's narrow width; toggles on the ? button. Includes a Copy button
  // because users running this in AEP's Query Editor want it in their
  // clipboard, not transcribed by hand.
  const helpPop = document.createElement("div");
  helpPop.className = "shop-catalog-help";
  helpPop.id = "shop-catalog-help-pop";
  helpPop.style.display = "none";
  helpPop.innerHTML = `
    <div class="shop-catalog-help-head">
      <strong>Prepare product data</strong>
      <button type="button" class="shop-catalog-help-close" id="shop-catalog-help-close" aria-label="Close">×</button>
    </div>
    <p class="shop-catalog-help-step">
      1. Run <strong>both</strong> queries below in AEP Query Service, export each as <strong>XLSX</strong>, concatenate into one sheet, then upload.
    </p>
    <p class="shop-catalog-help-step" style="margin-top:6px;"><strong>Query 1</strong> — Nordstrom (excludes _ND variants)</p>
    <pre class="shop-catalog-help-sql" id="shop-catalog-help-sql-1">SELECT
  pd._nordstrom.productdetails.skuid,
  pd._nordstrom.productdetails.productdisplayid,
  pd._nordstrom.productdetails.url,
  pd._nordstrom.productdetails.primaryimageurl,
  pd._nordstrom.productdetails.isdeleted,
  pd._nordstrom.productdetails.sellingretailprice,
  pd._nordstrom.productdetails.productrating,
  pp._nordstrom.productpdid.skuids
FROM nd_product_batch_lookup_dataset pd
INNER JOIN nd_productpdid_batch_lookup_dataset pp
  ON pp._nordstrom.productpdid.productdisplayid =
     pd._nordstrom.productdetails.productdisplayid
WHERE INSTR(pd._nordstrom.productdetails.productdisplayid, '_ND') = 0
  AND pp._nordstrom.productpdid.skuids IS NOT NULL
  AND TRIM(pp._nordstrom.productpdid.skuids) <> ''
ORDER BY pp.extsourcesystemaudit.lastupdateddate DESC
LIMIT 1000;</pre>
    <div class="shop-catalog-help-actions">
      <button type="button" class="btn-mini shop-catalog-help-copy" id="shop-catalog-help-copy-1">Copy Query 1</button>
    </div>
    <p class="shop-catalog-help-step" style="margin-top:8px;"><strong>Query 2</strong> — Nordstrom Rack (excludes _NR variants)</p>
    <pre class="shop-catalog-help-sql" id="shop-catalog-help-sql-2">SELECT
  pd._nordstrom.productdetails.skuid,
  pd._nordstrom.productdetails.productdisplayid,
  pd._nordstrom.productdetails.url,
  pd._nordstrom.productdetails.primaryimageurl,
  pd._nordstrom.productdetails.isdeleted,
  pd._nordstrom.productdetails.sellingretailprice,
  pd._nordstrom.productdetails.productrating,
  pp._nordstrom.productpdid.skuids
FROM nd_product_batch_lookup_dataset pd
INNER JOIN nd_productpdid_batch_lookup_dataset pp
  ON pp._nordstrom.productpdid.productdisplayid =
     pd._nordstrom.productdetails.productdisplayid
WHERE INSTR(pd._nordstrom.productdetails.productdisplayid, '_NR') = 0
  AND pp._nordstrom.productpdid.skuids IS NOT NULL
  AND TRIM(pp._nordstrom.productpdid.skuids) <> ''
ORDER BY pp.extsourcesystemaudit.lastupdateddate DESC
LIMIT 1000;</pre>
    <div class="shop-catalog-help-actions">
      <button type="button" class="btn-mini shop-catalog-help-copy" id="shop-catalog-help-copy-2">Copy Query 2</button>
    </div>
    <p class="shop-catalog-help-step" style="margin-top:8px;">
      2. Export each result as <strong>XLSX</strong>, paste rows from Query 2 below Query 1 rows (same columns), then upload the combined file.
    </p>
    <p class="shop-catalog-help-step">
      3. Duplicates are removed automatically on upload. Rows with <code>isdeleted = TRUE</code> are flagged in the product card. Any columns you add <strong>after productrating</strong> appear in the ⓘ tooltip on the product card.
    </p>
  `;
  details.appendChild(helpPop);

  // ── Brand selector ───────────────────────────────────────────────────
  // Two-state (or N-state) toggle that determines channelBrand on every
  // fired event. Persisted to chrome.storage so reload keeps the last
  // selected brand.
  if (Array.isArray(section.brands) && section.brands.length) {
    const validIds = new Set(section.brands.map((b) => b.id));
    if (!_shop.brand || !validIds.has(_shop.brand)) {
      _shop.brand = section.brands[0].id;
      _shopPersistBrand();
    }
    const brandRow = document.createElement("div");
    brandRow.className = "shop-brand-row";
    brandRow.innerHTML = `
      <label class="shop-brand-label">Brand</label>
      <div class="shop-brand-chips" id="shop-brand-chips" role="radiogroup" aria-label="Brand">
        ${section.brands.map((b) => `
          <button type="button"
                  class="shop-brand-chip${_shop.brand === b.id ? " is-active" : ""}"
                  data-brand-id="${escapeHtml(b.id)}"
                  role="radio"
                  aria-checked="${_shop.brand === b.id ? "true" : "false"}">${escapeHtml(b.label)}</button>
        `).join("")}
      </div>
    `;
    details.appendChild(brandRow);
  }

  // ── Compact identity strip ───────────────────────────────────────────
  // Two side-by-side cards summarising the active session: who's shopping
  // (left) and which product is selected (right). Each card is dense and
  // monospaced — built to be informational glance-fodder, not a form.
  // Replaces the wider Identity panel + verbose product detail block.
  const idStrip = document.createElement("div");
  idStrip.className = "shop-idstrip";
  idStrip.innerHTML = `
    <div class="shop-idcard" id="shop-card-shopper">
      <div class="shop-idcard-label">Shopping as</div>
      <div class="shop-idcard-body shop-idcard-empty">Enter Shopper ID and click View Profile.</div>
    </div>
    <div class="shop-idcard" id="shop-card-product">
      <div class="shop-idcard-label">Product</div>
      <div class="shop-idcard-body shop-idcard-empty">Upload a catalog and pick a product.</div>
    </div>
  `;
  details.appendChild(idStrip);

  // ── Hierarchical product picker: Product → SKU ───────────────────────
  // First dropdown picks a productDisplayId (catalogues often have one PD
  // with multiple SKU variants — sizes, colors, materials). Second
  // dropdown then narrows to a specific SKU within that PD. This mirrors
  // the actual data shape and keeps the lists scannable (49 PDs reads
  // better than 100 SKUs in one big list). The downstream code still
  // sees _shop.selected as a single resolved row — the hierarchy is
  // purely UI.
  const pickerRow = document.createElement("div");
  pickerRow.className = "shop-picker-row shop-picker-hier";
  pickerRow.innerHTML = `
    <div class="shop-picker-cell">
      <label class="shop-picker-label">Product</label>
      <select id="shop-pd-select" class="shop-product-select" disabled>
        <option>Upload a catalog first…</option>
      </select>
    </div>
    <div class="shop-picker-cell">
      <label class="shop-picker-label">SKU</label>
      <select id="shop-sku-select" class="shop-product-select" disabled>
        <option>—</option>
      </select>
    </div>
    <span class="cart-pill is-empty" id="shop-cart-pill" title="Click to peek at cart">🛒 0</span>
  `;
  details.appendChild(pickerRow);

  // ── Manual product-ID lookup ─────────────────────────────────────────
  // Type a productDisplayId or skuId, press Enter or click Find. If the
  // ID is in the loaded catalog we select that product (same effect as
  // picking from the dropdown). If not, we show an error and keep the
  // current selection untouched — the simulator deliberately refuses to
  // fire on products it can't verify exist, since an unverified ID would
  // produce events AEP can't correlate.
  const lookupRow = document.createElement("div");
  lookupRow.className = "shop-lookup-row";
  lookupRow.innerHTML = `
    <input type="text" id="shop-product-id-input" class="shop-product-id-input"
           placeholder="Or enter productDisplayId / skuId"
           autocomplete="off" spellcheck="false">
    <button type="button" class="btn-mini" id="shop-product-id-find">Find</button>
    <span class="shop-lookup-status" id="shop-lookup-status"></span>
  `;
  details.appendChild(lookupRow);

  // Cart peek (collapsed by default — opens when you click the pill).
  const cartPeek = document.createElement("div");
  cartPeek.className = "cart-peek";
  cartPeek.id = "shop-cart-peek";
  cartPeek.style.display = "none";
  details.appendChild(cartPeek);

  // ── Cart-tracking toggle ─────────────────────────────────────────────
  // Default-on switch that controls whether Bag/Wishlist actually push
  // the product into the local cart. Turning it off lets the user fire
  // BAG/WISHLIST as pure events while keeping the cart at its current
  // state — useful for testing Order/Retail against a controlled cart
  // (e.g. fire Order with cart empty, or with a specific manually-built
  // set of items).
  const cartToggleRow = document.createElement("div");
  cartToggleRow.className = "shop-toggle-row";
  cartToggleRow.innerHTML = `
    <label class="shop-toggle-label">AJO Event Trigger</label>
    <button type="button"
            class="shop-toggle ${_shop.cartTrackingEnabled ? "is-on" : "is-off"}"
            id="shop-cart-tracking-toggle"
            role="switch"
            aria-checked="${_shop.cartTrackingEnabled ? "true" : "false"}"
            title="When on, Bag/Wishlist add the selected product to the cart. When off, they fire events only — cart unchanged.">
      <span class="shop-toggle-knob"></span>
      <span class="shop-toggle-text">${_shop.cartTrackingEnabled ? "ON" : "OFF"}</span>
    </button>
    <span class="shop-toggle-hint" id="shop-toggle-hint"></span>
  `;
  details.appendChild(cartToggleRow);

  // ── Compact action grid (6 columns, icon + 1-word label) ─────────────
  const actionGrid = document.createElement("div");
  actionGrid.className = "shop-actions shop-actions-compact";
  actionGrid.id = "shop-actions";
  for (const action of section.actions || []) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "shop-action-btn shop-action-btn-compact";
    btn.dataset.actionId = action.id;
    // Split the configured label "👀 View Product" into emoji + word(s).
    // Compact mode renders emoji on top, single short label underneath.
    // Short label is derived from action.id so the UI stays readable.
    const COMPACT_LABEL = {
      pdv:      "View",
      addBag:   "Bag",
      wishlist: "Wishlist",
      browse:   "Browse",
      order:    "Order",
      retail:   "Retail",
      qualify:  "Qualify",
    };
    const emojiMatch = (action.label || "").match(/^(\p{Extended_Pictographic}+)/u);
    const emoji = emojiMatch ? emojiMatch[1] : "";
    const shortLabel = COMPACT_LABEL[action.id] || (action.label || "").replace(/^[\p{Extended_Pictographic}\s]+/u, "").split(" ")[0];
    btn.innerHTML = `
      <span class="action-emoji">${escapeHtml(emoji)}</span>
      <span class="action-short" data-action-id="${escapeHtml(action.id)}">${escapeHtml(shortLabel)}</span>
    `;
    btn.disabled = true; // enabled once catalog + product are loaded
    btn.addEventListener("click", () => _shopFireAction(section, action));
    actionGrid.appendChild(btn);
  }
  details.appendChild(actionGrid);

  // ── Business Events panel ────────────────────────────────────────────
  // Back in Stock: add multiple products from catalog; fires backInStockSKUs
  // Price Drop: add multiple products; drop price auto-fills from catalog
  //             price; fires priceDropSKUs as "dropPrice|currentPrice" map
  const bizPanel = document.createElement("details");
  bizPanel.className = "shop-biz-panel";
  bizPanel.id = "shop-biz-panel";
  bizPanel.innerHTML = `
    <summary class="shop-biz-header">
      <span class="shop-biz-title">Business Events</span>
    </summary>
    <div class="shop-biz-tabs" role="tablist">
      <button type="button" class="shop-biz-tab is-active" data-biz="bis" role="tab">Back in Stock</button>
      <button type="button" class="shop-biz-tab" data-biz="pd" role="tab">Price Drop</button>
    </div>

    <!-- Back in Stock -->
    <div class="shop-biz-pane" id="biz-pane-bis">
      <div class="shop-biz-add-row">
        <button type="button" class="btn-mini" id="biz-bis-add-product">＋ Add from catalog</button>
        <span class="shop-biz-hint">Adds the currently selected product's SKU</span>
      </div>
      <div class="items-list" id="biz-bis-list"></div>
      <div class="shop-biz-fire-row">
        <button type="button" class="btn-pill shop-biz-fire-btn" id="biz-bis-fire" disabled>🔔 Fire Back in Stock</button>
        <span class="shop-biz-status" id="biz-bis-status"></span>
      </div>
    </div>

    <!-- Price Drop -->
    <div class="shop-biz-pane" id="biz-pane-pd" style="display:none;">
      <div class="shop-biz-add-row">
        <button type="button" class="btn-mini" id="biz-pd-add-product">＋ Add from catalog</button>
        <span class="shop-biz-hint">Adds selected product · drop price auto-filled</span>
      </div>
      <div class="shop-biz-pd-head">
        <span>SKU</span><span>Drop price</span><span>Current price</span><span></span>
      </div>
      <div class="items-list" id="biz-pd-list"></div>
      <div class="shop-biz-fire-row">
        <button type="button" class="btn-pill shop-biz-fire-btn" id="biz-pd-fire" disabled>💸 Fire Price Drop</button>
        <span class="shop-biz-status" id="biz-pd-status"></span>
      </div>
    </div>
  `;
  details.appendChild(bizPanel);
  // Counter pill shows how many fires are accumulated. Download/Clear
  // operate on the recorded buffer.
  const recHeader = document.createElement("div");
  recHeader.className = "shop-rec-header";
  recHeader.innerHTML = `
    <span class="shop-rec-title">Test Recorder</span>
    <span class="shop-rec-count" id="shop-rec-count">0 fires</span>
    <span class="shop-rec-spacer"></span>
    <button type="button" class="btn-mini shop-rec-download" id="shop-rec-download" disabled title="Download all recorded fires as a Postman v2.1 collection">Download Postman</button>
    <button type="button" class="btn-mini" id="shop-rec-clear" disabled title="Clear recorded fires">Clear</button>
  `;
  details.appendChild(recHeader);

  // ── Two-column Activity + Profile Events panes ───────────────────────
  // Left pane: what was just fired (the local activity log). Right pane:
  // what the AEP profile actually carries (events list from the last
  // profile refresh). Sitting side by side makes the connection obvious —
  // "I fired X 30s ago, AEP now sees X."
  const dualPane = document.createElement("div");
  dualPane.className = "shop-dual-pane";
  dualPane.innerHTML = `
    <div class="shop-dual-col">
      <div class="shop-dual-head">
        <span class="shop-dual-head-label">Activity</span>
      </div>
      <div class="shop-log" id="shop-log"></div>
    </div>
    <div class="shop-dual-col">
      <div class="shop-dual-head">
        <span class="shop-dual-head-label">Profile Events</span>
        <span class="shop-refresh-status" id="shop-refresh-status"></span>
        <button type="button"
                class="shop-refresh-btn"
                id="shop-refresh-now"
                title="Fetch the profile now (skips the 10s wait)">↻</button>
      </div>
      <div class="shop-events-mirror" id="shop-events-mirror">
        <div class="shop-empty">Profile not loaded.</div>
      </div>
    </div>
  `;
  details.appendChild(dualPane);

  // ── Defer wiring until next tick so the DOM elements exist ───────────
  setTimeout(() => _shopWireUI(section, bizPanel), 0);

  return details;
}

// ── Storage ─────────────────────────────────────────────────────────────
function _shopLoadFromStorage() {
  try {
    chrome.storage.local.get(["shopCatalog", "shopCart", "shopBrand", "shopCartTracking"], (data) => {
      if (data?.shopCatalog?.products?.length) {
        _shop.products = data.shopCatalog.products;
      }
      if (Array.isArray(data?.shopCart)) {
        _shop.cart = data.shopCart;
      }
      if (typeof data?.shopBrand === "string") {
        _shop.brand = data.shopBrand;
      }
      // Only override the default-true when storage explicitly holds a
      // boolean. Missing key keeps tracking on for first-time users.
      if (typeof data?.shopCartTracking === "boolean") {
        _shop.cartTrackingEnabled = data.shopCartTracking;
      }
      _shopRefreshUI();
    });
  } catch (e) { /* storage unavailable — proceed with empty state */ }
}
function _shopPersistCatalog() {
  try { chrome.storage.local.set({ shopCatalog: { products: _shop.products } }); } catch (_) {}
}
function _shopPersistCart() {
  try { chrome.storage.local.set({ shopCart: _shop.cart }); } catch (_) {}
}
function _shopPersistBrand() {
  try { chrome.storage.local.set({ shopBrand: _shop.brand }); } catch (_) {}
}
function _shopPersistCartTracking() {
  try { chrome.storage.local.set({ shopCartTracking: _shop.cartTrackingEnabled }); } catch (_) {}
}

// ── Wiring ──────────────────────────────────────────────────────────────
function _shopWireUI(section, bizPanel) {
  const fileInput  = document.getElementById("shop-catalog-file");
  const pickBtn    = document.getElementById("shop-catalog-pick");
  const sampleBtn  = document.getElementById("shop-catalog-sample");
  const pdSelect   = document.getElementById("shop-pd-select");
  const skuSelect  = document.getElementById("shop-sku-select");
  const cartPill   = document.getElementById("shop-cart-pill");
  const cartPeek   = document.getElementById("shop-cart-peek");
  if (!fileInput || !pickBtn) return;

  pickBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await _shopLoadCatalogFile(file);
    fileInput.value = ""; // reset so re-selecting the same file fires change
  });

  // Help popover — toggles open/closed on the ? button. Close button
  // and Copy button both wired here so they're not bound to a separate
  // lifecycle.
  const helpBtn   = document.getElementById("shop-catalog-help");
  const helpPop   = document.getElementById("shop-catalog-help-pop");
  const helpClose = document.getElementById("shop-catalog-help-close");
  if (helpBtn && helpPop) {
    helpBtn.addEventListener("click", () => {
      const showing = helpPop.style.display !== "none";
      helpPop.style.display = showing ? "none" : "block";
      helpBtn.classList.toggle("is-active", !showing);
    });
  }
  if (helpClose) {
    helpClose.addEventListener("click", () => {
      helpPop.style.display = "none";
      helpBtn?.classList.remove("is-active");
    });
  }
  // Wire up copy buttons for both queries
  [1, 2].forEach((n) => {
    const btn = document.getElementById(`shop-catalog-help-copy-${n}`);
    const pre = document.getElementById(`shop-catalog-help-sql-${n}`);
    if (!btn || !pre) return;
    btn.addEventListener("click", async () => {
      const sql = pre.textContent || "";
      try {
        await navigator.clipboard.writeText(sql);
        const original = btn.textContent;
        btn.textContent = "✓ Copied";
        btn.classList.add("is-copied");
        setTimeout(() => { btn.textContent = original; btn.classList.remove("is-copied"); }, 1800);
      } catch (e) {
        const range = document.createRange();
        range.selectNodeContents(pre);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        btn.textContent = "Select+Copy";
        setTimeout(() => { btn.textContent = `Copy Query ${n}`; }, 2500);
      }
    });
  });

  sampleBtn.addEventListener("click", async () => {
    try {
      const url = chrome.runtime.getURL("sample-catalog.xlsx");
      const res = await fetch(url);
      const blob = await res.blob();
      await _shopLoadCatalogFile(new File([blob], "sample-catalog.xlsx"));
    } catch (e) {
      _shopSetStatus(`Couldn't load sample: ${e.message}`, "error");
    }
  });

  // Brand chips — single delegated handler so adding a brand to settings.json
  // doesn't require new wiring code.
  const brandChips = document.getElementById("shop-brand-chips");
  if (brandChips) {
    brandChips.addEventListener("click", (e) => {
      const chip = e.target.closest(".shop-brand-chip");
      if (!chip || chip.classList.contains("is-active")) return;
      _shop.brand = chip.dataset.brandId;
      _shopPersistBrand();
      // Update chip states locally without a full re-render — preserves
      // any in-flight product select / cart state.
      brandChips.querySelectorAll(".shop-brand-chip").forEach((c) => {
        const on = c === chip;
        c.classList.toggle("is-active", on);
        c.setAttribute("aria-checked", on ? "true" : "false");
      });
    });
  }

  // Hierarchical pickers. PD change repopulates SKU and auto-picks the
  // first variant so the user lands on a valid selection without an extra
  // click. SKU change resolves the (PD, SKU) pair back to the underlying
  // product row index that downstream code uses.
  if (pdSelect) {
    pdSelect.addEventListener("change", () => {
      const pd = pdSelect.value;
      _shopPopulateSkuSelect(pd);
      // Auto-pick first SKU after repopulation so _shop.selected is non-null
      // when the user has a PD picked but hasn't clicked the SKU dropdown.
      const sku = skuSelect && skuSelect.options.length ? skuSelect.options[0].value : "";
      _shopApplyPdSku(pd, sku);
      // Clear stale lookup status — the user is interacting with the
      // dropdowns, not the manual lookup input.
      const status = document.getElementById("shop-lookup-status");
      if (status) { status.textContent = ""; status.className = "shop-lookup-status"; }
    });
  }
  if (skuSelect) {
    skuSelect.addEventListener("change", () => {
      _shopApplyPdSku(pdSelect?.value || "", skuSelect.value);
    });
  }

  // Manual product ID lookup — Enter on the input or click Find triggers
  // the lookup. We accept both productDisplayId and skuId since users
  // might know either form. Case-insensitive comparison, trimmed.
  const lookupInput = document.getElementById("shop-product-id-input");
  const lookupBtn   = document.getElementById("shop-product-id-find");
  if (lookupInput) {
    lookupInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        _shopFindProductById(lookupInput.value);
      }
    });
  }
  if (lookupBtn) {
    lookupBtn.addEventListener("click", () => {
      _shopFindProductById(lookupInput?.value || "");
    });
  }

  cartPill.addEventListener("click", () => {
    if (!_shop.cart.length) return;
    cartPeek.style.display = cartPeek.style.display === "none" ? "block" : "none";
  });

  // Test Recorder buttons. Both no-op when buffer is empty; Clear wipes the
  // log too so the panes empty together (they're meant to be read as one
  // session). Download serializes the buffer to a Postman v2.1 collection.
  const recClearBtn    = document.getElementById("shop-rec-clear");
  const recDownloadBtn = document.getElementById("shop-rec-download");
  if (recClearBtn) {
    recClearBtn.addEventListener("click", () => {
      _shop.recorded = [];
      _shop.recSeq = 0;
      _shop.log = [];
      _shopRenderLog();
      _shopRenderRecorderHeader();
    });
  }
  if (recDownloadBtn) {
    recDownloadBtn.addEventListener("click", () => _shopDownloadPostman());
  }

  // Manual refresh button next to the countdown pill — skips the 10s
  // wait. Useful when the user knows AEP has caught up faster than the
  // timer expects, or wants to re-check after the auto-refresh ran.
  const refreshNowBtn = document.getElementById("shop-refresh-now");
  if (refreshNowBtn) {
    refreshNowBtn.addEventListener("click", () => {
      const shopperId = document.getElementById("shopperId")?.value?.trim();
      if (!shopperId) return;
      // Cancel any pending auto-refresh so we don't double-fetch.
      if (_shopRefreshTimer) {
        clearTimeout(_shopRefreshTimer);
        _shopRefreshTimer = null;
      }
      _shopDoProfileRefresh();
    });
  }

  // Cart-tracking toggle — flips _shop.cartTrackingEnabled, persists,
  // updates the toggle UI and action-button tooltips so Bag/Wishlist
  // reflect their current side-effect mode at a glance.
  const cartToggleBtn = document.getElementById("shop-cart-tracking-toggle");
  if (cartToggleBtn) {
    cartToggleBtn.addEventListener("click", () => {
      _shop.cartTrackingEnabled = !_shop.cartTrackingEnabled;
      _shopPersistCartTracking();
      _shopRenderCartTrackingToggle();
      _shopRefreshActionButtons();
    });
  }

  // ── Business Events wiring ──────────────────────────────────────────
  _shopWireBizEvents(section, bizPanel);

  _shopRefreshUI();

  // Seed the identity mirror + Profile Events mirror from any cached
  // profile — the user shouldn't have to re-click View Profile on every
  // panel reload just to see who they're shopping as. Cached profile lives
  // in chrome.storage.local from a prior fetch.
  getCachedProfile().then((p) => {
    if (p) {
      _shopUpdateIdentityMirror(p);
      _shopUpdateEventsMirror(p);
    }
  });
}

// ── Business Events ─────────────────────────────────────────────────────
// Back-in-Stock: builds a list of SKUs from catalog; fires backInStockSKUs
// Price Drop: builds a list of {skuId, drop, current}; drop auto-fills from
//   catalog price; fires priceDropSKUs as { skuId: "drop|current" } map

function _shopWireBizEvents(section, bizPanel) {
  // ── Tab switching
  const tabs = document.querySelectorAll(".shop-biz-tab");
  const panes = { bis: document.getElementById("biz-pane-bis"), pd: document.getElementById("biz-pane-pd") };
  tabs.forEach((tab) => {
    tab.addEventListener("click", (e) => {
      bizPanel.open = true;
      tabs.forEach((t) => t.classList.remove("is-active"));
      tab.classList.add("is-active");
      const which = tab.dataset.biz;
      Object.entries(panes).forEach(([k, el]) => { if (el) el.style.display = k === which ? "" : "none"; });
    });
  });

  // ── Back in Stock ──────────────────────────────────────────────────
  const bisItems = [];   // [{ skuId }]
  const bisList  = document.getElementById("biz-bis-list");
  const bisFire  = document.getElementById("biz-bis-fire");
  const bisStatus = document.getElementById("biz-bis-status");

  function bisRerender() {
    bisList.innerHTML = "";
    bisList.className = "biz-bis-chips";
    bisItems.forEach((item, idx) => {
      const chip = document.createElement("span");
      chip.className = "biz-sku-chip";
      chip.innerHTML = `${escapeHtml(item.skuId)}<button type="button" class="biz-chip-rm" title="Remove">×</button>`;
      chip.querySelector(".biz-chip-rm").addEventListener("click", () => {
        bisItems.splice(idx, 1);
        bisRerender();
        _bizUpdateFireBtn(bisFire, bisItems.length > 0);
      });
      bisList.appendChild(chip);
    });
    _bizUpdateFireBtn(bisFire, bisItems.length > 0);
  }

  document.getElementById("biz-bis-add-product")?.addEventListener("click", () => {
    const p = _shop.selected;
    if (!p) { bisStatus.textContent = "⚠ Pick a product first"; setTimeout(() => { bisStatus.textContent = ""; }, 2000); return; }
    const skuId = p.skuId;
    if (bisItems.find((x) => x.skuId === skuId)) { bisStatus.textContent = "Already added"; setTimeout(() => { bisStatus.textContent = ""; }, 1500); return; }
    bisItems.push({ skuId });
    bisRerender();
  });

  bisFire?.addEventListener("click", async () => {
    if (!bisItems.length) return;
    const skuList = bisItems.map((x) => x.skuId).join(",");
    const context = {
      channelBrand:    _shop.brand || "NORDSTROM",
      backInStockSKUs: skuList,
      systemTime:      TE.nowISO(),
      uuid:            _shopUuid(),
      shopperId:       document.getElementById("shopperId")?.value?.trim() || "(no shopper)",
    };
    await _shopFireBizEvent({
      eventId:    "BACK_IN_STOCK",
      context,
      descriptor: `Back in Stock · ${bisItems.length} SKU${bisItems.length > 1 ? "s" : ""} · ${skuList}`,
      statusEl:   bisStatus,
      fireBtn:    bisFire,
      enabledWhen: () => bisItems.length > 0,
    });
  });

  // ── Price Drop ─────────────────────────────────────────────────────
  const pdItems  = [];   // [{ skuId, drop, current }]
  const pdList   = document.getElementById("biz-pd-list");
  const pdFire   = document.getElementById("biz-pd-fire");
  const pdStatus = document.getElementById("biz-pd-status");

  function pdRerender() {
    pdList.innerHTML = "";
    pdItems.forEach((item, idx) => {
      const row = document.createElement("div");
      row.className = "biz-pd-row";

      const skuSpan = document.createElement("span");
      skuSpan.className = "biz-sku-label";
      skuSpan.textContent = item.skuId;

      const dropInp = document.createElement("input");
      dropInp.type = "text";
      dropInp.className = "biz-price-inp";
      dropInp.placeholder = "Drop price";
      dropInp.value = item.drop;
      dropInp.addEventListener("input", () => { item.drop = dropInp.value.trim(); });

      const curInp = document.createElement("input");
      curInp.type = "text";
      curInp.className = "biz-price-inp";
      curInp.placeholder = "Current price";
      curInp.value = item.current;
      curInp.addEventListener("input", () => { item.current = curInp.value.trim(); });

      const rm = document.createElement("button");
      rm.type = "button";
      rm.className = "biz-pd-rm";
      rm.textContent = "×";
      rm.addEventListener("click", () => {
        pdItems.splice(idx, 1);
        pdRerender();
        _bizUpdateFireBtn(pdFire, pdItems.length > 0);
      });

      row.append(skuSpan, dropInp, curInp, rm);
      pdList.appendChild(row);
    });
    _bizUpdateFireBtn(pdFire, pdItems.length > 0);
  }

  document.getElementById("biz-pd-add-product")?.addEventListener("click", () => {
    const p = _shop.selected;
    if (!p) { pdStatus.textContent = "⚠ Pick a product first"; setTimeout(() => { pdStatus.textContent = ""; }, 2000); return; }
    const skuId  = p.skuId;
    if (pdItems.find((x) => x.skuId === skuId)) { pdStatus.textContent = "Already added"; setTimeout(() => { pdStatus.textContent = ""; }, 1500); return; }
    // Drop price defaults to 90% of catalog price; current price = catalog price
    const catalogPrice = parseFloat(p.price) || 0;
    const dropPrice    = catalogPrice > 0 ? (catalogPrice * 0.9).toFixed(2) : "";
    const curPrice     = catalogPrice > 0 ? catalogPrice.toFixed(2) : "";
    pdItems.push({ skuId, drop: dropPrice, current: curPrice });
    pdRerender();
  });

  pdFire?.addEventListener("click", async () => {
    if (!pdItems.length) return;
    const invalid = pdItems.filter((x) => !x.drop || !x.current);
    if (invalid.length) { pdStatus.textContent = "⚠ Fill drop & current price for all rows"; setTimeout(() => { pdStatus.textContent = ""; }, 3000); return; }

    const priceDropSKUs = {};
    pdItems.forEach((x) => { priceDropSKUs[x.skuId] = `${x.drop}|${x.current}`; });
    const priceDropArr = pdItems.map((x) => ({ skuId: x.skuId, sale: x.drop, original: x.current }));

    const context = {
      channelBrand:  _shop.brand || "NORDSTROM",
      priceDropSKUs: priceDropArr,
      systemTime:    TE.nowISO(),
      uuid:          _shopUuid(),
      shopperId:     document.getElementById("shopperId")?.value?.trim() || "(no shopper)",
    };
    await _shopFireBizEvent({
      eventId:    "PRICE_DROP",
      context,
      descriptor: `Price Drop · ${pdItems.length} SKU${pdItems.length > 1 ? "s" : ""} · ${Object.entries(priceDropSKUs).map(([k,v]) => `${k}:${v}`).join(", ")}`,
      statusEl:   pdStatus,
      fireBtn:    pdFire,
      enabledWhen: () => pdItems.length > 0,
    });
  });
}

// Look up the 'business' section from SETTINGS for fireEvent routing
function _shopGetBizSection() {
  return (SETTINGS.sections || []).find((s) => s.id === "business") || null;
}

// Shared fire helper for business events — mirrors _shopFireAction behaviour:
//   • respects the AJO Event Trigger toggle (real vs dry-fire)
//   • records to the Postman recorder buffer
//   • updates the IO request/response panel
//   • appends to the activity log
async function _shopFireBizEvent({ eventId, context, descriptor, statusEl, fireBtn, enabledWhen }) {
  const isBuildOnly = !_shop.cartTrackingEnabled;
  const bizSection  = _shopGetBizSection();
  if (!bizSection) { if (statusEl) statusEl.textContent = "✗ Business section not in settings"; return; }

  if (statusEl) statusEl.textContent = isBuildOnly ? "Building…" : "Firing…";
  if (fireBtn)  fireBtn.disabled = true;

  try {
    const response = await chrome.runtime.sendMessage({
      action:    isBuildOnly ? "dryFireEvent" : "fireEvent",
      sectionId: bizSection.id,
      eventId,
      context,
    });

    if (!response?.ok) {
      const errMsg = response?.error || "Failed";
      if (statusEl) statusEl.textContent = "✗ " + errMsg;
      _shopAppendLog({ eventId, status: "ERR", msg: errMsg, ok: false });
      const ioSection = document.getElementById("io-section");
      setIO(response?.payload ?? {}, response?.responseBody ?? errMsg, response?.status ? `HTTP ${response.status}` : "error", "err", response?.request);
      _shopSetStatus("error", "err");
      if (ioSection) ioSection.open = true;
      return;
    }

    const result = response.result;
    const statusLabel = isBuildOnly ? "DRY" : `HTTP ${result.status}`;
    if (statusEl) statusEl.textContent = isBuildOnly ? `✓ Built (dry)` : `✓ ${statusLabel}`;
    _shopAppendLog({ eventId, status: statusLabel, msg: descriptor, ok: true, dry: isBuildOnly, request: result.request });

    // Record into Postman buffer — same as regular actions
    _shopRecordFire({
      action:     { event: eventId },
      shopperId:  context.shopperId,
      brand:      context.channelBrand || _shop.brand,
      descriptor,
      request:    result.request,
    });

    // IO panel — only on real fires
    if (!isBuildOnly) {
      const ioSection = document.getElementById("io-section");
      setIO(result.payload, result.body, `HTTP ${result.status}`, "ok", result.request);
      _shopSetStatus(`HTTP ${result.status}`, "ok");
      if (ioSection) ioSection.open = true;
    }

  } catch (e) {
    if (statusEl) statusEl.textContent = "✗ " + e.message;
    _shopAppendLog({ eventId, status: "ERR", msg: e.message, ok: false });
  } finally {
    if (fireBtn) fireBtn.disabled = enabledWhen ? !enabledWhen() : false;
    setTimeout(() => { if (statusEl) statusEl.textContent = ""; }, 3000);
  }
}

function _bizUpdateFireBtn(btn, enabled) {
  if (btn) btn.disabled = !enabled;
}

// ── Catalog parsing ─────────────────────────────────────────────────────
async function _shopLoadCatalogFile(file) {
  if (typeof XLSX === "undefined") {
    _shopSetStatus("XLSX library not loaded — reload the extension", "error");
    return;
  }
  try {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    if (!wb.SheetNames?.length) throw new Error("Workbook has no sheets");

    const usedSheet = wb.SheetNames[0];
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[usedSheet], { defval: "" });

    // Header normalization — accept any case variant and strip spaces.
    const norm = (k) => String(k || "").trim().toLowerCase().replace(/\s+/g, "");
    const REQUIRED = ["productdisplayid", "skuid"];

    // Canonical-field mapping. Accept both the simple schema (productName,
    // brand, category) and the richer Nordstrom catalog schema (url,
    // primaryimageurl, isdeleted, sellingretailprice, productrating).
    // When productName/category aren't supplied directly, we derive them
    // from the url column further down.
    const FIELD_MAP = {
      productdisplayid:   "productDisplayId",
      skuid:              "skuId",
      productname:        "productName",
      brand:              "brand",
      category:           "category",
      url:                "url",
      primaryimageurl:    "imageUrl",
      isdeleted:          "isDeleted",
      sellingretailprice: "price",
      productrating:      "rating",
      skuids:             "skuids",
    };

    // Columns that are "known card fields" — anything not in this set AND
    // not in FIELD_MAP is treated as an extra tooltip field.
    const KNOWN_KEYS = new Set(Object.values(FIELD_MAP));

    // Parse a Nordstrom product URL into name + category + brand.
    //   https://www.nordstrom.com/s/jordan-stay-loyal-2/7023110
    //     → name "Jordan Stay Loyal 2", category "/jordan-stay-loyal-2",
    //       brand inferred from host (nordstromrack.com → NORDSTROM_RACK).
    // Returns nullish fields when the URL doesn't match the expected shape
    // so callers can decide whether to fall back to explicit columns.
    const parseProductUrl = (url) => {
      if (!url) return {};
      let u;
      try { u = new URL(url); } catch { return {}; }
      const host = u.hostname.toLowerCase();
      const brand = host.includes("nordstromrack") ? "NORDSTROM_RACK" : "NORDSTROM";
      // Path typically starts with "/s/<slug>/<productDisplayId>". Slug is
      // the second segment when it exists.
      const segments = u.pathname.split("/").filter(Boolean);
      const slug = (segments[0] === "s" && segments[1]) ? segments[1] : segments[segments.length - 2] || "";
      // Humanize the slug for display ("jordan-stay-loyal-2" → "Jordan Stay Loyal 2").
      // Strip pure-numeric trailing tokens so things like "shirt-men-2"
      // don't become "Shirt Men 2" (we keep them; just normalize hyphens).
      const name = slug
        ? slug.replace(/[-_]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())
        : "";
      return { name, category: slug ? "/" + slug : "", brand };
    };

    const products = [];
    let skipped = 0;
    let deletedCount = 0;
    for (const row of rows) {
      // Re-key the row from its actual headers to our canonical names.
      // Coerce to string because xlsx can deserialize numeric-looking SKUs
      // (e.g. "5735767") as JS numbers — we always want strings downstream.
      const canonical = {};
      for (const [k, v] of Object.entries(row)) {
        const target = FIELD_MAP[norm(k)];
        if (target) canonical[target] = (v == null ? "" : String(v)).trim();
      }
      if (!canonical.productDisplayId || !canonical.skuId) {
        skipped++;
        continue;
      }

      // Parse skuids: array stored as JSON string or comma-separated
      if (canonical.skuids) {
        const raw = canonical.skuids.trim();
        if (raw.startsWith("[")) {
          try { canonical.skuidsArr = JSON.parse(raw).map(String); } catch(e) { canonical.skuidsArr = [raw]; }
        } else {
          canonical.skuidsArr = raw.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
        }
      } else {
        canonical.skuidsArr = [];
      }

      // Capture extra columns (anything not in FIELD_MAP) for the ⓘ tooltip
      canonical._extras = {};
      for (const [k, v] of Object.entries(row)) {
        if (!FIELD_MAP[norm(k)] && v != null && String(v).trim() !== "") {
          canonical._extras[k] = String(v).trim();
        }
      }
      // NOTE: We do NOT filter soft-deleted rows here. They flow through
      // so the user can deliberately pick one and test how AEP handles
      // events on deleted products — and the product card surfaces the
      // isdeleted=TRUE flag in red so the warning is unmistakable.
      // Count them for the status line so the user knows the catalog
      // contains some.
      if (canonical.isDeleted && /^(y|yes|true|1)$/i.test(canonical.isDeleted)) {
        deletedCount++;
      }

      // URL-derived enrichment. Explicit columns always win — only fill
      // gaps from the parsed URL.
      if (canonical.url) {
        const parsed = parseProductUrl(canonical.url);
        if (!canonical.productName && parsed.name)     canonical.productName = parsed.name;
        if (!canonical.category    && parsed.category) canonical.category    = parsed.category;
        if (!canonical.brand       && parsed.brand)    canonical.brand       = parsed.brand;
      }

      products.push(canonical);
    }

    if (!products.length) {
      throw new Error(`No valid rows. Required columns: ${REQUIRED.join(", ")}`);
    }

    // Deduplicate by skuId + productDisplayId (first occurrence wins —
    // query orders by lastupdateddate DESC so first = most recent).
    const seenKeys = new Set();
    let dupCount = 0;
    const deduped = products.filter((p) => {
      const key = `${p.skuId}::${p.productDisplayId}`;
      if (seenKeys.has(key)) { dupCount++; return false; }
      seenKeys.add(key);
      return true;
    });
    const dupNote = dupCount ? ` · ${dupCount} duplicate${dupCount > 1 ? "s" : ""} removed` : "";

    _shop.products = deduped;
    _shop.selected = null;
    _shopPersistCatalog();
    const extraSheets = wb.SheetNames.length > 1
      ? ` · ${wb.SheetNames.length - 1} extra sheet${wb.SheetNames.length > 2 ? "s" : ""} ignored`
      : "";
    const skipNote    = skipped      ? ` · ${skipped} skipped (missing fields)` : "";
    const deletedNote = deletedCount ? ` · ${deletedCount} marked isDeleted` : "";
    _shopSetStatus(`Loaded ${deduped.length} products from "${usedSheet}"${extraSheets}${skipNote}${deletedNote}${dupNote}`, "loaded");
    _shopRefreshUI();
  } catch (e) {
    _shopSetStatus(`Parse failed: ${e.message}`, "error");
  }
}

function _shopSetStatus(msg, kind) {
  const el = document.getElementById("shop-catalog-status");
  if (!el) return;
  el.textContent = msg;
  el.className = "shop-catalog-status" + (kind === "loaded" ? " is-loaded" : kind === "error" ? " is-error" : "");
}

// ── UI refresh ──────────────────────────────────────────────────────────
function _shopRefreshUI() {
  const pdSelect  = document.getElementById("shop-pd-select");
  const skuSelect = document.getElementById("shop-sku-select");
  const cartPill  = document.getElementById("shop-cart-pill");
  if (!pdSelect) return;

  if (!_shop.products.length) {
    pdSelect.innerHTML = `<option>Upload a catalog first…</option>`;
    pdSelect.disabled = true;
    if (skuSelect) {
      skuSelect.innerHTML = `<option>—</option>`;
      skuSelect.disabled = true;
    }
  } else {
    // Group products by productDisplayId so multi-SKU products collapse
    // into one PD entry. Sort by productName for readability.
    const byPd = new Map();
    for (let i = 0; i < _shop.products.length; i++) {
      const p = _shop.products[i];
      const pd = p.productDisplayId;
      if (!byPd.has(pd)) {
        byPd.set(pd, { pd, name: p.productName || pd, indices: [] });
      }
      byPd.get(pd).indices.push(i);
    }
    const pdList = Array.from(byPd.values())
      .sort((a, b) => (a.name || a.pd).localeCompare(b.name || b.pd));

    pdSelect.disabled = false;
    pdSelect.innerHTML = `<option value="">— Pick a product —</option>` +
      pdList.map((g) => {
        const skuLabel = g.indices.length > 1 ? ` · ${g.indices.length} SKUs` : "";
        const lbl = `${g.name} (${g.pd})${skuLabel}`;
        return `<option value="${escapeHtml(g.pd)}">${escapeHtml(lbl)}</option>`;
      }).join("");

    // Restore PD + SKU from _shop.selected if one is set.
    if (_shop.selected) {
      pdSelect.value = _shop.selected.productDisplayId || "";
      _shopPopulateSkuSelect(_shop.selected.productDisplayId || "");
      if (skuSelect) skuSelect.value = _shop.selected.skuId || "";
    } else {
      // No selection — leave SKU dropdown empty / disabled.
      _shopPopulateSkuSelect("");
    }
  }

  // Product idcard — replaces the old verbose detail panel. Single line
  // headline (product name) + a compact data line (SKU + display id + price).
  _shopUpdateProductCard();

  // Cart pill + peek.
  if (cartPill) {
    const n = _shop.cart.length;
    cartPill.textContent = `🛒 ${n}`;
    cartPill.className = n ? "cart-pill" : "cart-pill is-empty";
  }
  _shopRenderCartPeek();

  // Action buttons — disable based on need-met state.
  _shopRefreshActionButtons();
  _shopRenderLog();
  _shopRenderRecorderHeader();
  _shopRenderCartTrackingToggle();
}

// Populate the SKU dropdown to show every SKU under the given PD. Called
// on PD change AND from _shopRefreshUI's restore branch. Empty pd
// argument clears + disables the dropdown.
function _shopPopulateSkuSelect(pd) {
  const skuSelect = document.getElementById("shop-sku-select");
  if (!skuSelect) return;
  if (!pd) {
    skuSelect.innerHTML = `<option>—</option>`;
    skuSelect.disabled = true;
    return;
  }
  const variants = _shop.products.filter((p) => p.productDisplayId === pd);
  if (!variants.length) {
    skuSelect.innerHTML = `<option>—</option>`;
    skuSelect.disabled = true;
    return;
  }
  // If only one SKU, render it as a single non-interactive option so the
  // user still sees what SKU will fire.
  skuSelect.disabled = variants.length === 1;
  skuSelect.innerHTML = variants.map((v) => {
    const lbl = v.price ? `${v.skuId} · $${v.price}` : v.skuId;
    return `<option value="${escapeHtml(v.skuId)}">${escapeHtml(lbl)}</option>`;
  }).join("");
}

// Resolve a (PD, SKU) pair to a concrete product row and update
// _shop.selected. Called from both dropdown change handlers and the
// manual lookup. Updates _shop.selected directly then triggers a refresh
// of dependent UI (action buttons, product card). Does NOT call
// _shopPopulateSkuSelect — the caller has already done that when needed.
function _shopApplyPdSku(pd, sku) {
  if (!pd) {
    _shop.selected = null;
  } else {
    const row = _shop.products.find(
      (p) => p.productDisplayId === pd && (!sku || p.skuId === sku)
    ) || _shop.products.find((p) => p.productDisplayId === pd) || null;
    _shop.selected = row;
  }
  _shopUpdateProductCard();
  _shopRefreshActionButtons();
}

// Update the right-hand product idcard with the currently-selected
// product's headline + key IDs. Empty state shows a hint.
function _shopUpdateProductCard() {
  const card = document.getElementById("shop-card-product");
  if (!card) return;
  const body = card.querySelector(".shop-idcard-body");
  if (!body) return;
  const p = _shop.selected;
  if (!p) {
    body.className = "shop-idcard-body shop-idcard-empty";
    body.textContent = "Upload a catalog and pick a product.";
    return;
  }
  body.className = "shop-idcard-body";

  // Primary detail line — IDs and price.
  const detailParts = [];
  if (p.skuId)            detailParts.push(`SKU ${p.skuId}`);
  if (p.productDisplayId) detailParts.push(`PD ${p.productDisplayId}`);
  if (p.price)            detailParts.push(`$${p.price}`);

  // Presence flags — the catalog columns coming from the Query Service
  // query carry url/imageurl/isdeleted, and the testing workflow cares
  // about whether they're populated rather than the actual values. Replaces
  // the older "open ↗" link.
  const isDeletedRaw = (p.isDeleted || "").toString().trim();
  const isDeletedTrue = /^(y|yes|true|1)$/i.test(isDeletedRaw);
  // isDeleted is special: even an empty string reads as "not deleted",
  // which is the common case after our parser already filtered TRUE rows.
  const flags = [
    {
      label: "url",
      present: !!p.url,
      cls: p.url ? "is-present" : "is-absent",
    },
    {
      label: "image",
      present: !!p.imageUrl,
      cls: p.imageUrl ? "is-present" : "is-absent",
    },
    {
      label: `isdeleted ${isDeletedTrue ? "TRUE" : "FALSE"}`,
      present: true, // always show — the value matters either way
      cls: isDeletedTrue ? "is-deleted-true" : "is-deleted-false",
    },
  ];
  const flagsHtml = flags.map((f) => `
    <span class="shop-flag ${f.cls}">${escapeHtml(f.label)}${
      // For url/image, no value — just label means "present"; "absent"
      // styling dims it. isdeleted carries its value in the label.
      f.label === "url" || f.label === "image"
        ? (f.present ? " present" : " absent")
        : ""
    }</span>
  `).join("");

  body.innerHTML = `
    <div class="shop-idcard-name">${escapeHtml(p.productName || p.productDisplayId)}</div>
    <div class="shop-idcard-detail">${escapeHtml(detailParts.join(" · "))}</div>
    <div class="shop-flags">${flagsHtml}</div>
  `;

  // ⓘ tooltip — show skuids array + any extra columns after productrating
  const hasExtras = (p.skuidsArr && p.skuidsArr.length) || Object.keys(p._extras || {}).length > 0;
  if (hasExtras) {
    // Remove stale popover if any
    const old = document.getElementById("shop-info-popover");
    if (old) old.remove();

    const tipBtn = document.createElement("button");
    tipBtn.type = "button";
    tipBtn.className = "shop-info-tip-btn";
    tipBtn.title = "Extra details";
    tipBtn.textContent = "ⓘ";
    body.appendChild(tipBtn);

    const popover = document.createElement("div");
    popover.id = "shop-info-popover";
    popover.className = "shop-info-popover";
    popover.style.display = "none";

    let rows = "";
    if (p.skuidsArr && p.skuidsArr.length) {
      rows += `<div class="shop-info-row"><span class="shop-info-label">skuids</span><span class="shop-info-val">${escapeHtml(p.skuidsArr.join(", "))}</span></div>`;
    }
    Object.entries(p._extras || {}).forEach(([k, v]) => {
      rows += `<div class="shop-info-row"><span class="shop-info-label">${escapeHtml(k)}</span><span class="shop-info-val">${escapeHtml(v)}</span></div>`;
    });
    popover.innerHTML = `<div class="shop-info-title">PDID SkuIds</div>${rows}`;
    body.appendChild(popover);

    tipBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const showing = popover.style.display !== "none";
      popover.style.display = showing ? "none" : "block";
    });
    document.addEventListener("click", () => { popover.style.display = "none"; }, { once: true });
  }
}

function _shopRenderCartPeek() {
  const peek = document.getElementById("shop-cart-peek");
  if (!peek) return;
  if (!_shop.cart.length) {
    peek.style.display = "none";
    peek.innerHTML = "";
    return;
  }
  peek.innerHTML = _shop.cart.map((it, i) => `
    <div class="cart-peek-row">
      <span>${escapeHtml(it.productName || it.skuId)} <span style="color:#6a7a90;">(${escapeHtml(it.skuId)})</span></span>
      <span class="cart-rm" data-idx="${i}" title="Remove">✕</span>
    </div>
  `).join("");
  peek.querySelectorAll(".cart-rm").forEach((el) => {
    el.addEventListener("click", () => {
      const idx = parseInt(el.dataset.idx, 10);
      _shop.cart.splice(idx, 1);
      _shopPersistCart();
      _shopRefreshUI();
    });
  });
}

// Re-render the cart-tracking toggle (ON/OFF visual + hint). Called on
// toggle click and on _shopRefreshUI (so storage-loaded state surfaces
// after the panel reloads).
function _shopRenderCartTrackingToggle() {
  const btn = document.getElementById("shop-cart-tracking-toggle");
  const hint = document.getElementById("shop-toggle-hint");
  if (!btn) return;
  const on = !!_shop.cartTrackingEnabled;
  btn.classList.toggle("is-on", on);
  btn.classList.toggle("is-off", !on);
  btn.setAttribute("aria-checked", on ? "true" : "false");
  const txt = btn.querySelector(".shop-toggle-text");
  if (txt) txt.textContent = on ? "ON" : "OFF";
  if (hint) {
    hint.textContent = on
      ? "Fires AJO events as you click"
      : "Build-only — cart updates, no AJO fires (still recorded for Postman)";
  }
}

function _shopRefreshActionButtons() {
  const section = (SETTINGS.sections || []).find((s) => s.type === "shop");
  if (!section) return;
  for (const action of section.actions || []) {
    const btn = document.querySelector(`.shop-action-btn[data-action-id="${action.id}"]`);
    if (!btn) continue;
    const reasons = [];
    if (action.needs?.includes("product") && !_shop.selected)    reasons.push("Pick a product");
    // NOTE: We deliberately do NOT block on "cart is empty" any more.
    // Order/Retail are valid test fires with an empty items[] — the user
    // might be testing how the journey handles a no-items event.
    if (action.needs?.includes("journey"))                       reasons.push("Open a journey tab");
    const shopperId = document.getElementById("shopperId")?.value?.trim();
    if (!shopperId) reasons.push("Enter a Shopper ID");
    btn.disabled = reasons.length > 0;
    btn.title = reasons.length ? reasons.join(" · ") : `Fires ${action.event}`;

    // Dynamic suffix on the short label — Bag shows current cart count so
    // the user can see at a glance "I have 3 items pending an Order".
    // Order shows the same so the user knows how many will be sent.
    const shortEl = btn.querySelector(".action-short");
    if (shortEl) {
      const base = shortEl.dataset.actionId === action.id ? shortEl.textContent.replace(/\s*\(\d+\)\s*$/, "") : null;
      const baseLabel = (base || shortEl.textContent).replace(/\s*\(\d+\)\s*$/, "");
      const showCount = (action.id === "addBag" || action.id === "order" || action.id === "retail") && _shop.cart.length > 0;
      shortEl.textContent = showCount ? `${baseLabel} (${_shop.cart.length})` : baseLabel;
    }

    // Reset transient state colors (is-firing / is-ok / is-err clear after 3s
    // by the dispatcher, but if the user toggles state inputs we want clean
    // buttons immediately).
    if (!btn.classList.contains("is-firing")) {
      btn.classList.remove("is-ok", "is-err");
    }
  }
}

// ── Action dispatch — reuses existing fireEvent message ─────────────────
async function _shopFireAction(section, action) {
  const btn = document.querySelector(`.shop-action-btn[data-action-id="${action.id}"]`);
  if (btn) { btn.classList.add("is-firing"); btn.disabled = true; }

  // Build-only mode: when cart tracking is OFF, the toggle's semantic is
  // "do not touch AJO — build the request shape locally so the Postman
  // recorder still captures it, and update the cart so subsequent
  // Order/Retail fires reflect a realistic cart state". The user opted
  // in to a build-only workflow for replay later.
  const isBuildOnly = !_shop.cartTrackingEnabled;

  try {
    const context = await _shopBuildContext(action);

    // Route to either fireEvent (real HTTP) or dryFireEvent (no fetch,
    // returns same request shape). Background owns both — we just pick.
    const response = await chrome.runtime.sendMessage({
      action: isBuildOnly ? "dryFireEvent" : "fireEvent",
      sectionId: action.section,
      eventId:   action.event,
      context,
    });

    if (!response || !response.ok) {
      const errMsg = response?.error || (isBuildOnly ? "Dry-fire failed" : "Fire failed");
      _shopAppendLog({ eventId: action.event, status: response?.status || "ERR", msg: errMsg, ok: false });
      _shopBtnFlash(btn, "err");
      return;
    }

    const result = response.result;
    const statusLabel = isBuildOnly ? "DRY" : `HTTP ${result.status}`;
    _shopAppendLog({
      eventId: action.event,
      status:  statusLabel,
      msg:     _shopActionMsg(action, context),
      ok:      true,
      dry:     isBuildOnly,
      request: result.request,
    });
    _shopBtnFlash(btn, "ok");

    // Record this fire into the Postman recorder buffer regardless of
    // whether it was a real fire or a dry one — the captured request is
    // identical in shape, which is the whole point of dry mode.
    _shopRecordFire({
      action,
      shopperId: context.shopperId,
      brand:     context.channelBrand || _shop.brand,
      descriptor: _shopActionMsg(action, context),
      request:    result.request,
    });

    // Mirror the existing IO panel update — only when this was a real
    // fire. Build-only mode has no response body, and the IO panel's
    // status indicator would lie if we showed "OK" for something that
    // never hit the wire.
    if (!isBuildOnly) {
      const ioSection = document.getElementById("io-section");
      if (ioSection) {
        setIO(result.payload, result.body, `HTTP ${result.status}`, "ok", result.request);
      }
    }

    // Cart side-effects — ALWAYS apply, regardless of mode. The toggle is
    // about firing to AJO, not about cart accounting. In build-only mode
    // this lets you populate a 3-item cart locally, then click Order and
    // have it capture a realistic 3-item ORDER_SUBMITTED payload.
    if (action.addsToCart && _shop.selected) {
      _shop.cart.push({
        productDisplayId: _shop.selected.productDisplayId,
        skuId:            _shop.selected.skuId,
        productName:      _shop.selected.productName || "",
      });
      _shopPersistCart();
      _shopRefreshUI();
    }
    if (action.consumesCart) {
      _shop.cart = [];
      _shopPersistCart();
      _shopRefreshUI();
    }

    // Profile auto-refresh — only on real fires. Build-only mode didn't
    // touch AEP so there's nothing new on the profile to fetch.
    if (!isBuildOnly && document.getElementById("shopperId")?.value?.trim()) {
      _shopScheduleProfileRefresh();
    }
  } catch (e) {
    _shopAppendLog({ eventId: action.event, status: "ERR", msg: e.message, ok: false });
    _shopBtnFlash(btn, "err");
  } finally {
    if (btn) btn.classList.remove("is-firing");
    _shopRefreshActionButtons();
  }
}

// Build the context object the fireEvent handler expects, based on which
// event's payload schema we're targeting. The key insight: the existing
// event payloads pull from named template vars (skuItems, skuId, etc.) —
// so we just need to populate those.
async function _shopBuildContext(action) {
  const p = _shop.selected;
  const shopperId = document.getElementById("shopperId")?.value?.trim() || "";
  // User-selected brand wins on every event. Falls back to the product's
  // own brand column (if catalog supplied one) and finally NORDSTROM so
  // older catalogs without a brand selector still work.
  const channelBrand = _shop.brand || p?.brand || "NORDSTROM";
  const ctx = {
    shopperId,
    systemTime:   TE.nowISO(),
    eventTime:    TE.nowISO(),
    uuid:         _shopUuid(),
    channelBrand,
  };
  // Per-event field population.
  switch (action.event) {
    case "PRODUCT_DETAIL_VIEWED":
      ctx.skuItems = p ? [{ productDisplayId: p.productDisplayId, skuId: p.skuId }] : [];
      break;
    case "BAG":
      ctx.bagType  = "SHOPPING_BAG";
      ctx.skuItems = p ? [{ skuId: p.skuId, lastModifyTime: ctx.eventTime }] : [];
      break;
    case "ADDED_SKU_TO_WISHLIST":
      ctx.skuItems = p ? [{ skuId: p.skuId }] : [];
      break;
    case "BROWSE_SEARCH_RESULTS":
      ctx.browsePath = p?.category || "/home";
      ctx.skuItems   = p ? [{ skuId: p.skuId }] : [];
      break;
    case "ORDER_SUBMITTED":
      ctx.orderNumber = "N" + Math.floor(Math.random() * 1e10);
      ctx.purchaseId  = "P-" + Math.floor(Math.random() * 1e6);
      ctx.skuItems    = _shop.cart.map((it) => ({ skuId: it.skuId }));
      break;
    case "CUSTOMER_RETAIL_TRANSACTION":
      // CRT uses a different identity schema than the other events: top-
      // level `customerIdType` + `customerId`. The settings template
      // defaults to OPERATIONAL_CUSTOMER_PROFILE_ID, which requires a
      // cached customerProfileId from a prior profile load — but the
      // Shop simulator is self-sufficient and the dispatcher path
      // doesn't call into requiresFromProfile resolution. So we force
      // SHOPPER_ID for the Shop flow: the payload identifies the customer
      // via the same shopperId field every other event uses, and the
      // event lands on the profile reliably. If a power user wants the
      // OPERATIONAL_CUSTOMER_PROFILE_ID variant, they can do it from the
      // granular sibling extension's form UI.
      ctx.customerIdType  = "SHOPPER_ID";
      // Also opportunistically populate customerProfileId from any
      // cached profile, so a future switch to OPERATIONAL_CUSTOMER_PROFILE_ID
      // would just work without re-fetching.
      try {
        const cached = await getCachedProfile();
        const cpid = digIdentity(cached, "customerProfileId");
        if (cpid) ctx.customerProfileId = cpid;
      } catch (_) { /* cache miss is fine — SHOPPER_ID path doesn't need it */ }
      ctx.purchaseId      = "P-" + Math.floor(Math.random() * 1e6);
      ctx.transactionTime = ctx.eventTime;
      ctx.skuItems        = _shop.cart.map((it) => ({ skuId: it.skuId }));
      break;
  }
  return ctx;
}

function _shopUuid() {
  // RFC4122-ish v4 UUID, browser-safe (crypto.randomUUID exists in MV3 sw
  // but not always in side panel context).
  if (typeof crypto?.randomUUID === "function") return crypto.randomUUID();
  const hex = [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-4${hex.slice(13,16)}-${(parseInt(hex[16],16)&3|8).toString(16)}${hex.slice(17,20)}-${hex.slice(20,32)}`;
}

function _shopActionMsg(action, context) {
  const p = _shop.selected;
  if (action.event === "ORDER_SUBMITTED" || action.event === "CUSTOMER_RETAIL_TRANSACTION") {
    return `${_shop.cart.length || 0} item${_shop.cart.length === 1 ? "" : "s"}`;
  }
  return p ? `${p.productName || p.productDisplayId} (${p.skuId})` : "(no product)";
}

function _shopBtnFlash(btn, kind) {
  if (!btn) return;
  btn.classList.add("is-" + kind);
  setTimeout(() => btn.classList.remove("is-" + kind), 3000);
}

// ── Activity log ────────────────────────────────────────────────────────
function _shopAppendLog(entry) {
  _shop.log.unshift({ ts: new Date(), ...entry });
  if (_shop.log.length > 50) _shop.log.length = 50;
  _shopRenderLog();
}
function _shopRenderLog() {
  const el = document.getElementById("shop-log");
  if (!el) return;
  if (!_shop.log.length) {
    el.innerHTML = `<div class="shop-log-empty">No actions yet.</div>`;
    return;
  }
  el.replaceChildren(..._shop.log.map((row) => {
    const statusCls = row.dry ? "dry" : (row.ok ? "ok" : "err");
    const wrap = document.createElement("div");
    wrap.className = "shop-log-row";
    wrap.innerHTML = `
      <div class="shop-log-ts">${row.ts.toLocaleTimeString()}</div>
      <div class="shop-log-event">${escapeHtml(row.eventId)}</div>
      <div class="shop-log-msg">${escapeHtml(row.msg)}</div>
      <div class="shop-log-badges">
        <span class="shop-log-status ${statusCls}">${escapeHtml(row.status)}</span>
      </div>`;

    // cURL copy button — only when we have request meta
    if (row.request?.url) {
      const curlBtn = document.createElement("button");
      curlBtn.type = "button";
      curlBtn.className = "shop-log-curl-btn";
      curlBtn.title = "Copy as cURL";
      curlBtn.textContent = "cURL";
      curlBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const curl = buildCurlCommand(row.request);
        if (!curl) return;
        navigator.clipboard.writeText(curl).then(() => {
          const orig = curlBtn.textContent;
          curlBtn.textContent = "✓";
          curlBtn.classList.add("is-copied");
          setTimeout(() => { curlBtn.textContent = orig; curlBtn.classList.remove("is-copied"); }, 1800);
        }).catch(() => {
          curlBtn.textContent = "⚠";
          setTimeout(() => { curlBtn.textContent = "cURL"; }, 1800);
        });
      });
      wrap.querySelector(".shop-log-badges").appendChild(curlBtn);
    }

    return wrap;
  }));
}

// ── Profile auto-refresh with diff highlight ────────────────────────────
// After a successful fire, schedule a full profile re-fetch ~2 min later
// (audience qualification and event ingestion in AEP can take minutes,
// not seconds — a 5s refresh would just show the same profile back).
// Before re-render, snapshot the currently-rendered audience names, event
// types, and SCA keys. After re-render, mark any new entries with the
// .is-new class, which triggers a green pulse + "NEW" suffix from the CSS
// so the user can see what their actions actually qualified them for.
const SHOP_REFRESH_DELAY_MS = 10 * 1000;
let _shopRefreshTimer = null;
function _shopScheduleProfileRefresh() {
  if (_shopRefreshTimer) clearTimeout(_shopRefreshTimer);
  // Show a hint in the activity log so the user knows a refresh is queued.
  _shopShowRefreshCountdown();
  _shopRefreshTimer = setTimeout(_shopDoProfileRefresh, SHOP_REFRESH_DELAY_MS);
}
// Live indicator that ticks down so the user knows a refresh is queued
// (a silent 2-minute wait looks broken). Lives in a small pill near the
// activity-log header. Updates every second until the timer fires.
let _shopCountdownTicker = null;
function _shopShowRefreshCountdown() {
  if (_shopCountdownTicker) clearInterval(_shopCountdownTicker);
  const deadline = Date.now() + SHOP_REFRESH_DELAY_MS;
  const pill = document.getElementById("shop-refresh-status");
  if (!pill) return;
  const tick = () => {
    const remaining = deadline - Date.now();
    if (remaining <= 0) {
      pill.textContent = "Refreshing profile…";
      pill.classList.add("is-active");
      clearInterval(_shopCountdownTicker);
      _shopCountdownTicker = null;
      return;
    }
    const m = Math.floor(remaining / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    pill.textContent = m > 0 ? `Profile refresh in ${m}m ${s}s` : `Profile refresh in ${s}s`;
    pill.classList.add("is-active");
  };
  tick();
  _shopCountdownTicker = setInterval(tick, 1000);
}
function _shopClearRefreshCountdown(finalMsg) {
  if (_shopCountdownTicker) {
    clearInterval(_shopCountdownTicker);
    _shopCountdownTicker = null;
  }
  const pill = document.getElementById("shop-refresh-status");
  if (!pill) return;
  if (finalMsg) {
    pill.textContent = finalMsg;
    pill.classList.add("is-active");
    setTimeout(() => {
      pill.textContent = "";
      pill.classList.remove("is-active");
    }, 4000);
  } else {
    pill.textContent = "";
    pill.classList.remove("is-active");
  }
}

async function _shopDoProfileRefresh() {
  _shopRefreshTimer = null;
  const shopperId = document.getElementById("shopperId")?.value?.trim();
  if (!shopperId) {
    _shopClearRefreshCountdown();
    return;
  }
  try {
    // Snapshot existing rendered identifiers so we can diff after refresh.
    const before = _shopSnapshotProfilePanels();

    // Trigger same code path as clicking View Profile — using the existing
    // viewProfile RPC keeps everything (caching, renderers, panel state)
    // identical to the manual flow.
    const response = await chrome.runtime.sendMessage({
      action:    "viewProfile",
      shopperId,
    });
    if (!response?.ok || !response.result) {
      _shopClearRefreshCountdown("Refresh failed");
      return;
    }

    renderProfile(response.result);

    // After render completes, mark new items + update the pill with what
    // changed so the user can see the refresh actually did something.
    requestAnimationFrame(() => {
      const newCount = _shopHighlightNew(before);
      _shopClearRefreshCountdown(
        newCount > 0 ? `Profile refreshed · ${newCount} new` : "Profile refreshed · no changes"
      );
    });
  } catch (e) {
    // Fail silently — auto-refresh is opportunistic. The manual View Profile
    // button still works if the user wants to retry.
    console.warn("Shop auto-refresh failed:", e);
    _shopClearRefreshCountdown("Refresh failed");
  }
}

function _shopSnapshotProfilePanels() {
  // Collect identifier text from the rendered DOM. Cheaper than re-fetching
  // the cached profile and walking it ourselves, and works regardless of
  // which renderer (audiences/events/SCA) produced the row.
  const grab = (sel) => new Set(
    [...document.querySelectorAll(sel)].map((el) => el.textContent.trim())
  );
  return {
    audiences: grab("#profile-audiences .aud-name"),
    events:    grab("#profile-events .profile-table td.cell-key"),
    sca:       grab("#profile-sca .profile-table td.cell-key"),
  };
}
// Update the left Shopping-as card with current profile values. Compact
// format: shopperId headline, enterpriseId · sandbox secondary line, then
// the AEP profile link. Sandbox switches to red text when on prod.
function _shopUpdateIdentityMirror(p) {
  const card = document.getElementById("shop-card-shopper");
  if (!card || !p) return;
  const body = card.querySelector(".shop-idcard-body");
  if (!body) return;

  const sandboxStr = String(p.sandbox || "").toLowerCase().trim();
  const isProd = sandboxStr === "prod" || sandboxStr === "production";
  card.classList.toggle("is-prod", isProd);

  const shopperId = p.shopperId || "—";
  const entId     = digIdentity(p, "enterpriseId");
  const sandbox   = p.sandbox || "—";

  // Build the secondary line: prefer enterpriseId · sandbox; fall back to
  // sandbox-only when no enterprise id available.
  const sandboxHtml = isProd
    ? `<span class="sandbox-badge sandbox-prod">⚠ ${escapeHtml(sandbox).toUpperCase()}</span>`
    : escapeHtml(sandbox);
  const detailParts = [];
  if (entId)   detailParts.push(escapeHtml(entId));
  if (sandbox) detailParts.push(sandboxHtml);

  let linkHtml = "";
  if (p.profileId) {
    const tenant   = p.tenant  || SETTINGS.tenant  || "@nordstrom";
    const sandboxV = p.sandbox || SETTINGS.sandbox || "prod";
    const url = SETTINGS.profileUrlTemplate
      ? TE.tplStr(SETTINGS.profileUrlTemplate, { tenant, sandbox: sandboxV, profileId: p.profileId })
      : `https://experience.adobe.com/#/${tenant}/sname:${sandboxV}/journey-optimizer/platform/profile/browse/${p.profileId}/experienceEvents`;
    linkHtml = `<a class="shop-idcard-link" href="${url}" target="_blank" rel="noopener">View in AEP ↗</a>`;
  }

  body.className = "shop-idcard-body";
  body.innerHTML = `
    <div class="shop-idcard-name">${escapeHtml(shopperId)}</div>
    <div class="shop-idcard-detail">${detailParts.join(" · ")}</div>
    ${linkHtml}
  `;
}

function _shopHighlightNew(before) {
  let total = 0;
  const tag = (sel, beforeSet) => {
    for (const el of document.querySelectorAll(sel)) {
      const txt = el.textContent.trim();
      if (!beforeSet.has(txt)) {
        el.classList.add("is-new");
        total++;
      }
    }
  };
  tag("#profile-audiences .aud-name", before.audiences);
  tag("#profile-events .profile-table td.cell-key", before.events);
  tag("#profile-sca .profile-table td.cell-key", before.sca);
  return total;
}

// ─────────────────────────────────────────────────────────────────────────────
// TEST RECORDER
// — Captures successful fires as a sequenced collection that can be
// exported as a Postman v2.1 collection JSON. Each entry preserves the
// full HTTP snapshot (URL, method, headers, body) and session metadata
// (shopper, brand, event, descriptor) used to build a sortable name.
//
// The exported collection uses {{IMS_TOKEN}} as a collection-level
// variable so the user can refresh the token in one place when it
// expires (~24h cycle). Bodies are postmanized the same way Copy-as-cURL
// already does — ephemeral _id fields become {{$guid}}, timestamp fields
// become {{$isoTimestamp}}.
// ─────────────────────────────────────────────────────────────────────────────

function _shopRecordFire({ action, shopperId, brand, descriptor, request }) {
  if (!request || !request.url) return; // background didn't surface a request — skip
  _shop.recSeq += 1;
  // Pull the primary product identifier out of the rendered body so the
  // Postman collection name can include it. Looks first at productDisplayId
  // (PDV events), then skuId (Bag/Wishlist/Browse/Order/Retail). Multi-item
  // events (Order/Retail) use the first item — keeps the name readable.
  const productKey = _shopExtractProductKey(request.body);
  _shop.recorded.push({
    seq:        _shop.recSeq,
    ts:         new Date().toISOString(),
    shopperId:  shopperId || "(no shopper)",
    brand:      brand || "—",
    event:      action.event,
    descriptor: descriptor || "",
    productKey: productKey || "",   // for the Postman name format
    request:    request,
  });
  // Cap the buffer — drop oldest fires when over limit. The seq counter
  // keeps moving forward so collection numbering remains monotonic even
  // if the buffer rotated.
  if (_shop.recorded.length > SHOP_RECORDED_MAX) {
    _shop.recorded.splice(0, _shop.recorded.length - SHOP_RECORDED_MAX);
  }
  _shopRenderRecorderHeader();
}

// Manual lookup of a product by user-entered ID. Matches against both
// productDisplayId and skuId since either is a valid identifier and users
// might have one or the other on hand. Strict exact-match (case-insensitive,
// trimmed) — we deliberately don't fuzzy-match because firing events on
// the wrong product silently is worse than failing loudly.
function _shopFindProductById(rawInput) {
  const status = document.getElementById("shop-lookup-status");
  const id = (rawInput || "").trim();
  if (!id) {
    if (status) { status.textContent = ""; status.className = "shop-lookup-status"; }
    return;
  }
  if (!_shop.products.length) {
    if (status) { status.textContent = "No catalog loaded — upload one first."; status.className = "shop-lookup-status is-error"; }
    return;
  }
  const idLower = id.toLowerCase();
  // Compare both fields per row. Most catalogs differentiate skuId (alpha-
  // numeric) from productDisplayId (numeric) clearly, but we don't assume.
  const matchIdx = _shop.products.findIndex(
    (p) => (p.productDisplayId || "").toLowerCase() === idLower
        || (p.skuId            || "").toLowerCase() === idLower
  );
  if (matchIdx < 0) {
    // Miss — leave current selection untouched. The simulator refuses to
    // load a phantom product; the user has to fix the ID or update the
    // catalog upload.
    if (status) {
      status.textContent = `Not in catalog: ${id}`;
      status.className = "shop-lookup-status is-error";
    }
    return;
  }
  // Hit — select the product. Both dropdowns get updated to stay in sync
  // with the resolved row. The hierarchical model: lookup might match
  // either a productDisplayId or a skuId, so we update PD then populate
  // SKU and pick the matched SKU (or first if the input was a PD).
  _shop.selected = _shop.products[matchIdx];
  const pdSelect  = document.getElementById("shop-pd-select");
  const skuSelect = document.getElementById("shop-sku-select");
  if (pdSelect)  pdSelect.value = _shop.selected.productDisplayId || "";
  _shopPopulateSkuSelect(_shop.selected.productDisplayId || "");
  if (skuSelect) skuSelect.value = _shop.selected.skuId || "";
  if (status) {
    status.textContent = `Found: ${_shop.selected.productName || _shop.selected.productDisplayId}`;
    status.className = "shop-lookup-status is-ok";
  }
  _shopUpdateProductCard();
  _shopRefreshActionButtons();
}

// Walk the body's items array to find a usable product identifier for
// the Postman collection name. The rendered payloads put items at
// `_nordstrom.events.items` for the DCS event family; defensively check
// other common shapes too.
function _shopExtractProductKey(body) {
  if (!body || typeof body !== "object") return "";
  // The rendered shape is body.messages[0]._nordstrom.events.items
  const message = body.messages?.[0];
  const items = message?._nordstrom?.events?.items;
  if (Array.isArray(items) && items.length > 0) {
    const it = items[0];
    return it.productDisplayId || it.skuId || "";
  }
  return "";
}

function _shopRenderRecorderHeader() {
  const count    = _shop.recorded.length;
  const countEl  = document.getElementById("shop-rec-count");
  const downEl   = document.getElementById("shop-rec-download");
  const clearEl  = document.getElementById("shop-rec-clear");
  if (countEl) {
    countEl.textContent = count === 1 ? "1 fire" : `${count} fires`;
    countEl.classList.toggle("is-empty", count === 0);
  }
  if (downEl)  downEl.disabled  = count === 0;
  if (clearEl) clearEl.disabled = count === 0;
}

// Serialize the recorder buffer to a Postman v2.1 collection and trigger
// a browser download. Each fire becomes one collection item with a name
// like "[01] SHOP0000000301 · NORDSTROM · BAG · Linen Shirt" so the items
// sort in the order they were fired and you can scan the list visually.
function _shopDownloadPostman() {
  if (!_shop.recorded.length) return;
  const collection = _shopBuildPostmanCollection();
  const json = JSON.stringify(collection, null, 2);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const filename = `ajo-shop-test-${stamp}.postman_collection.json`;

  // URL.createObjectURL is blocked in MV3 side panels — use a data URI instead.
  const dataUrl = "data:application/json;charset=utf-8," + encodeURIComponent(json);
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function _shopBuildPostmanCollection() {
  const stamp = new Date().toISOString();
  // Width of the [NN] prefix — at least 2 digits, more if we crossed 99.
  const pad   = Math.max(2, String(_shop.recorded[_shop.recorded.length - 1].seq).length);

  // Grab the current IMS token from any one captured request so the
  // collection has a sane initial value. The user will refresh it via the
  // collection variable when it expires (~24h cycle).
  const sampleAuth = _shop.recorded
    .map((r) => r.request?.headers?.Authorization)
    .find((a) => a && /^Bearer\s+/.test(a)) || "Bearer ";
  const sampleToken = sampleAuth.replace(/^Bearer\s+/, "");

  // Build a stable shopperId → variable name map. Each unique shopper
  // gets its own SHOPPER_ID_N variable (numbered in order of first
  // appearance in the recorder buffer). The body substitution swaps
  // every literal occurrence of these IDs for the variable reference,
  // so the user can run the collection against different shoppers by
  // editing the variables in Postman.
  const shopperIdToVar = {};
  const shopperVarsInOrder = [];
  let nextShopperVarIdx = 1;
  for (const rec of _shop.recorded) {
    const sid = rec.shopperId;
    // Skip the placeholder when the user hadn't entered a shopper id —
    // there's nothing useful to variableize. Keep its literal value
    // (which is "(no shopper)") in the body where it appears.
    if (!sid || sid === "(no shopper)") continue;
    if (!shopperIdToVar[sid]) {
      const varName = `SHOPPER_ID_${nextShopperVarIdx++}`;
      shopperIdToVar[sid] = varName;
      shopperVarsInOrder.push({ key: varName, value: sid, type: "string" });
    }
  }

  const items = _shop.recorded.map((rec) => _shopBuildPostmanItem(rec, pad, shopperIdToVar));

  // Build the description block dynamically so the per-shopper variable
  // table is included when present.
  const descLines = [
    "Recorded fires from the AJO Shop Simulator extension.",
    "",
    "Collection variables:",
    "  • IMS_TOKEN — bearer token used in the Authorization header. Refresh in Variables tab when it expires (~24h).",
  ];
  if (shopperVarsInOrder.length) {
    descLines.push("  • SHOPPER_ID_N — one per unique shopper recorded. Edit values in Variables tab to retarget the collection at a different shopper.");
    descLines.push("");
    descLines.push("Recorded shoppers:");
    for (const v of shopperVarsInOrder) {
      descLines.push(`  • {{${v.key}}} = ${v.value}`);
    }
  }
  descLines.push("");
  descLines.push("Body placeholders that auto-regenerate on each Send:");
  descLines.push("  • {{$guid}}          — fresh UUID v4 (used for _id, productTriggerId)");
  descLines.push("  • {{$isoTimestamp}}  — current ISO timestamp (used for systemTime, eventTime, transactionTime, lastModifyTime, etc.)");

  return {
    info: {
      name:        `AJO Shop Test · ${stamp}`,
      description: descLines.join("\n"),
      schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
      _postman_id: _shopUuid(),
    },
    variable: [
      { key: "IMS_TOKEN", value: sampleToken, type: "string" },
      ...shopperVarsInOrder,
    ],
    item: items,
  };
}

function _shopBuildPostmanItem(rec, pad, shopperIdToVar) {
  const req = rec.request;
  const seqStr = String(rec.seq).padStart(pad, "0");

  // Name format: "01-BAG-7023110-N"
  // Order: sequence, event, product (productDisplayId or skuId fallback),
  // brand shorthand (N/NR). Shopper id deliberately omitted — it's
  // represented by the {{SHOPPER_ID_N}} variable inside the request body
  // instead. This keeps names short and stable when the same recording
  // gets re-targeted at a different shopper via the variable swap. Note:
  // the event name itself keeps its underscores (PRODUCT_DETAIL_VIEWED)
  // since that's how AJO names them everywhere else.
  const brandShort = rec.brand === "NORDSTROM_RACK" ? "NR"
                   : rec.brand === "NORDSTROM"      ? "N"
                   : (rec.brand || "X");
  const productPart = rec.productKey || "";
  const parts = [seqStr, rec.event, productPart, brandShort]
    .filter((p) => p != null && p !== "");
  const name = parts.join("-");

  // Headers: rewrite Authorization to use the collection variable so
  // refreshing the token is one edit. Everything else passes through.
  const headers = Object.entries(req.headers || {}).map(([key, value]) => {
    if (key.toLowerCase() === "authorization") {
      return { key, value: "Bearer {{IMS_TOKEN}}", type: "text" };
    }
    return { key, value: String(value), type: "text" };
  });

  // Body: apply the postmanize pass first (ephemeral _id and timestamps
  // → {{$guid}} / {{$isoTimestamp}}), then swap any shopper-id strings
  // for their collection-variable references. The variable swap is done
  // value-based rather than path-based so it works for every event
  // schema (BAG/PDV put shopperId in _nordstrom.identities; CRT puts it
  // at top-level customerId when customerIdType=SHOPPER_ID).
  let bodyObj = (typeof req.body === "object" && req.body !== null)
    ? _postmanizeBody(req.body)
    : req.body;
  if (typeof bodyObj === "object" && bodyObj !== null && shopperIdToVar) {
    bodyObj = _shopReplaceShopperIds(bodyObj, shopperIdToVar);
  }
  const bodyStr = (typeof bodyObj === "string") ? bodyObj : JSON.stringify(bodyObj, null, 2);

  return {
    name,
    request: {
      method: req.method || "POST",
      header: headers,
      body: {
        mode: "raw",
        raw:  bodyStr,
        options: { raw: { language: "json" } },
      },
      url: { raw: req.url, ...(_shopParseUrlForPostman(req.url)) },
    },
    response: [],
  };
}

// Walk an object/array recursively and replace any string value that
// exactly matches a known shopper id with its Postman collection variable
// reference. Exact-match only — substring replacement risks corrupting
// unrelated strings that happen to contain a shopper id.
function _shopReplaceShopperIds(node, shopperIdToVar) {
  if (Array.isArray(node)) {
    return node.map((item) => _shopReplaceShopperIds(item, shopperIdToVar));
  }
  if (node && typeof node === "object") {
    const out = {};
    for (const [k, v] of Object.entries(node)) {
      out[k] = _shopReplaceShopperIds(v, shopperIdToVar);
    }
    return out;
  }
  if (typeof node === "string" && shopperIdToVar[node]) {
    return `{{${shopperIdToVar[node]}}}`;
  }
  return node;
}

// Decompose a URL into Postman's host/path/query parts. Saves the user
// from having to re-parse the URL in Postman; the host array and path
// array make Postman's URL editor populate correctly.
function _shopParseUrlForPostman(rawUrl) {
  try {
    const u = new URL(rawUrl);
    return {
      protocol: u.protocol.replace(":", ""),
      host:     u.hostname.split("."),
      path:     u.pathname.split("/").filter(Boolean),
      query:    [...u.searchParams.entries()].map(([key, value]) => ({ key, value })),
    };
  } catch {
    return {};
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PROFILE EVENTS MIRROR
// — Compact, read-only list of events from the last loaded profile. Sits
// in the right pane of the Activity/Events split. Empty until a profile
// loads; populated on every viewProfile (manual and auto-refresh).
// ─────────────────────────────────────────────────────────────────────────────

function _shopUpdateEventsMirror(p) {
  const el = document.getElementById("shop-events-mirror");
  if (!el) return;
  const events = Array.isArray(p?.events) ? p.events : [];
  if (!events.length) {
    el.innerHTML = `<div class="shop-empty">No events on profile.</div>`;
    return;
  }

  const sorted = events.slice()
    .sort((a, b) => (b.timestamp || "").localeCompare(a.timestamp || ""))
    .slice(0, 100);

  const fmtTime = (ts) => {
    if (!ts) return "";
    try {
      const d = new Date(ts);
      const diff = Date.now() - d.getTime();
      if (diff < 60_000)    return `${Math.floor(diff / 1000)}s ago`;
      if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
      if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
      return d.toLocaleDateString();
    } catch { return ts; }
  };

  // Singleton popover — one shared element, repositioned per click
  let popover = document.getElementById("shop-event-json-pop");
  if (!popover) {
    popover = document.createElement("div");
    popover.id = "shop-event-json-pop";
    popover.className = "shop-event-json-pop";
    popover.style.display = "none";
    popover.innerHTML = `
      <div class="shop-event-json-head">
        <span class="shop-event-json-title">Event JSON</span>
        <div class="shop-event-json-head-actions">
          <button type="button" class="shop-event-json-copy" id="shop-event-json-copy">Copy</button>
          <button type="button" class="shop-event-json-close" id="shop-event-json-close">×</button>
        </div>
      </div>
      <pre class="shop-event-json-body" id="shop-event-json-body"></pre>
    `;
    document.body.appendChild(popover);
    document.getElementById("shop-event-json-close").addEventListener("click", () => {
      popover.style.display = "none";
    });
    document.getElementById("shop-event-json-copy").addEventListener("click", () => {
      const jsonBody = document.getElementById("shop-event-json-body");
      const txt = jsonBody._rawJson || jsonBody.textContent;
      navigator.clipboard.writeText(txt).then(() => {
        const btn = document.getElementById("shop-event-json-copy");
        const orig = btn.textContent;
        btn.textContent = "✓";
        setTimeout(() => { btn.textContent = orig; }, 1800);
      });
    });
    document.addEventListener("click", (e) => {
      if (!popover.contains(e.target) && !e.target.classList.contains("shop-event-tip-btn")) {
        popover.style.display = "none";
      }
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") popover.style.display = "none"; });
  }

  function syntaxHighlight(json) {
    const escaped = json
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    return escaped.replace(
      /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
      (match) => {
        if (/^"/.test(match)) {
          if (/:$/.test(match)) return `<span class="jk">${match}</span>`;
          return `<span class="js">${match}</span>`;
        }
        if (/true|false/.test(match)) return `<span class="jb">${match}</span>`;
        if (/null/.test(match))       return `<span class="jn">${match}</span>`;
        return `<span class="jnum">${match}</span>`;
      }
    );
  }

  function showPopover(btn, eventObj) {
    const jsonBody = document.getElementById("shop-event-json-body");
    const json = JSON.stringify(eventObj, null, 2);
    jsonBody.innerHTML = syntaxHighlight(json);
    jsonBody._rawJson = json;
    const rect = btn.getBoundingClientRect();
    const top  = Math.min(rect.bottom + 6, window.innerHeight - 360);
    const left = Math.max(4, Math.min(rect.left - 10, window.innerWidth - 320));
    popover.style.top  = top + "px";
    popover.style.left = left + "px";
    popover.style.display = "flex";
  }

  el.replaceChildren(...sorted.map((e) => {
    let descriptor = "";
    if (Array.isArray(e.items) && e.items.length) {
      const ids = e.items.map((it) => it.skuId || it.productDisplayId).filter(Boolean);
      if (ids.length) descriptor = ids.join(", ");
    }
    if (!descriptor && e.browsePath)        descriptor = e.browsePath;
    if (!descriptor && e.metadata?.banner)  descriptor = e.metadata.banner;
    if (!descriptor && e.sourceJourneyName) descriptor = e.sourceJourneyName;

    const row = document.createElement("div");
    row.className = "shop-events-row";
    row.innerHTML = `
      <div class="shop-events-row-inner">
        <div class="shop-events-info">
          <div class="shop-events-ts">${escapeHtml(fmtTime(e.timestamp))}</div>
          <div class="shop-events-name">${escapeHtml(e.eventType || "—")}</div>
          ${descriptor ? `<div class="shop-events-detail">${escapeHtml(descriptor)}</div>` : ""}
        </div>
        <button type="button" class="shop-event-tip-btn" title="View full event JSON">{ }</button>
      </div>`;

    row.querySelector(".shop-event-tip-btn").addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (popover.style.display !== "none" &&
          document.getElementById("shop-event-json-body").textContent === JSON.stringify(e, null, 2)) {
        popover.style.display = "none";
        return;
      }
      showPopover(ev.currentTarget, e);
    });

    return row;
  }));
}

// ── Refresh action-button enable/disable on Shopper ID typing ──────────
// Hook into the existing input — Shop's "needs shopperId" check needs to
// re-evaluate as the user types.
document.addEventListener("DOMContentLoaded", () => {
  const sid = document.getElementById("shopperId");
  if (sid) sid.addEventListener("input", () => _shopRefreshActionButtons());
});
