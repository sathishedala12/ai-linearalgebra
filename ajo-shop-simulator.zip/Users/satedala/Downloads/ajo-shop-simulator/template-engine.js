// ─────────────────────────────────────────────────────────────────────────────
// Template engine — shared between background and sidepanel.
//
// SYNTAX (preferred, granular):
//   {{path}}                   — dotted-path lookup in context
//                                e.g. {{shopperId}}, {{item.skuId}},
//                                     {{_nordstrom.event.channelBrand}}
//   {{path|transformer}}       — pipe value through a named transformer
//   {{uuid}}                   — fresh UUID v4 each render
//   {{nowISO}}                 — current ISO timestamp each render
//
// DIRECTIVES (object templates):
//   { "$each": "skuItems", "$as": <template>, "$filter": "item.skuId" }
//       Iterate the array at ctx.skuItems, render <template> for each
//       element with `item` bound to the current element. Empty objects
//       (all keys pruned) are dropped from the result. Optional $filter
//       drops rows where the given path is empty/falsy.
//
//   { "$mapFrom": "priceDropSKUs", "$key": <template>, "$value": <template> }
//       Iterate the array, render $key and $value per row to build an
//       object map. Empty keys / empty values are skipped.
//
//   { "$pick": "customerIdType", "VALUE_A": <branch>, "VALUE_B": <branch>,
//     "$default": <branch> }
//       Branch by the value of a context variable.
//
//   { "$coalesce": [<template>, <template>, ...] }
//       First non-empty rendered value wins.
//
// LEGACY SYNTAX (still supported for back-compat):
//   {name}                     — flat context lookup (no dotted paths)
//   {name:transformer}         — transformer applied to flat lookup
//   Built-in transformers: asSkuList, withLastModified, asProductDisplay,
//     asQualItems, csvList, asPriceMap, pickCustomerId
//
// EMPTY-VALUE PRUNING: undefined, null, "", [], {} are dropped from
// object outputs so the final payload is clean.
// ─────────────────────────────────────────────────────────────────────────────

(function (root) {
  // Double-brace, dotted-path placeholders (the preferred form).
  const DBL_WHOLE_RE = /^\{\{\s*([\w.]+)\s*(?:\|\s*([\w]+)\s*)?\}\}$/;
  const DBL_EMBED_RE = /\{\{\s*([\w.]+)\s*(?:\|\s*([\w]+)\s*)?\}\}/g;

  // Legacy single-brace placeholders (back-compat).
  const LEG_WHOLE_RE = /^\{([\w]+)(?::([\w]+))?\}$/;
  const LEG_EMBED_RE = /\{([\w]+)(?::([\w]+))?\}/g;

  function nowISO() { return new Date().toISOString(); }

  function uuidv4() {
    const b = (typeof crypto !== "undefined" && crypto.getRandomValues)
      ? crypto.getRandomValues(new Uint8Array(16))
      : new Uint8Array(16).map(() => Math.floor(Math.random() * 256));
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = Array.from(b, (n) => n.toString(16).padStart(2, "0"));
    return `${h.slice(0,4).join("")}-${h.slice(4,6).join("")}-${h.slice(6,8).join("")}-${h.slice(8,10).join("")}-${h.slice(10).join("")}`;
  }

  // Resolve a dotted path against ctx. `uuid` and `nowISO` are virtual
  // properties that yield a fresh value on every access.
  function getPath(ctx, path) {
    if (!path) return undefined;
    if (path === "uuid") return uuidv4();
    if (path === "nowISO") return nowISO();
    return path.split(".").reduce((acc, seg) => (acc == null ? undefined : acc[seg]), ctx);
  }

  // Legacy flat resolver (no dotted paths).
  function legacyResolve(name, ctx) {
    if (name === "uuid") return uuidv4();
    if (name === "nowISO") return nowISO();
    return ctx[name];
  }

  // ── Built-in transformers ───────────────────────────────────────────────────
  // Kept primarily for back-compat with legacy single-brace settings. The new
  // double-brace syntax can still invoke them via `{{var|name}}`.
  const transformers = {
    asSkuList(value) {
      if (!Array.isArray(value)) return [];
      return value.map((it) => ({ skuId: typeof it === "string" ? it : it?.skuId || "" }))
                  .filter((i) => i.skuId);
    },
    withLastModified(value, ctx) {
      if (!Array.isArray(value)) return [];
      const fallback = ctx.eventTime || ctx.systemTime || nowISO();
      return value.map((it) => {
        const skuId = typeof it === "string" ? it : it?.skuId || "";
        const ts = (typeof it === "object" && it?.lastModifiedTime) || fallback;
        return skuId ? { skuId, lastModifiedTime: ts } : null;
      }).filter(Boolean);
    },
    asProductDisplay(value) {
      if (!Array.isArray(value)) return [];
      return value.map((it) => {
        const id = typeof it === "string" ? it : (it?.skuId || it?.productDisplayId || "");
        return id ? { productDisplayId: id } : null;
      }).filter(Boolean);
    },
    asQualItems(value) {
      if (!Array.isArray(value)) return [];
      return value
        .filter((it) => (it?.skuId || "").trim())
        .map((it) => ({
          lastModifyTime:   it.lastModifyTime || "",
          productDisplayId: it.productDisplayId || "",
          skuId:            it.skuId,
        }));
    },
    csvList(value) {
      if (Array.isArray(value)) return value.filter(Boolean);
      if (typeof value !== "string") return [];
      return value.split(",").map((s) => s.trim()).filter(Boolean);
    },
    asPriceMap(value) {
      if (!Array.isArray(value)) return {};
      const out = {};
      for (const r of value) {
        const sku = (r?.skuId || "").trim();
        const sale = (r?.sale || "").trim();
        const orig = (r?.original || "").trim();
        if (sku && sale && orig) out[sku] = `${sale}|${orig}`;
      }
      return out;
    },
    pickCustomerId(value, ctx) {
      if (value === "SHOPPER_ID") return ctx.shopperId || "";
      return ctx.customerProfileId || "";
    },
  };

  function applyTransformer(name, value, ctx) {
    const fn = transformers[name];
    if (!fn) { console.warn(`Unknown transformer: ${name}`); return value; }
    return fn(value, ctx);
  }

  // ── Whole-string and embedded resolution ────────────────────────────────────
  // Whole-string placeholder returns the raw value (preserving its JS type).
  // Embedded placeholders inside a longer string are interpolated as strings.
  function resolveString(str, ctx) {
    const dblWhole = DBL_WHOLE_RE.exec(str);
    if (dblWhole) {
      const v = getPath(ctx, dblWhole[1]);
      return dblWhole[2] ? applyTransformer(dblWhole[2], v, ctx) : v;
    }
    const legWhole = LEG_WHOLE_RE.exec(str);
    if (legWhole) {
      const v = legacyResolve(legWhole[1], ctx);
      return legWhole[2] ? applyTransformer(legWhole[2], v, ctx) : v;
    }
    // Embedded — replace double-brace, then legacy. Each placeholder becomes a
    // string fragment; whole result is the concatenated string.
    let out = String(str).replace(DBL_EMBED_RE, (_, p, t) => {
      let v = getPath(ctx, p);
      if (t) v = applyTransformer(t, v, ctx);
      return v == null ? "" : String(v);
    });
    out = out.replace(LEG_EMBED_RE, (_, n, t) => {
      let v = legacyResolve(n, ctx);
      if (t) v = applyTransformer(t, v, ctx);
      return v == null ? "" : String(v);
    });
    return out;
  }

  // ── Main render — recursive, with directive support ─────────────────────────
  function render(template, ctx) {
    if (template == null) return template;

    if (typeof template === "string") return resolveString(template, ctx);

    if (Array.isArray(template)) return template.map((t) => render(t, ctx));

    if (typeof template === "object") {
      // Directive: $each — array iteration. `item` is bound to each element.
      if (Object.prototype.hasOwnProperty.call(template, "$each") &&
          Object.prototype.hasOwnProperty.call(template, "$as")) {
        const source = getPath(ctx, template.$each);
        if (!Array.isArray(source)) return [];
        const out = [];
        for (const item of source) {
          const itemCtx = { ...ctx, item };
          if (template.$filter) {
            const keep = getPath(itemCtx, template.$filter);
            if (!keep) continue;
          }
          const rendered = render(template.$as, itemCtx);
          if (!isEmpty(rendered)) out.push(rendered);
        }
        return out;
      }

      // Directive: $mapFrom — object map built from an array.
      if (Object.prototype.hasOwnProperty.call(template, "$mapFrom") &&
          Object.prototype.hasOwnProperty.call(template, "$key") &&
          Object.prototype.hasOwnProperty.call(template, "$value")) {
        const source = getPath(ctx, template.$mapFrom);
        if (!Array.isArray(source)) return {};
        const out = {};
        for (const item of source) {
          const itemCtx = { ...ctx, item };
          if (template.$filter) {
            const keep = getPath(itemCtx, template.$filter);
            if (!keep) continue;
          }
          const k = render(template.$key, itemCtx);
          const v = render(template.$value, itemCtx);
          if (k && !isEmpty(v)) out[String(k)] = v;
        }
        return out;
      }

      // Directive: $pick — branch by the value of a context variable.
      if (Object.prototype.hasOwnProperty.call(template, "$pick")) {
        const val = String(getPath(ctx, template.$pick) ?? "");
        const branch = Object.prototype.hasOwnProperty.call(template, val)
          ? template[val]
          : template.$default;
        return render(branch, ctx);
      }

      // Directive: $coalesce — first non-empty wins.
      if (Object.prototype.hasOwnProperty.call(template, "$coalesce") &&
          Array.isArray(template.$coalesce)) {
        for (const candidate of template.$coalesce) {
          const v = render(candidate, ctx);
          if (!isEmpty(v)) return v;
        }
        return undefined;
      }

      // Directive: $keep — escape hatch from empty-pruning. Renders the
      // wrapped value verbatim, so callers can force a key to stay in the
      // output even when its template substitutes to "". Used for fields
      // like AJO Qualification's `status` where the Adobe API contract may
      // expect the key to always be present even if blank.
      if (Object.prototype.hasOwnProperty.call(template, "$keep") &&
          Object.keys(template).length === 1) {
        const v = render(template.$keep, ctx);
        // Preserve "" / null specifically; arrays/objects collapse to a
        // sensible empty form rather than disappearing.
        if (v === undefined || v === null) return "";
        return v;
      }

      // Default: render each key, prune empty results.
      const out = {};
      for (const [k, v] of Object.entries(template)) {
        const rendered = render(v, ctx);
        // The $keep wrapper short-circuits the prune check so an explicit ""
        // survives; everything else still gets pruned for clean payloads.
        const isKept = v && typeof v === "object" && !Array.isArray(v) &&
                       Object.prototype.hasOwnProperty.call(v, "$keep");
        if (isKept || !isEmpty(rendered)) out[k] = rendered;
      }
      return out;
    }

    return template;
  }

  // Empty: undefined, null, "", [], {}. Zero and false are NOT empty.
  function isEmpty(v) {
    if (v === undefined || v === null || v === "") return true;
    if (Array.isArray(v) && v.length === 0) return true;
    if (typeof v === "object" && Object.keys(v).length === 0) return true;
    return false;
  }

  // ── Generators for `defaults` placeholders ──────────────────────────────────
  function genOrderNumber() {
    const d = new Date();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const n = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
    return `ND-${mm}${dd}-S${n}`;
  }
  function genPurchaseId() {
    const d = new Date();
    const y = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const r1 = String(Math.floor(Math.random() * 1000)).padStart(3, "0");
    const r2 = String(Math.floor(Math.random() * 10000)).padStart(4, "0");
    const r3 = String(9000 + Math.floor(Math.random() * 1000));
    return `${r1}_${r2}_${r3}_${y}${mm}${dd}`;
  }
  function genShopperId() {
    const d = new Date();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const n = String(Math.floor(Math.random() * 1000)).padStart(3, "0");
    const infix = ["TRIG", "SHOP", "PROF"][Math.floor(Math.random() * 3)];
    const suffix = Math.random() < 0.5 ? "SINGLE" : "MULTI";
    return `SHOPPER-${mm}${dd}-${infix}-${suffix}-${n}`;
  }

  const generators = {
    nowISO,
    uuid: uuidv4,
    generateOrderNumber: genOrderNumber,
    generatePurchaseId:  genPurchaseId,
    generateShopperId:   genShopperId,
  };

  function runGenerator(name) {
    const fn = generators[name];
    return fn ? fn() : "";
  }

  // Resolve a "{generatorName}" or "{{generatorName}}" placeholder default into
  // its concrete value. Plain strings pass through unchanged.
  function resolveDefault(value) {
    if (typeof value !== "string") return value;
    let m = /^\{\{\s*(\w+)\s*\}\}$/.exec(value);
    if (m) return runGenerator(m[1]) || value;
    m = /^\{(\w+)\}$/.exec(value);
    if (m) return runGenerator(m[1]) || value;
    return value;
  }

  // Template-string interpolation for URLs / header values. Supports both
  // single-brace and double-brace syntax.
  function tplStr(str, vars) {
    let out = String(str || "");
    out = out.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, p) => {
      const v = getPath(vars, p);
      return v != null ? String(v) : `{{${p}}}`;
    });
    out = out.replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : `{${k}}`));
    return out;
  }

  const TemplateEngine = {
    render,
    resolveDefault,
    runGenerator,
    nowISO,
    uuidv4,
    tplStr,
    getPath,
    transformers,
    generators,
  };

  if (typeof module !== "undefined" && module.exports) module.exports = TemplateEngine;
  if (typeof root !== "undefined") root.TemplateEngine = TemplateEngine;
})(typeof self !== "undefined" ? self : this);
