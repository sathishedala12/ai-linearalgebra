// ─────────────────────────────────────────────────────────────────────────────
// Adobe Journey Event Trigger — schema-driven background service worker
//
// The whole runtime is driven by `settings.json`. The settings file declares
// sections, fields, events, endpoints, headers, and payload templates with
// {var} placeholders. This file:
//   1. Loads + caches settings (with chrome.storage overrides)
//   2. Handles fire-event requests by rendering the chosen event's payload
//      template against the form context and POSTing to its endpoint
//   3. Handles profile lookups (AEP GraphQL) — these stay code-driven since
//      their response shapes are fixed
// ─────────────────────────────────────────────────────────────────────────────

importScripts("template-engine.js");

let SETTINGS = null;
let SETTINGS_READY = loadSettings();

async function loadSettings() {
  let defaults = {};
  try {
    const res = await fetch(chrome.runtime.getURL("settings.json"));
    defaults = await res.json();
  } catch (e) {
    console.error("Failed to load settings.json:", e);
  }
  let overrides = {};
  try {
    const stored = await chrome.storage.local.get("userSettings");
    overrides = stored?.userSettings || {};
  } catch (_) { /* ignore */ }
  SETTINGS = deepMerge(defaults, overrides);
  return SETTINGS;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "userSettings" in changes) {
    SETTINGS_READY = loadSettings();
  }
});

function deepMerge(a, b) {
  if (!b || typeof b !== "object" || Array.isArray(b)) return b === undefined ? a : b;
  if (!a || typeof a !== "object" || Array.isArray(a)) return b;
  const out = { ...a };
  for (const k of Object.keys(b)) out[k] = deepMerge(a[k], b[k]);
  return out;
}

// ── Side panel: open on action click ───────────────────────────────────────
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((err) => {
  console.warn("setPanelBehavior failed (ok in older Chrome):", err);
});
chrome.action.onClicked.addListener(async (tab) => {
  try { await chrome.sidePanel.open({ tabId: tab.id }); }
  catch (e) { console.warn("sidePanel.open failed:", e); }
});

// ── Token / sandbox / tenant / imsOrgId sniffer ─────────────────────────────
// All four runtime context values are derived from the live Adobe Experience
// Cloud tab so the extension stays in sync with whichever org/sandbox the
// user happens to be browsing. settings.json values are kept only as a
// fallback for when the tab is closed or hasn't finished loading.
//
// This is the *inner* sniffer — it requires a live AJO tab and throws if
// none is found. The public getTabContext() wraps this with a cache layer
// (2h TTL) so fires can still go out when the user has navigated away
// from Adobe but the auth context is still recent enough to be valid.
async function _sniffTabContext() {
  // Prefer the currently active experience.adobe.com tab (most reliable for
  // chrome.scripting.executeScript permissions). Fall back to any AJO tab.
  let tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true,
    url: "https://experience.adobe.com/*",
  });
  if (!tabs.length) {
    tabs = await chrome.tabs.query({ url: "https://experience.adobe.com/*" });
  }
  if (!tabs.length) {
    throw new Error("Open an Adobe Experience Cloud tab (experience.adobe.com) so the extension can sniff your auth token, then try again.");
  }

  // Prefer an AJO tab so the sandbox is meaningful.
  const ajoTab = tabs.find((t) => /journey-optimizer/.test(t.url || "")) || tabs[0];

  // URL-derived context: tenant (@nordstrom, @nordstromrack, …) and sandbox
  // (sname:dev, sname:prod, …). The hash fragment carries the routing for
  // Adobe's single-page shell, so we parse it directly.
  const url = ajoTab.url || "";
  const tenantM  = /#\/([^/?#]+)/.exec(url);
  const sandboxM = /sname:([^/?#]+)/.exec(url);
  const tenant   = tenantM  ? tenantM[1]  : (SETTINGS?.tenant  || "@nordstrom");
  const sandbox  = sandboxM ? sandboxM[1] : (SETTINGS?.sandbox || "prod");

  // Storage-derived context: IMS access token + IMS Org ID. We pull both in
  // a single executeScript round-trip rather than two — the page only needs
  // to be inspected once, and a single retry on cold-load is enough.
  const readOnce = async () => {
    try {
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: ajoTab.id },
        func: () => {
          const out = {};
          try {
            // IMS access token — sessionStorage, key starts with adobeid_ims_access_token.
            const tokKey = Object.keys(sessionStorage).find((k) => k.startsWith("adobeid_ims_access_token"));
            if (!tokKey) {
              out.error = "No Adobe IMS token in sessionStorage. Re-login at experience.adobe.com.";
              return out;
            }
            const tokRaw = sessionStorage.getItem(tokKey);
            const tokParsed = JSON.parse(tokRaw || "{}");
            out.token = tokParsed?.tokenValue || tokParsed?.token || tokRaw || null;

            // IMS Org ID — Adobe's Unified Shell stores the active org under
            // localStorage.unifiedShellSession with a leading marker (e.g.
            // "N|") before the JSON payload. Slice to the first { to be
            // marker-agnostic, then walk the per-session entries for
            // activeOrg, falling back to userOrgs[0].imsOrgId.
            const shell = localStorage.getItem("unifiedShellSession")
                      || sessionStorage.getItem("unifiedShellSession");
            if (shell) {
              const start = shell.indexOf("{");
              if (start >= 0) {
                try {
                  const sessions = JSON.parse(shell.slice(start));
                  for (const sess of Object.values(sessions || {})) {
                    if (!sess || typeof sess !== "object") continue;
                    if (typeof sess.activeOrg === "string" && sess.activeOrg.endsWith("@AdobeOrg")) {
                      out.imsOrgId = sess.activeOrg;
                      break;
                    }
                    if (Array.isArray(sess.userOrgs)) {
                      const org = sess.userOrgs.find((u) => u && u.imsOrgId);
                      if (org) { out.imsOrgId = org.imsOrgId; break; }
                    }
                  }
                } catch (_) { /* fall through to settings default */ }
              }
            }
          } catch (e) { out.error = e.message; }
          return out;
        },
      });
      return result;
    } catch (e) {
      // executeScript itself failed — usually a host-permission problem or
      // the tab navigated away mid-call.
      return { error: `Cannot read context from tab — ${e.message}. Make sure an experience.adobe.com tab is open and you're logged in.` };
    }
  };

  let result = await readOnce();
  if (!result?.token && !result?.error) {
    await new Promise((r) => setTimeout(r, 1000));
    result = await readOnce();
  }

  if (!result || result.error) throw new Error(result?.error || "Could not read auth token.");
  if (!result.token) throw new Error("Got an empty token — try refreshing the Adobe Experience Cloud tab and logging in again.");

  return {
    token: result.token,
    sandbox,
    tenant,
    imsOrgId: result.imsOrgId || SETTINGS?.aep?.imsOrgId || null,
    // Surface the URL of the tab we sniffed from so downstream callers
    // (e.g. getJourneyContext) can derive the journey ID without a fresh
    // tabs.query, avoiding the race where active-tab changes between calls.
    tabUrl: ajoTab.url || "",
  };
}

// 2-hour cache for the tab context. Backs the public getTabContext() so
// fires keep working when the user closes the Adobe tab or switches to
// another app entirely. Stored in chrome.storage.local because the
// service worker can be unloaded by Chrome aggressively — in-memory
// scope would lose the cache too often. tabUrl is intentionally NOT
// cached: it ties to the live tab for journey detection, and a stale
// tabUrl could mislead getJourneyContext into using yesterday's journey.
const TAB_CONTEXT_CACHE_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours
const TAB_CONTEXT_CACHE_KEY    = "tabContextCache";

async function _readTabContextCache() {
  try {
    const data = await chrome.storage.local.get([TAB_CONTEXT_CACHE_KEY]);
    const entry = data?.[TAB_CONTEXT_CACHE_KEY];
    if (!entry || !entry.cachedAt || !entry.value) return null;
    const age = Date.now() - entry.cachedAt;
    if (age > TAB_CONTEXT_CACHE_TTL_MS) return null;
    return { value: entry.value, age };
  } catch (_) { return null; }
}

async function _writeTabContextCache(ctx) {
  // Don't cache anything we won't reuse — token + sandbox + tenant +
  // imsOrgId are stable across the session. tabUrl is deliberately
  // excluded (it pins to a specific live tab).
  try {
    await chrome.storage.local.set({
      [TAB_CONTEXT_CACHE_KEY]: {
        cachedAt: Date.now(),
        value: {
          token:    ctx.token,
          sandbox:  ctx.sandbox,
          tenant:   ctx.tenant,
          imsOrgId: ctx.imsOrgId,
        },
      },
    });
  } catch (_) { /* cache write failure isn't fatal — proceed without */ }
}

// Public tab-context accessor. Order of preference:
//   1. Live sniff from an open Adobe tab — most accurate, updates cache.
//   2. Cached values from the last successful sniff (if within 2h TTL).
//   3. Throw — no way to get auth context.
// Callers see the same {token, sandbox, tenant, imsOrgId, tabUrl} shape
// whether the result came from a live sniff or the cache. When served
// from cache, tabUrl is empty (no live tab) — getJourneyContext callers
// need to handle this case (and currently they do, by failing gracefully
// when journey detection can't find a tab).
async function getTabContext() {
  try {
    const fresh = await _sniffTabContext();
    // Successful live sniff — refresh the cache and return.
    await _writeTabContextCache(fresh);
    return fresh;
  } catch (sniffErr) {
    // Live sniff failed. Try the cache before giving up. Common reasons
    // to fail: user closed Adobe tab, switched to another browser
    // window, or the Adobe page hasn't finished loading.
    const cached = await _readTabContextCache();
    if (cached) {
      const ageMin = Math.floor(cached.age / 60000);
      console.log(`getTabContext: live sniff failed (${sniffErr.message}), using cached context from ${ageMin}m ago`);
      return {
        ...cached.value,
        tabUrl: "", // no live tab — caller must handle empty tabUrl gracefully
        fromCache: true,
        cacheAgeMs: cached.age,
      };
    }
    // Cache miss too — propagate the original sniff error since it
    // carries the actionable user-facing message.
    throw sniffErr;
  }
}

// Pick a sandbox-keyed value from a string-or-object: if `v` is an object
// like {dev: "...", nonprod: "..."}, return v[sandbox] with fall-through to
// dev → first key. Strings pass through untouched. Shared between fireEvent
// (extraHeaders, endpoint URLs) and the AEP profile fetches (mergePolicyId).
function pickForSandbox(v, sandbox, label) {
  if (v && typeof v === "object" && !Array.isArray(v)) {
    const keys = Object.keys(v);
    const picked = v[sandbox] ?? v.dev ?? v[keys[0]];
    if (picked == null) return null;
    if (!(sandbox in v)) {
      const usedKey = v.dev ? "dev" : keys[0];
      console.warn(`${label} has no entry for sandbox "${sandbox}"; using "${usedKey}" value instead`);
    }
    return picked;
  }
  return v;
}

// ─────────────────────────────────────────────────────────────────────────────
// AJO Qualification — journey detection
// Ported from the user's standalone tool. Used by AJO_QUALIFICATION_EVENT
// (and any future event with `requiresJourneyContext: true`) to discover:
//   • journeyId       — UUID parsed out of the live tab URL hash
//   • journeyName     — `name` from the journey-private authoring API
//   • journeyType     — `latestVersionType` from the same response
//   • eventUid        — the start-trigger event's UID, found by walking
//                       `steps[].transitions`, then `ui.nodes`, then a
//                       generic deep scan as fallbacks
// All four become {{...}} interpolations available in the payload template.
// ─────────────────────────────────────────────────────────────────────────────
const _UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isUuid = (s) => _UUID_RE.test(String(s || ""));

function getJourneyIdFromUrl(url) {
  const s = String(url || "");
  // Adobe shell uses hash routing: experience.adobe.com/#/<tenant>/sname:<env>/journey-optimizer/journey/<uuid>/...
  const hashPart = (s.split("#")[1] || "").replace(/^\/+/, "");
  const segments = hashPart.split("/").filter(Boolean);
  const idx = segments.findIndex((seg) => seg === "journey");
  if (idx !== -1 && isUuid(segments[idx + 1])) return segments[idx + 1];
  // Fallback — any UUID-shaped segment.
  for (const seg of segments) if (isUuid(seg)) return seg;
  return null;
}

// Different from the regular DCS calls — uses the authoring API host with
// the voyager_ui x-api-key (not acp_ui_platform). Auth headers reuse the
// live IMS token + imsOrgId already sniffed from the Adobe tab.
function authoringHeaders(token, sandbox, imsOrgId) {
  return {
    Accept: "*/*",
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
    Origin: "https://experience.adobe.com",
    Referer: "https://experience.adobe.com/",
    "x-api-key": "voyager_ui",
    "x-gw-ims-org-id": imsOrgId || SETTINGS?.aep?.imsOrgId,
    "x-sandbox-name": sandbox,
  };
}

async function findJourneyEventForId(journeyId, token, sandbox, imsOrgId) {
  const res = await fetch(
    `https://journey-private.adobe.io/authoring/journeyVersions/${journeyId}`,
    { headers: authoringHeaders(token, sandbox, imsOrgId) }
  );
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`Journey API ${res.status}: ${txt.slice(0, 200)}`);
  }
  const raw = await res.json();
  const data = raw?.result || raw;
  const journeyName = data?.name || "";
  const journeyType = data?.latestVersionType || data?.type || "";
  const steps = Array.isArray(data?.steps) ? data.steps : [];
  const nodes = data?.ui?.nodes ? Object.values(data.ui.nodes) : [];

  // Strategy 1 — start step transitions pointing at an event.
  for (const step of steps) {
    for (const t of step.transitions || []) {
      const ref = t.elementRef;
      if (ref?.type === "event" && ref.uid) {
        return { eventUid: ref.uid, eventName: t.name || "", journeyName, journeyType };
      }
    }
  }
  // Strategy 2 — UI graph nodes (newer canvas format).
  for (const node of nodes) {
    if (node.type === "event" && node.data?.uid && isUuid(node.data.uid)) {
      return { eventUid: node.data.uid, eventName: node.label || node.name || "", journeyName, journeyType };
    }
  }
  // Strategy 3 — the step itself is the event.
  for (const step of steps) {
    if ((step.type === "event" || step.nodeType === "event") && isUuid(step.uid)) {
      return { eventUid: step.uid, eventName: step.name || step.nodeName || "", journeyName, journeyType };
    }
  }
  // Strategy 4 — recursive scan.
  const deepScan = (obj, depth = 0) => {
    if (!obj || typeof obj !== "object" || depth > 6) return null;
    if (Array.isArray(obj)) {
      for (const item of obj) { const r = deepScan(item, depth + 1); if (r) return r; }
      return null;
    }
    if (obj.uid && isUuid(obj.uid) &&
        (obj.type === "event" || (obj.elementType || "").toLowerCase().includes("event"))) {
      return { uid: obj.uid, name: obj.name || obj.label || "" };
    }
    for (const v of Object.values(obj)) { const r = deepScan(v, depth + 1); if (r) return r; }
    return null;
  };
  const found = deepScan(steps);
  if (found) return { eventUid: found.uid, eventName: found.name, journeyName, journeyType };

  // Strategy 5 — top-level trigger.
  const trigger = data.trigger || data.entryCondition || data.entryEvent || {};
  const tId = trigger.uid || trigger.eventUid || trigger.eventId || trigger.id;
  if (tId && isUuid(tId)) return { eventUid: tId, eventName: trigger.name || "", journeyName, journeyType };

  throw new Error(`No event UID found in journey "${journeyName || journeyId}"`);
}

// Side-panel-facing helper — pulls the active tab URL, extracts the journey
// ID, then hits the authoring API to resolve the rest. Returns everything
// the AJO Qualification form needs to auto-populate its read-only fields.
async function getJourneyContext() {
  const { token, sandbox, imsOrgId, tabUrl } = await getTabContext();
  const journeyId = getJourneyIdFromUrl(tabUrl);
  if (!journeyId) {
    throw new Error("No journey UUID in the active tab URL — open a journey in Adobe Journey Optimizer first (the URL should contain /journey/<uuid>/).");
  }
  const { eventUid, eventName, journeyName, journeyType } =
    await findJourneyEventForId(journeyId, token, sandbox, imsOrgId);
  return { journeyId, journeyName, journeyType, eventUid, eventName, sandbox };
}

// ─────────────────────────────────────────────────────────────────────────────
// Fire any event — fully schema-driven
// ─────────────────────────────────────────────────────────────────────────────
async function fireEvent({ sectionId, eventId, context }) {
  await SETTINGS_READY;
  const section = (SETTINGS.sections || []).find((s) => s.id === sectionId);
  if (!section) throw new Error(`Unknown section: ${sectionId}`);
  const event = (section.events || []).find((e) => e.id === eventId);
  if (!event) throw new Error(`Unknown event: ${eventId} in ${sectionId}`);
  const endpointDef = (SETTINGS.endpoints || {})[event.endpoint];
  if (!endpointDef) throw new Error(`Unknown endpoint: ${event.endpoint}`);

  // Sniff token + sandbox from the open AJO tab.
  const { token, sandbox, imsOrgId } = await getTabContext();
  // Events that need journey context (currently AJO_QUALIFICATION_EVENT) opt
  // in via `requiresJourneyContext: true`. We resolve once here and merge
  // into the template context so payload templates can use {{journeyId}},
  // {{eventUid}}, etc. directly. User-supplied form values win when set —
  // the journey lookup just provides defaults.
  let journeyCtx = {};
  if (event.requiresJourneyContext) {
    try {
      const j = await getJourneyContext();
      journeyCtx = {
        journeyId:               j.journeyId,
        sourceJourneyVersionId:  context.sourceJourneyVersionId || j.journeyId,
        correlationId:           context.correlationId          || j.journeyId,
        sourceJourneyName:       context.sourceJourneyName      || j.journeyName,
        sourceJourneyType:       context.sourceJourneyType      || j.journeyType,
        eventUid:                context.eventUid               || j.eventUid,
      };
    } catch (e) {
      // If detection fails but the user already filled the fields manually,
      // proceed with their values. Otherwise surface a useful error.
      if (!context.eventUid || !context.sourceJourneyVersionId) {
        throw new Error(`Journey detection failed: ${e.message}`);
      }
      journeyCtx = {
        journeyId:               context.sourceJourneyVersionId,
        sourceJourneyVersionId:  context.sourceJourneyVersionId,
        correlationId:           context.correlationId || context.sourceJourneyVersionId,
        sourceJourneyName:       context.sourceJourneyName || "",
        sourceJourneyType:       context.sourceJourneyType || "",
        eventUid:                context.eventUid,
      };
    }
  }

  // Augment the context with auth + computed values.
  const ctx = {
    ...context,
    ...journeyCtx,
    authSandbox: sandbox,  // for header interpolation
    imsOrgId,              // live org ID from unifiedShellSession (for dccsAuthoring header)
    token,
  };

  // Render the payload template.
  const payload = TemplateEngine.render(event.payload, ctx);

  // Build headers (Authorization injected here, the rest come from settings).
  const headers = { Authorization: `Bearer ${token}` };
  for (const [k, v] of Object.entries(endpointDef.headers || {})) {
    headers[k] = TemplateEngine.tplStr(v, ctx);
  }
  // Pick a sandbox-keyed value (shared helper at module scope handles
  // string-or-object shape for extraHeaders and endpoint URLs).
  const pick = (v, label) => pickForSandbox(v, sandbox, label);

  // extraHeaders entries can be either a plain template string (legacy
  // shape) or an object keyed by sandbox name ({ dev: "...", nonprod: "..." })
  // so per-environment flow IDs and similar can live in settings.json
  // without code edits.
  for (const [k, v] of Object.entries(event.extraHeaders || {})) {
    const raw = pick(v, `extraHeaders.${k}`);
    if (raw == null) {
      console.warn(`extraHeaders.${k} has no value for sandbox "${sandbox}"; skipping header`);
      continue;
    }
    headers[k] = TemplateEngine.tplStr(String(raw), ctx);
  }

  // Endpoint URL — supports the same string-or-sandbox-object shape so
  // dcsBatch / dcsSingle can route to a different DCS dataset per env.
  const rawUrl = pick(endpointDef.url, `endpoints.${event.endpoint}.url`);
  if (rawUrl == null) throw new Error(`No URL defined for endpoint "${event.endpoint}" in sandbox "${sandbox}".`);
  const url = TemplateEngine.tplStr(String(rawUrl), ctx);
  const method = endpointDef.method || "POST";

  const res = await fetch(url, { method, headers, body: JSON.stringify(payload) });
  let body = null;
  try { body = await res.json(); } catch { body = await res.text(); }

  // Snapshot of the actual HTTP request — used by the side panel's
  // "Copy as cURL" so the user can rebuild the call in Postman/terminal.
  // NOTE: this includes the live IMS bearer token. The token is short-lived
  // (~24h) and stays inside the runtime message bridge between background
  // and the side panel — never persisted, never sent over the network.
  // If the user copies the curl, the token lands on their clipboard; they
  // are responsible for not pasting it into shared spaces.
  const request = { url, method, headers, body: payload };

  if (!res.ok) {
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    err.payload = payload;
    err.responseBody = body;
    err.sandbox = sandbox;
    err.request = request;
    throw err;
  }
  return { status: res.status, payload, body, sandbox, request };
}

// Build-only variant of fireEvent — resolves everything (token, sandbox,
// journey context, template, headers, URL) but does NOT issue the fetch.
// Used by the Shop simulator's build-only mode (cart tracking off) so the
// Postman recorder captures an authentic request shape without touching
// AJO. Returns the same {status, payload, body, sandbox, request} shape
// fireEvent does, with status="DRY" so callers can tell build-only fires
// apart from real ones in the activity log.
async function dryFireEvent({ sectionId, eventId, context }) {
  await SETTINGS_READY;
  const section = (SETTINGS.sections || []).find((s) => s.id === sectionId);
  if (!section) throw new Error(`Unknown section: ${sectionId}`);
  const event = (section.events || []).find((e) => e.id === eventId);
  if (!event) throw new Error(`Unknown event: ${eventId} in ${sectionId}`);
  const endpointDef = (SETTINGS.endpoints || {})[event.endpoint];
  if (!endpointDef) throw new Error(`Unknown endpoint: ${event.endpoint}`);

  // Same tab-sniffing as fireEvent so the captured request has live
  // token + sandbox + imsOrgId. If the tab isn't open, fall back to a
  // placeholder token — the recorded request will still work in Postman
  // once the user pastes a fresh token into the collection variable.
  let token = "", sandbox = "", imsOrgId = "";
  try {
    const tc = await getTabContext();
    token    = tc.token;
    sandbox  = tc.sandbox;
    imsOrgId = tc.imsOrgId;
  } catch (e) {
    // Build-only mode shouldn't fail just because no Adobe tab is open.
    // The user explicitly opted into dry-fire, and the resulting Postman
    // collection is meant to be replayed later anyway.
    sandbox = SETTINGS.sandbox || "dev";
    imsOrgId = SETTINGS.aep?.imsOrgId || "";
  }

  // Journey context — same logic as fireEvent. We tolerate detection
  // failures more permissively in dry mode because there's no live AJO
  // tab requirement.
  let journeyCtx = {};
  if (event.requiresJourneyContext) {
    try {
      const j = await getJourneyContext();
      journeyCtx = {
        journeyId:               j.journeyId,
        sourceJourneyVersionId:  context.sourceJourneyVersionId || j.journeyId,
        correlationId:           context.correlationId          || j.journeyId,
        sourceJourneyName:       context.sourceJourneyName      || j.journeyName,
        sourceJourneyType:       context.sourceJourneyType      || j.journeyType,
        eventUid:                context.eventUid               || j.eventUid,
      };
    } catch (_) {
      journeyCtx = {
        journeyId:               context.sourceJourneyVersionId || "",
        sourceJourneyVersionId:  context.sourceJourneyVersionId || "",
        correlationId:           context.correlationId || context.sourceJourneyVersionId || "",
        sourceJourneyName:       context.sourceJourneyName || "",
        sourceJourneyType:       context.sourceJourneyType || "",
        eventUid:                context.eventUid || "",
      };
    }
  }

  const ctx = { ...context, ...journeyCtx, authSandbox: sandbox, imsOrgId, token };
  const payload = TemplateEngine.render(event.payload, ctx);

  const headers = { Authorization: `Bearer ${token}` };
  for (const [k, v] of Object.entries(endpointDef.headers || {})) {
    headers[k] = TemplateEngine.tplStr(v, ctx);
  }
  const pick = (v, label) => pickForSandbox(v, sandbox, label);
  for (const [k, v] of Object.entries(event.extraHeaders || {})) {
    const raw = pick(v, `extraHeaders.${k}`);
    if (raw == null) continue;
    headers[k] = TemplateEngine.tplStr(String(raw), ctx);
  }

  const rawUrl = pick(endpointDef.url, `endpoints.${event.endpoint}.url`);
  if (rawUrl == null) throw new Error(`No URL defined for endpoint "${event.endpoint}" in sandbox "${sandbox}".`);
  const url = TemplateEngine.tplStr(String(rawUrl), ctx);
  const method = endpointDef.method || "POST";

  const request = { url, method, headers, body: payload };
  return { status: "DRY", payload, body: null, sandbox, request };
}

// ─────────────────────────────────────────────────────────────────────────────
// Profile + Audiences (Adobe Experience Platform GraphQL)
// — kept code-driven because the response parsing is fixed-shape
// ─────────────────────────────────────────────────────────────────────────────
function aepHeaders(token, sandbox, imsOrgId) {
  return {
    Accept: "*/*",
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
    Origin: "https://experience.adobe.com",
    Referer: "https://experience.adobe.com/",
    "x-api-key": SETTINGS.aep.apiKey,
    "x-gw-ims-org-id": imsOrgId || SETTINGS.aep.imsOrgId,
    "x-sandbox-name": sandbox,
  };
}

async function fetchProfileByShopperId(shopperId, token, sandbox, imsOrgId) {
  // Compact, single-line GraphQL to mirror the working curl byte-for-byte.
  const query =
    "query Profiles($page: PageInput!, $params: ProfilesInput!) {\n" +
    "  aepProfiles(page: $page, params: $params) {\n" +
    "    edges { node { id entity __typename } __typename }\n" +
    "    pageInfo { hasNextPage hasPreviousPage __typename }\n" +
    "    totalCount\n" +
    "    __typename\n" +
    "  }\n" +
    "}";
  const mergePolicyId = pickForSandbox(SETTINGS.aep?.mergePolicyId, sandbox, "aep.mergePolicyId");
  const res = await fetch(SETTINGS.aep.graphqlUrl, {
    method: "POST",
    headers: aepHeaders(token, sandbox, imsOrgId),
    body: JSON.stringify({
      operationName: "Profiles",
      variables: {
        params: {
          schemaName: "_xdm.context.profile",
          ...(mergePolicyId ? { mergePolicyId } : {}),
          entityIdNS: "ShopperId",
          entityId: shopperId,
        },
        page: { start: 0, sort: null, limit: 50 },
      },
      query,
    }),
  });
  if (!res.ok) {
    const body = await safeJson(res);
    throw new Error(`AEP profile lookup failed (${res.status}): ${JSON.stringify(body).slice(0, 300)}`);
  }
  const data = await res.json();
  const edges = data?.data?.aepProfiles?.edges || [];
  if (!edges.length) throw new Error(`No AEP profile found for ShopperId ${shopperId} in sandbox ${sandbox}.`);
  const node = edges[0].node;
  return { id: node.id, entity: node.entity };
}

async function fetchProfileEdge(encryptedId, token, sandbox, imsOrgId) {
  if (!encryptedId) return [];
  const query =
    "query ProfileEdge($page: PageInput!, $params: ProfilesInput!) {\n" +
    "  profileEdge(page: $page, params: $params) {\n" +
    "    edges { node { id entity isActiveOnEdge lastModifiedAt __typename } __typename }\n" +
    "    pageInfo { hasNextPage hasPreviousPage __typename }\n" +
    "    totalCount\n" +
    "    __typename\n" +
    "  }\n" +
    "}";
  const mergePolicyId = pickForSandbox(SETTINGS.aep?.mergePolicyId, sandbox, "aep.mergePolicyId");
  const res = await fetch(SETTINGS.aep.graphqlUrl, {
    method: "POST",
    headers: aepHeaders(token, sandbox, imsOrgId),
    body: JSON.stringify({
      operationName: "ProfileEdge",
      variables: {
        params: {
          schemaName: "_xdm.context.profile",
          ...(mergePolicyId ? { mergePolicyId } : {}),
          entityId: encryptedId,
        },
        page: { limit: 25, start: 1 },
      },
      query,
    }),
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data?.data?.profileEdge?.edges || [];
}

async function fetchProfileExperienceEvents(encryptedId, token, sandbox, imsOrgId) {
  if (!encryptedId) return [];
  const query =
    "query profileExperienceEvent($page: PageInput!, $params: ProfileExperienceEventInput!) {\n" +
    "  profileExperienceEvent(page: $page, params: $params) {\n" +
    "    children\n" +
    "    _links\n" +
    "    __typename\n" +
    "  }\n" +
    "}";
  const mergePolicyId = pickForSandbox(SETTINGS.aep?.mergePolicyId, sandbox, "aep.mergePolicyId");
  const res = await fetch(SETTINGS.aep.graphqlUrl, {
    method: "POST",
    headers: aepHeaders(token, sandbox, imsOrgId),
    body: JSON.stringify({
      operationName: "profileExperienceEvent",
      variables: {
        params: {
          ...(mergePolicyId ? { mergePolicyId } : {}),
          profileId: encryptedId,
          schemaName: "_xdm.context.experienceevent",
          relatedSchemaName: "_xdm.context.profile",
        },
        page: { limit: 200, start: 1 },
      },
      query,
      extensions: { appId: "profiles", category: "profile-browse-experienceEvents" },
    }),
  });
  if (!res.ok) return [];
  const data = await res.json();
  const children = data?.data?.profileExperienceEvent?.children || [];
  return children
    .map((c) => {
      const ent = c?.entity || {};
      let timestamp = ent.timestamp || "";
      if (!timestamp && typeof c.timestamp === "number") timestamp = new Date(c.timestamp).toISOString();
      const evBlock = ent?._nordstrom?.events || ent?._nordstrom?.event || {};
      const items = Array.isArray(evBlock.items)
        ? evBlock.items
            .map((i) => ({
              // Keep skuId and productDisplayId distinct — don't merge or
              // fall back. Each event type's payload contract differs (BAG
              // emits skuId+lastModifyTime, PDV emits productDisplayId
              // only), and the renderer needs to know which fields are
              // actually present to label them honestly.
              skuId:            i?.skuId || "",
              productDisplayId: i?.productDisplayId || "",
              lastModifyTime:   i?.lastModifyTime || i?.lastModifiedTime || "",
            }))
            .filter((i) => i.skuId || i.productDisplayId)
        : [];

      // AJO messageExecution metadata — surfaces banner / campaign / skuIds
      // for message.feedback (and message.tracking) rows that otherwise show
      // "—" in the Brand and Value columns. Lives deep inside _experience.
      const mdSrc = ent?._experience?.customerJourneyManagement?.messageExecution?.metadata;
      const metadata = (mdSrc && typeof mdSrc === "object") ? {
        campaignType:        mdSrc.campaignType || "",
        campaignId:          mdSrc.campaignId || "",
        banner:              mdSrc.banner || "",
        campaignDescription: mdSrc.campaignDescription || "",
        skuIds:              mdSrc.skuIds || "",
      } : null;

      return {
        eventType: ent.eventType || "—",
        timestamp,
        channelBrand: evBlock.channelBrand || "",
        // SKU summary across all items — used by search filter and as
        // fallback for events the renderer doesn't have a dedicated branch
        // for. Prefer productDisplayId in PDV-style rows (where skuId may
        // be absent), skuId otherwise.
        skuIds: items.map((i) => i.skuId || i.productDisplayId).filter(Boolean),
        items,
        // Per-event-type field surfaces — populated from evBlock when the
        // event happens to carry them. Empty string when absent so the
        // renderer can simply skip falsy fields.
        browsePath:        evBlock.browsePath || "",
        bagType:           evBlock.bagType || "",
        orderNumber:       evBlock.orderNumber || "",
        purchaseId:        evBlock.purchaseId || "",
        eventTime:         evBlock.eventTime || "",
        sourceJourneyName: ent?._nordstrom?.ajoJourney?.sourceJourneyName || "",
        metadata,
      };
    })
    .sort((a, b) => (b.timestamp || "").localeCompare(a.timestamp || ""));
}

async function resolveSegmentNames(segments, token, sandbox, imsOrgId) {
  if (!segments.length) return {};
  const query =
    "query profileSegmentMembershipForProfileViewer($params: ProfileSegmentMembershipIdsInput!) {\n" +
    "  profileSegmentMembership(params: $params) {\n" +
    "    id\n    name\n    __typename\n  }\n}";
  // Adobe handles ~100 at a time; cap to be safe.
  const BATCH = 100;
  const nameMap = {};
  for (let i = 0; i < segments.length; i += BATCH) {
    const batch = segments.slice(i, i + BATCH).map((s) => ({
      namespace: s.namespace || "ups",
      segmentId: s.id,
    }));
    try {
      const res = await fetch(SETTINGS.aep.graphqlUrl, {
        method: "POST",
        headers: aepHeaders(token, sandbox, imsOrgId),
        body: JSON.stringify({
          operationName: "profileSegmentMembershipForProfileViewer",
          variables: { params: { segmentIds: batch } },
          query,
          extensions: { appId: "profiles", category: "profile-browse" },
        }),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const list = data?.data?.profileSegmentMembership || [];
      for (const row of list) if (row?.id && row?.name) nameMap[row.id] = row.name;
    } catch (e) {
      console.warn("Segment name resolution failed:", e.message);
    }
  }
  return nameMap;
}

async function fetchProfileSummary(shopperId) {
  if (!shopperId) throw new Error("Shopper ID is required.");
  await SETTINGS_READY;

  // All four values come from the live Adobe tab — sandbox + tenant from
  // the URL, token + imsOrgId from storage. settings.json only kicks in
  // when one of those is unavailable.
  const { token, sandbox, tenant, imsOrgId } = await getTabContext();

  const { id: profileId, entity } = await fetchProfileByShopperId(shopperId, token, sandbox, imsOrgId);

  const membership = entity?.segmentMembership || {};
  const segments = [];
  for (const [namespace, byId] of Object.entries(membership)) {
    if (!byId || typeof byId !== "object") continue;
    for (const [segId, info] of Object.entries(byId)) {
      segments.push({
        namespace,
        id: segId,
        status: info?.status || "",
        lastQualificationTime: info?.lastQualificationTime || "",
      });
    }
  }

  const [nameMap, edges, events] = await Promise.all([
    resolveSegmentNames(segments, token, sandbox, imsOrgId),
    fetchProfileEdge(profileId, token, sandbox, imsOrgId),
    fetchProfileExperienceEvents(profileId, token, sandbox, imsOrgId),
  ]);

  const audiences = segments.map((s) => ({ ...s, name: nameMap[s.id] || s.id }));
  const { segmentMembership: _ignored, ...primaryAttrs } = entity || {};
  const edgeAttrs = edges.map((e) => e?.node?.entity).filter(Boolean);

  return {
    shopperId, profileId, sandbox, tenant, imsOrgId,
    audiences, events,
    attributes: primaryAttrs, edgeAttributes: edgeAttrs,
  };
}

async function safeJson(res) { try { return await res.json(); } catch { return await res.text(); } }

// ── Message bridge ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  if (req.action === "getSettings") {
    SETTINGS_READY
      .then(() => sendResponse({ ok: true, settings: SETTINGS }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (req.action === "fireEvent") {
    fireEvent(req)
      .then((r) => sendResponse({ ok: true, result: r }))
      .catch((e) => sendResponse({
        ok: false,
        error: e.message,
        status: e.status || 0,
        payload: e.payload || null,
        responseBody: e.responseBody || null,
        request: e.request || null,
      }));
    return true;
  }

  if (req.action === "dryFireEvent") {
    dryFireEvent(req)
      .then((r) => sendResponse({ ok: true, result: r }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (req.action === "viewProfile") {
    fetchProfileSummary(req.shopperId)
      .then((r) => sendResponse({ ok: true, result: r }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (req.action === "getContext") {
    // Best-effort context lookup for the side panel — surfaces tenant /
    // sandbox / imsOrgId so the shortcut bar and profile deep link match
    // the live Adobe tab. Falls back to settings.json on any error so the
    // panel never blanks out when no Adobe tab is open.
    getTabContext()
      .then((ctx) => sendResponse({
        ok: true,
        context: {
          tenant: ctx.tenant,
          sandbox: ctx.sandbox,
          imsOrgId: ctx.imsOrgId,
        },
      }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (req.action === "getJourneyContext") {
    // Resolves the live journey: journeyId from the URL hash + name/type/
    // eventUid from the authoring API. Used by the AJO Qualification form
    // to populate read-only fields with sensible defaults.
    getJourneyContext()
      .then((r) => sendResponse({ ok: true, result: r }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  return false;
});
